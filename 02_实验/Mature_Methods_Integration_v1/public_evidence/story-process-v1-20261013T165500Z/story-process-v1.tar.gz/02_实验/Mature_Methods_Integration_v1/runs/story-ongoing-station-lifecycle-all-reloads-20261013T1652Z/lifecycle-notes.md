# Scoped service lifecycle carrier

This carrier preserves the three stop/start pairs associated with the system-work source/reload sequence. The original logs remain in `outputs/native_platform_p1p2_v0/p1_evennia_20261010/runs/`; the files here are exact copies.

| UTC label | Stop SHA-256 | Start SHA-256 | Scope |
|---|---|---|---|
| `system-work-reload` 14:29 | `0bb92b1c2e486e5635d2dff39cd1a6ed6c6b0d7b2a02e3a8ab4d4d2dad6bb9c1` | `e236f84730b245ea783835bacbfe2a854cf980f84880972b119f747742b4f5d2` | Initial station-work runtime reload; preserved source identities are recorded in the corresponding scene `identity.json` files. |
| `system-work-plannerfix-reload` 14:56 | `0bb92b1c2e486e5635d2dff39cd1a6ed6c6b0d7b2a02e3a8ab4d4d2dad6bb9c1` | `e236f84730b245ea783835bacbfe2a854cf980f84880972b119f747742b4f5d2` | Reload after the P3 planning fix; subsequent scene source identity is recorded per run. |
| `ongoing-station-deferred-offer-recheck` 16:32–16:33 | `0bb92b1c2e486e5635d2dff39cd1a6ed6c6b0d7b2a02e3a8ab4d4d2dad6bb9c1` | `e236f84730b245ea783835bacbfe2a854cf980f84880972b119f747742b4f5d2` | Final deferred-offer retention source reload used for the four final scenes. |

The three pairs have identical stop/start log bytes because the helper output was identical. The earlier process-permission check was inconclusive (`kill -0` did not establish absence); no PID file was moved. A later independent loopback-listener check confirmed the existing instance. No standalone permission-error log or source-freeze transcript was present to copy; exact source snapshots remain alongside each run. This note distinguishes those recorded facts from the copied helper logs and does not claim the helper logs prove a source hash was loaded.

Only scoped lifecycle text/logs are included. No PID file, service configuration, credential, database binary, or full server log is included.

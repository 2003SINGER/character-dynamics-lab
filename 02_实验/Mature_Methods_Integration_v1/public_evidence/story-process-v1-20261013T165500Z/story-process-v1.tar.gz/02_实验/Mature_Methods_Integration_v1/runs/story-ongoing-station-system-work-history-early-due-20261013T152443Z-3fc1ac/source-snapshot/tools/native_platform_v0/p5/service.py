"""Narrow P5 orchestration over Evennia W, actor callbacks, and TypedIR.

Only generated P5 scenes are accepted. The director can propose one registered
route opportunity; the world adapter rechecks its active bundle permission and
the physical budget before changing a native exit lock.
"""

from __future__ import annotations

from collections.abc import Mapping
from collections.abc import Sequence
from copy import deepcopy
from functools import wraps
from hashlib import sha256
import json
from types import SimpleNamespace

from .bundle import BundleError, BundleStore, load_bundle
from .monitor import evaluate_bundle
from .planning import NO_OP, plan
from . import world


SOCIAL_PRESETS = {"native_default_reject_v0", "hero_intelligence_30_v0"}
MAX_HORIZON = 24
_P5_CONTROL_ROLE_BY_ALIAS = {"A": "courier", "B": "resident"}


def _inline_callbacks(function):
    """Delay the Twisted import until a native-server operation is invoked."""
    @wraps(function)
    def wrapped(*args, **kwargs):
        from twisted.internet import defer
        return defer.inlineCallbacks(function)(*args, **kwargs)
    return wrapped


def _attr(obj, key, default=None, category="native_p3"):
    return obj.attributes.get(key, category=category, default=default)


def _set(obj, key, value, category="native_p5"):
    obj.attributes.add(key, value, category=category)


def _entities():
    from .bundle import DEFAULT_ENTITIES
    return dict(DEFAULT_ENTITIES)


def _scene_objects(scene_id):
    return world.scene_objects(scene_id)


def _bundle_for(pickup):
    raw = _attr(pickup, "p5_active_bundle", category="native_p5")
    entities = _attr(pickup, "p5_entities", category="native_p5")
    if not isinstance(raw, Mapping) or not isinstance(entities, Mapping):
        raise ValueError("P5 scene lacks its active author bundle or entity catalog")
    # Evennia persists nested attributes as _SaverDict/_SaverList. Normalize
    # recursively without relaxing the strict JSON loader's type checks.
    return load_bundle(_plain_json(raw), entities=_plain_json(entities))


def _stable_entities():
    return {alias: {"entity_type": value.entity_type, "stable_id": value.stable_id,
                    "display_name": value.display_name}
            for alias, value in _entities().items()}


def _plain_json(value):
    if isinstance(value, Mapping):
        return {str(key): _plain_json(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_plain_json(item) for item in value]
    return value


def _bundle_sha256(bundle):
    raw = json.dumps(_plain_json(bundle.raw), sort_keys=True, ensure_ascii=False,
                     separators=(",", ":")).encode("utf-8")
    return sha256(raw).hexdigest()


def _current_verdicts(scene_id, bundle, *, through_minute=None):
    trace = world.build_typed_trace(scene_id, bundle, _entities(), through_minute=through_minute)
    return evaluate_bundle(bundle, trace), trace


def _pending_identity(actor):
    pending = _attr(actor, "pending_action")
    if not isinstance(pending, Mapping):
        return None
    # Preserve the complete pending record (including operation_id,
    # planned_at_tick, and full intent). This records identity, not a claim of
    # durable multi-tick execution progress.
    return _plain_json(deepcopy(pending))


def _ledger_prefix(pickup, before_minute):
    rows = list(_attr(pickup, "p4_ledger", default=[]))
    # Full JSON rows make prefix equality sensitive to typed_args/provenance
    # edits, not merely event headers.
    return [_plain_json(deepcopy(row)) for row in rows
            if int(row.get("minute", -1)) < before_minute]


def _candidate_guard_matches(guard, *, scene_id, bundle_version, now,
                             events_through, values_through, action, opportunity_id):
    """Recheck an external planner candidate at native dispatch time.

    This is a narrow freshness/identity guard, not a signature or planner
    authentication mechanism. World permission and physical budget are still
    checked by ``world.activate_opportunity`` after this guard passes.
    """
    if (not isinstance(guard, Mapping) or set(guard) != {
            "scene_id", "bundle_version", "based_on_minute", "events_through",
            "values_through", "selected_action", "opportunity_id"}):
        return False
    based = guard.get("based_on_minute")
    return (
        guard.get("scene_id") == scene_id
        and type(guard.get("bundle_version")) is int
        and guard["bundle_version"] == bundle_version
        and type(based) is int
        and now == based + 1
        and type(guard.get("events_through")) is int
        and guard["events_through"] == events_through == based
        and type(guard.get("values_through")) is int
        and guard["values_through"] == values_through == based
        and guard.get("selected_action") == action
        and guard.get("opportunity_id") == opportunity_id
    )


def reset_p5_scenario(*, owner, bundle, initial_social_preset="native_default_reject_v0",
                      horizon=24, seed=0, director_enabled=True, shared_supply=False,
                      initial_main_open=True, story_process=None, story_strategy="gtpyhop",
                      ongoing_station=None):
    """Create a fresh P5 scene without reusing or overwriting any generated objects."""
    if initial_social_preset not in SOCIAL_PRESETS:
        raise ValueError("initial_social_preset is not a registered native preset")
    station_profile = None
    if ongoing_station is not None:
        try:
            from tools.native_platform_v0.p5.ongoing_station.model import load_profile, compile_projection
            station_profile = load_profile(ongoing_station)
            compile_projection(station_profile, entities=_entities())
            if story_process is not None:
                raise ValueError("ongoing_station cannot be combined with legacy story_process")
            if horizon not in (24, station_profile.horizon):
                raise ValueError("explicit horizon must match ongoing_station.horizon")
            horizon = station_profile.horizon
        except (TypeError, ValueError, BundleError) as exc:
            return {"ok": False, "scene_created": False,
                    "error": {"code": "INVALID_ONGOING_STATION", "details": {"reason": str(exc)}}}
    station_work_enabled = bool(station_profile is not None and
                                getattr(station_profile, "game_content", None) == "station_work_v1")
    if type(horizon) is not int or not 1 <= horizon <= (48 if station_profile else MAX_HORIZON):
        raise ValueError("P5 horizon must be an integer in [1,24]")
    if type(seed) is not int or not 0 <= seed <= 2**31 - 1:
        raise ValueError("P5 seed must be an integer in [0,2147483647]")
    if type(director_enabled) is not bool or type(shared_supply) is not bool or type(initial_main_open) is not bool:
        raise ValueError("P5 director, shared_supply, and initial_main_open must be booleans")
    if story_process is not None and story_strategy not in {"gtpyhop", "event_driven"}:
        raise ValueError("story_strategy must be gtpyhop or event_driven")
    if ongoing_station is not None and story_strategy not in {"gtpyhop", "event_driven"}:
        raise ValueError("ongoing station strategy must be gtpyhop or event_driven")
    entities = _stable_entities()
    try:
        # Validate external author input before importing Evennia factories or
        # creating any world objects, while preserving the public error code.
        active = load_bundle(bundle, entities=entities)
    except BundleError as exc:
        return {"ok": False, "scene_created": False,
                "error": {"code": exc.code, "details": dict(exc.details)}}
    if story_process is not None:
        try:
            from tools.native_platform_v0.p5.story_process.model import load_request
            template = load_request(story_process, allow_template=True)
            if template.scenario_id is not None or template.task_control_grant.get("scenario_id") is not None:
                raise ValueError("story-process reset template must leave scene and grant scenario IDs unbound")
        except (ValueError, TypeError) as exc:
            return {"ok": False, "scene_created": False,
                    "error": {"code": "INVALID_STORY_PROCESS_REQUEST", "details": {"reason": str(exc)}}}
    from evennia import create_object
    from typeclasses.characters import Character
    from typeclasses.exits import Exit
    from typeclasses.objects import Object
    from typeclasses.rooms import Room
    from tools.native_platform_v0.p3.scene import create_scene

    scene = create_scene(SimpleNamespace(account=owner), mode="b", seed=seed, drive_mode="manual",
                         interval=4, activity_profile="p4_story_v0", delivery_task=True,
                         p4_east_closed=not initial_main_open, p4_deadline=24)
    scene_id = scene["scene_id"]
    pickup, destination = scene["pickup"], scene["destination"]
    p4_clock = dict(_attr(pickup, "p4_clock"))
    p4_clock["deadline"] = horizon
    pickup.attributes.add("p4_clock", p4_clock, category="native_p3")
    actors = {"A": scene["courier"], "B": scene["resident"]}
    player = create_object(Character, key=f"P5 Fixture Player {scene_id}", location=pickup,
                           attributes=[("p3_scene_id", scene_id, "native_p3"),
                                       ("p3_control_role", "player", "native_p3"),
                                       ("owner_account_id", owner.id, "native_p3"),
                                       ("drive_mode", "manual", "native_p3"),
                                       ("log", [], "native_p3"),
                                       ("native_receipts", [], "native_p3")])
    side = create_object(Room, key=f"P5 Side Room {scene_id}",
                         attributes=[("p3_scene_id", scene_id, "native_p3")])
    # The direct route is inherited from the P4 fixture; P5 adds a second,
    # longer physical route through this generated third room.
    side_in = create_object(Exit, key="south", location=pickup, destination=side,
                            locks="traverse:false()",
                            attributes=[("p3_scene_id", scene_id, "native_p3"),
                                        ("p5_route_id", "side_passage", "native_p5")])
    side_back = create_object(Exit, key="north", location=side, destination=pickup,
                              locks="traverse:false()",
                              attributes=[("p3_scene_id", scene_id, "native_p3"),
                                          ("p5_route_id", "side_passage", "native_p5")])
    side_to_dest = create_object(Exit, key="east", location=side, destination=destination,
                                 locks="traverse:false()",
                                 attributes=[("p3_scene_id", scene_id, "native_p3"),
                                             ("p5_route_id", "side_passage", "native_p5")])
    dest_to_side = create_object(Exit, key="south", location=destination, destination=side,
                                 locks="traverse:false()",
                                 attributes=[("p3_scene_id", scene_id, "native_p3"),
                                             ("p5_route_id", "side_passage", "native_p5")])
    main_edges = [edge for room in (pickup, destination) for edge in room.exits
                  if edge.key in ("east", "west") and edge.destination in (pickup, destination)
                  and _attr(edge, "p3_scene_id") == scene_id]
    for edge in main_edges:
        _set(edge, "p5_route_id", "main_passage")
    items = {"courier_supply": scene["supply"], "resident_parcel": scene["return_parcel"]}
    if shared_supply:
        # Both delivery contracts now reference one actual object. The fixture's
        # resident parcel remains an unrelated generated object and is excluded
        # from either task binding.
        item = scene["supply"]
        actors["B"].attributes.add("task_item_id", item.id, category="native_p3")
        actors["B"].attributes.add("task_item_key", item.key, category="native_p3")
        actors["B"].attributes.add("task_item_dbref", item.dbref, category="native_p3")
        actors["B"].attributes.add("p3_role", "assigned_supply", category="native_p3")
        _set(item, "p5_item_alias", "courier_supply")
        _set(scene["return_parcel"], "p5_item_alias", "resident_parcel")
    else:
        _set(scene["supply"], "p5_item_alias", "courier_supply")
        _set(scene["return_parcel"], "p5_item_alias", "resident_parcel")
    _set(pickup, "p5_scene_id", scene_id, category="native_p3")
    _set(pickup, "p5_side_room_id", int(side.id))
    _set(pickup, "p5_station_archive_room_id", int(destination.id))
    _set(pickup, "p5_active_bundle", _plain_json(active.raw))
    _set(pickup, "p5_entities", entities)
    _set(pickup, "p5_bundle_archive", [])
    _set(pickup, "p5_spent_cost", 0)
    _set(pickup, "p5_opportunities_used", 0)
    _set(pickup, "p5_event_coverage_minute", 0)
    _set(pickup, "p5_snapshot_coverage_minute", 0)
    _set(pickup, "p5_completed_minutes", [0])
    _set(pickup, "p5_director_enabled", director_enabled)
    _set(pickup, "p5_horizon", horizon)
    _set(pickup, "p5_shared_supply", shared_supply)
    for room in (pickup, destination, side):
        _set(room, "p5_scene_id", scene_id)
    for edge in main_edges:
        _set(edge, "p5_route_id", "main_passage")
    for edge in (side_in, side_back, side_to_dest, dest_to_side):
        _set(edge, "p5_route_id", "side_passage")
    for alias, actor in actors.items():
        # P5 actors are freshly-created by the P3 scene factory. Bind their
        # existing authenticated control roles here so observe_actor's normal
        # role+owner lookup can resolve the P5 aliases; this does not change
        # either NPC policy or controller authority.
        actor.attributes.add("p3_control_role", _P5_CONTROL_ROLE_BY_ALIAS[alias],
                             category="native_p3")
        actor.attributes.add("activity_profile", "p5_story_v0", category="native_p3")
        _set(actor, "p5_actor_alias", alias)
        _set(actor, "p5_task_item_alias", "courier_supply" if alias == "A" else
             ("courier_supply" if shared_supply else "resident_parcel"))
        _set(actor, "p5_native_social_preset", initial_social_preset, category="native_p3")
        _set(actor, "p5_social_target_alias", "B" if alias == "A" else "A")
        _set(actor, "p5_delivery_task", True)
    station_objects = None
    if station_work_enabled:
        # In the opt-in work profile both roles begin co-present at their
        # registered workbench; legacy profiles keep the original P3 starts.
        for station_actor in actors.values():
            if station_actor.location != pickup:
                station_actor.move_to(pickup, quiet=True)
        station_tool = create_object(Object, key=f"Shared Station Tool {scene_id}", location=pickup,
                                     attributes=[("p3_scene_id", scene_id, "native_p3")])
        station_storage = create_object(Object, key=f"Station Storage {scene_id}", location=destination,
                                        attributes=[("p3_scene_id", scene_id, "native_p3")])
        from tools.native_platform_v0.p5.ongoing_station.work import initialize_content, TASK_DURATIONS
        content = initialize_content(pickup, destination, side, scene["supply"], station_tool,
                                     station_storage, side_in)
        horizon_deadline = int(horizon)
        _set(actors["A"], "p5_station_task_bindings", [
            {"task_kind": "inspect_supply", "item_id": int(scene["supply"].id),
             "tool_id": int(station_tool.id), "target_id": int(scene["supply"].id),
             "target_room_id": int(pickup.id), "storage_destination_id": int(station_storage.id),
             "duration_minutes": TASK_DURATIONS["inspect_supply"], "deadline_minute": horizon_deadline},
            {"task_kind": "store_item", "item_id": int(scene["supply"].id),
             "storage_destination_id": int(station_storage.id),
             "storage_room_id": int(destination.id), "deadline_minute": horizon_deadline},
        ])
        _set(actors["B"], "p5_station_task_bindings", [
            {"task_kind": "repair_passage", "tool_id": int(station_tool.id),
             "target_id": int(side_in.id), "target_room_id": int(pickup.id),
             "duration_minutes": TASK_DURATIONS["repair_passage"], "deadline_minute": horizon_deadline},
        ])
        for station_actor in (*actors.values(), player):
            _set(station_actor, "p5_station_profile_enabled", True)
            from tools.native_platform_v0.p5.ongoing_station.commands import install as install_station_commands
            install_station_commands(station_actor)
        station_objects = {"tool": station_tool, "storage": station_storage, "content": content}
    _set(scene["supply"], "p5_item_alias", "courier_supply")
    _set(scene["return_parcel"], "p5_item_alias", "resident_parcel")
    _set(pickup, "p5_world_snapshots", [])
    world.capture_snapshot(scene_id, 0)
    # Mark initial time as a complete, immutable snapshot, not as actor evidence.
    _set(pickup, "p5_snapshot_coverage_minute", 0)
    if story_process is not None:
        from tools.native_platform_v0.p5.story_process.native import initialize_story_process
        story_request = initialize_story_process(pickup, story_process, scene_id, story_strategy)
        for actor in actors.values():
            _set(actor, "p5_story_postresponse_policy", _plain_json(story_request.actor_postresponse))
            _set(actor, "p5_story_deadline", int(story_request.objective["by_minute"]))
    if station_profile is not None:
        from tools.native_platform_v0.p5.ongoing_station.controller import initialize, publish_after_seal
        initialize(pickup, actors, ongoing_station)
        _set(pickup, "p5_ongoing_station_strategy", story_strategy)
        publish_after_seal(scene_id, 0)
    return {"scene_id": scene_id, "seed": seed, "horizon": horizon, "now": 0,
            "preset": initial_social_preset, "director_enabled": director_enabled,
            "shared_supply": shared_supply,
            "rooms": {"origin": int(pickup.id), "destination": int(destination.id), "side": int(side.id)},
            "actors": {alias: {"id": int(actor.id), "dbref": str(actor.dbref)}
                       for alias, actor in actors.items()},
            "player": {"id": int(player.id), "dbref": str(player.dbref)},
            "items": {alias: {"id": int(item.id), "dbref": str(item.dbref)}
                      for alias, item in items.items() if item is not None} |
                     ({"station_tool": {"id": int(station_objects["tool"].id),
                                         "dbref": str(station_objects["tool"].dbref)},
                       "station_storage": {"id": int(station_objects["storage"].id),
                                           "dbref": str(station_objects["storage"].dbref)}}
                      if station_work_enabled else {}),
            "active_bundle": {"bundle_id": active.bundle_id, "version": active.version},
            "pending_actions": {alias: None for alias in actors},
            **({"story_process": {"strategy": story_strategy,
                                  "note_binding": "native_note_pending"}}
               if story_process is not None else {}),
            **({"ongoing_station": {"station_id": station_profile.station_id,
                                      "profile_version": station_profile.version,
                                      "horizon": station_profile.horizon,
                                      "author_status": "STAGED_INACTIVE" if station_profile.author else "ABSENT",
                                      **({"game_content": "station_work_v1",
                                          "game_content_version": 1,
                                          "tool_id": int(station_objects["tool"].id),
                                          "storage_id": int(station_objects["storage"].id),
                                          "supply_id": int(scene["supply"].id),
                                          "repair_exit_id": int(side_in.id)} if station_work_enabled else {})}}
               if station_profile is not None else {})}


def edit_author_bundle(scene_id, raw_bundle, expected_version):
    pickup, rows = _scene_objects(scene_id)
    active = _bundle_for(pickup)
    before = {str(_attr(obj, "p5_actor_alias", category="native_p5")): _pending_identity(obj)
              for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}
    before_verdicts, _ = _current_verdicts(scene_id, active)
    completed = {row["constraint_id"] for row in before_verdicts["constraints"]
                 if row["status"] == "SATISFIED"}
    evidence = {row["constraint_id"] for row in before_verdicts["constraints"]
                if row.get("witness") is not None}
    now = int(_attr(pickup, "p4_clock")["now"])
    prior_prefix = _ledger_prefix(pickup, now)
    store = BundleStore(active, entities=_entities())
    try:
        candidate = store.replace(raw_bundle, expected_version, now=now,
                                  completed_constraint_ids=completed,
                                  evidence_constraint_ids=evidence)
    except BundleError as exc:
        return {"ok": False, "error": {"code": exc.code, "message": str(exc),
                                        "details": exc.details},
                "active_bundle": {"bundle_id": active.bundle_id, "version": active.version},
                "now": now,
                "ledger_prefix_before": deepcopy(prior_prefix),
                "ledger_prefix_after": deepcopy(_ledger_prefix(pickup, now)),
                "prefix_event_ids_before": [row["event_id"] for row in prior_prefix],
                "prefix_event_ids_after": [row["event_id"] for row in _ledger_prefix(pickup, now)],
                "historical_prefix_preserved": prior_prefix == _ledger_prefix(pickup, now),
                "pending_actions_before": before,
                "pending_actions_after": {str(_attr(obj, "p5_actor_alias", category="native_p5")): _pending_identity(obj)
                                           for obj in rows if _attr(obj, "activity_profile") == world.PROFILE},
                "pending_identity_preserved": before == {
                    str(_attr(obj, "p5_actor_alias", category="native_p5")): _pending_identity(obj)
                    for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}}
    archive = list(_attr(pickup, "p5_bundle_archive", category="native_p5", default=[]))
    archive.append({"bundle_id": active.bundle_id, "version": active.version,
                    "now": now, "verdicts": before_verdicts})
    _set(pickup, "p5_bundle_archive", archive)
    _set(pickup, "p5_active_bundle", _plain_json(candidate.raw))
    later_prefix = _ledger_prefix(pickup, now)
    after = {str(_attr(obj, "p5_actor_alias", category="native_p5")): _pending_identity(obj)
             for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}
    return {"ok": True, "active_bundle": {"bundle_id": candidate.bundle_id,
                                             "version": candidate.version},
            "now": now, "archive": {"prior_version": active.version,
                                     "prior_verdicts": before_verdicts},
            "ledger_prefix_before": deepcopy(prior_prefix),
            "ledger_prefix_after": deepcopy(later_prefix),
            "prefix_event_ids_before": [row["event_id"] for row in prior_prefix],
            "prefix_event_ids_after": [row["event_id"] for row in later_prefix],
            "historical_prefix_preserved": prior_prefix == later_prefix,
            "pending_actions_before": before, "pending_actions_after": after,
            "pending_identity_preserved": before == after}


def _director_planning_view(scene_id, bundle, *, now, verdicts_through_minute):
    """Return the exact symbolic input consumed by the existing P5 Director.

    ``verdicts_through_minute`` is explicit so the live Director can retain its
    prior-sealed-prefix semantics while read-only evidence can request the
    current sealed frontier. This helper only reads native world state.
    """
    pickup, rows = _scene_objects(scene_id)
    actors = {str(_attr(obj, "p5_actor_alias", category="native_p5")): obj
              for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}
    trace_result, _trace = _current_verdicts(
        scene_id, bundle, through_minute=verdicts_through_minute)
    state = {"now": int(now), "horizon": int(_attr(pickup, "p5_horizon", category="native_p5")),
             "routes": world.route_rows(scene_id, actors["A"], bundle),
             "spent_cost": int(_attr(pickup, "p5_spent_cost", category="native_p5", default=0)),
             "opportunities_used": int(_attr(pickup, "p5_opportunities_used", category="native_p5", default=0)),
             "verdicts": [{"constraint_id": row["constraint_id"], "status": row["status"]}
                          for row in trace_result["constraints"]],
             "physical_budget": 2}
    return {"state": state,
            "verdicts": trace_result,
            "typed_trace": world.serialize_typed_trace(_trace)}


def _director(scene_id, bundle, *, enabled):
    from tools.native_platform_v0.p3.p4_world import append_event, clock_for_actor

    pickup, rows = _scene_objects(scene_id)
    actors = {str(_attr(obj, "p5_actor_alias", category="native_p5")): obj
              for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}
    clock = clock_for_actor(actors["A"])
    now = int(clock["now"])
    # Keep the original live policy boundary: callbacks at this minute have
    # not happened yet, so planning uses only through the prior sealed prefix.
    authorized = _director_planning_view(scene_id, bundle, now=now,
                                          verdicts_through_minute=max(0, now - 1))
    state = authorized["state"]
    proposal = plan(bundle, state)
    action = proposal["selected_action"] if enabled else NO_OP
    director_id = f"p5:{_attr(pickup, 'scenario_seed', default=0)}:{clock['now']}:director:v{bundle.version}"
    append_event(scene_id, {"event_type": "P5_DIRECTOR_DECISION", "event_id": director_id,
                            "typed_args": {"bundle_id": bundle.bundle_id, "bundle_version": bundle.version,
                                           "enabled": enabled, "selected_action": action,
                                           "plan": proposal}, "sealed": True})
    settlement = None
    if action != NO_OP:
        settlement = world.activate_opportunity(scene_id, actors["A"], action, bundle,
                                                expected_version=bundle.version)
        append_event(scene_id, {"event_type": "P5_OPPORTUNITY_ATTEMPT",
                                "event_id": f"{director_id}:world",
                                "typed_args": settlement, "sealed": True,
                                "receipt_id": settlement.get("receipt_id")})
    return {"plan": proposal, "selected_action": action, "settlement": settlement,
            "bundle_version": bundle.version, "authorized_view": state}


def _snapshot_actor(actor):
    return {"actor_alias": _attr(actor, "p5_actor_alias", category="native_p5"),
            "actor_id": int(actor.id), "room_id": int(actor.location.id) if actor.location else None,
            "inventory_ids": sorted(int(obj.id) for obj in actor.contents),
            "task_item_id": _attr(actor, "task_item_id"),
            "task_destination_id": _attr(actor, "task_destination_id"),
            "status": _attr(actor, "status"), "pending_action": deepcopy(_attr(actor, "pending_action")),
            "native_receipts": list(_attr(actor, "native_receipts", default=[])),
            "log": list(_attr(actor, "log", default=[]))}


def _planner_scene_binding(scene_id):
    """Read the exact generated P5 fixture's role IDs and registered exits.

    This is a world-capability projection for the external planner, not an
    actor observation and not a dispatch/assignment API. It is deliberately
    scoped to _scene_objects(scene_id) and the two closed P5 route IDs.
    """
    pickup, rows = _scene_objects(scene_id)
    by_id = {int(obj.id): obj for obj in rows}
    destination_id = _attr(pickup, "p4_destination_id")
    side_id = _attr(pickup, "p5_side_room_id", category="native_p5")
    if type(destination_id) is not int or type(side_id) is not int:
        raise ValueError("generated P5 fixture lacks registered destination/side room bindings")
    destination, side = by_id.get(destination_id), by_id.get(side_id)
    if destination is None or side is None:
        raise ValueError("generated P5 fixture room bindings do not resolve inside the scene")
    actors = {str(_attr(obj, "p5_actor_alias", category="native_p5")): obj
              for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}
    if set(actors) != {"A", "B"}:
        raise ValueError("planner scene binding requires the generated A/B actors")
    task_bindings = {}
    for alias, actor in actors.items():
        item_id = _attr(actor, "task_item_id")
        bound_item = by_id.get(int(item_id)) if type(item_id) is int else None
        item_alias = _attr(actor, "p5_task_item_alias", category="native_p5")
        bound_destination = _attr(actor, "task_destination_id")
        if bound_item is None or type(bound_destination) is not int or bound_destination != destination_id:
            raise ValueError(f"generated actor {alias} lacks its existing bound task identity")
        if item_alias not in {"courier_supply", "resident_parcel"}:
            raise ValueError(f"generated actor {alias} has an unregistered P5 task item alias")
        task_bindings[alias] = {"actor_id": int(actor.id), "item_alias": item_alias,
                                "item_id": int(bound_item.id),
                                "destination_id": int(bound_destination),
                                "source": "existing_scene_actor_binding"}
    routes = []
    author_actor = actors["A"]
    for route_id, opportunity_id in (("main_passage", "open_main_passage"),
                                     ("side_passage", "open_side_passage")):
        changed_edges = world.route_edges(scene_id, route_id)
        changed_ids = {int(edge.id) for edge in changed_edges}
        actual_edges = [edge for room in (pickup, side, destination) for edge in room.exits
                        if edge.destination is not None
                        and _attr(edge, "p3_scene_id") == scene_id
                        and _attr(edge, "p5_route_id", category="native_p5") == route_id]
        if not actual_edges or not changed_ids.issubset({int(edge.id) for edge in actual_edges}):
            raise ValueError(f"registered route {route_id} has an incomplete changed-edge binding")
        routes.append({"route_id": route_id, "opportunity_id": opportunity_id,
                       "cost": world.ROUTE_ACTIONS[opportunity_id][1],
                       "changed_edge_ids": sorted(changed_ids),
                       "directed_edges": [{"exit_id": int(edge.id),
                                           "from_room_id": int(edge.location.id),
                                           "to_room_id": int(edge.destination.id),
                                           "changed_by_author_op": int(edge.id) in changed_ids,
                                           "traversable_now": bool(edge.access(author_actor, "traverse", default=True))}
                                          for edge in actual_edges]})
    return {"schema": "p5-planner-scene-binding-v1",
            "source": "native_platform_v0.p5.service._planner_scene_binding",
            "scene_id": scene_id,
            "room_roles": {"pickup": int(pickup.id), "side": int(side.id),
                           "porch": int(destination.id)},
            "task_bindings": task_bindings, "routes": routes}


def _complete_minute(scene_id, minute):
    pickup, rows = _scene_objects(scene_id)
    from tools.native_platform_v0.p3.p4_world import append_event

    aliases = {str(_attr(obj, "p5_actor_alias", category="native_p5")): obj
               for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}
    if set(aliases) != {"A", "B"}:
        raise ValueError("P5 minute cannot complete without both actor callbacks")
    station_meta = _attr(pickup, "p5_ongoing_station_meta", category="native_p5")
    if isinstance(station_meta, Mapping):
        station_meta = _plain_json(station_meta)
        seen = set(station_meta.get("projected_receipt_ids", []))
        actor_by_id = {int(actor.id): alias for alias, actor in aliases.items()}
        for alias, actor in aliases.items():
            for receipt in _plain_json(_attr(actor, "native_receipts", default=[])):
                receipt_id = receipt.get("receipt_id")
                if (not receipt_id or receipt_id in seen or receipt.get("settled") is not True
                        or receipt.get("ongoing_task_kind") not in {"archive_note", "handover_note"}):
                    continue
                task_kind = receipt["ongoing_task_kind"]
                item_id = receipt.get("item_id")
                if type(item_id) is not int:
                    continue
                commitments = _plain_json(_attr(actor, "ongoing_commitments", category="native_p5", default=[]))
                commitment = next((row for row in commitments
                                   if row.get("commitment_id") == receipt.get("ongoing_commitment_id")), {})
                destination_id = commitment.get("destination_id")
                event_type = ("P5_ONGOING_STATION_NOTE_ARCHIVED" if task_kind == "archive_note"
                              and receipt.get("kind") == "drop"
                              and receipt.get("after_item_room_id") == destination_id
                              else "P5_ONGOING_STATION_NOTE_HANDED_OVER" if task_kind == "handover_note"
                              and receipt.get("kind") == "give"
                              and item_id in receipt.get("recipient_inventory_ids", []) else None)
                if event_type is None:
                    continue
                recipient_id = receipt.get("recipient_id")
                recipient_alias = actor_by_id.get(recipient_id) if recipient_id is not None else None
                append_event(scene_id, {"event_type": event_type,
                                        "event_id": f"station-receipt:{receipt_id}",
                                        "typed_args": {"receipt_id": receipt_id,
                                                       "commitment_id": receipt.get("ongoing_commitment_id"),
                                                       "task_kind": task_kind, "actor_alias": alias,
                                                       "recipient_alias": recipient_alias,
                                                       "item_id": item_id, "settled": True},
                                        "sealed": True})
                seen.add(receipt_id)
        station_meta["projected_receipt_ids"] = sorted(seen)
        _set(pickup, "p5_ongoing_station_meta", station_meta)
    if _attr(pickup, "p5_station_content_v1", category="native_p5") is not None:
        _project_tool_transfer_events(scene_id, minute, pickup, rows, aliases, append_event)
    snapshots = world.capture_snapshot(scene_id, minute)
    callback_event_ids = [f"p5:{_attr(pickup, 'scenario_seed', default=0)}:{alias}:{minute}:callback"
                          for alias in ("A", "B")]
    for alias, actor in aliases.items():
        callback_id = f"p5:{_attr(pickup, 'scenario_seed', default=0)}:{alias}:{minute}:callback"
        append_event(scene_id, {"event_type": "P5_NPC_CALLBACK", "event_id": callback_id,
                                "typed_args": {"actor_alias": alias, "actor_id": int(actor.id),
                                               "room_id_after": int(actor.location.id) if actor.location else None,
                                               "receipts_after": len(_attr(actor, "native_receipts", default=[]))},
                                "sealed": True})
    snapshot_event_id = f"p5:{_attr(pickup, 'scenario_seed', default=0)}:{minute}:snapshot"
    append_event(scene_id, {"event_type": "P5_WORLD_SNAPSHOT", "event_id": snapshot_event_id,
                            "typed_args": {"minute": minute, "callback_event_ids": callback_event_ids,
                                           "snapshot": snapshots}, "sealed": True})
    completed = list(_attr(pickup, "p5_completed_minutes", category="native_p5", default=[]))
    if minute != (max(completed) + 1 if completed else 0):
        raise ValueError("P5 completed-minute frontier must advance consecutively")
    completed.append(minute)
    _set(pickup, "p5_completed_minutes", completed)
    _set(pickup, "p5_snapshot_coverage_minute", minute)
    ledger = list(_attr(pickup, "p4_ledger", default=[]))
    unsealed = [row.get("event_id") for row in ledger
                if int(row.get("minute", -1)) == minute and row.get("sealed") is not True]
    if not unsealed:
        _set(pickup, "p5_event_coverage_minute", minute)
    event_frontier = int(_attr(pickup, "p5_event_coverage_minute", category="native_p5", default=0))
    return {"minute": minute, "completed": True, "event_complete": not unsealed,
            "unsealed_event_ids": unsealed, "snapshot": snapshots,
            "callback_event_ids": callback_event_ids,
            "trace_frontier": {"events_through": event_frontier, "values_through": minute}}


def _project_tool_transfer_events(scene_id, minute, pickup, rows, actors, append_event):
    """Publish witnessed loan/return facts only from exact settled give receipts."""
    content = _plain_json(_attr(pickup, "p5_station_content_v1", category="native_p5", default={}))
    tool_id = content.get("tool_id")
    if type(tool_id) is not int:
        return
    actor_alias_by_id = {int(actor.id): alias for alias, actor in actors.items()}
    by_id = {int(obj.id): obj for obj in rows}
    tool = by_id.get(tool_id)
    if tool is None:
        return
    seen = set(_plain_json(_attr(pickup, "p5_station_meta", category="native_p5", default={})
                           .get("projected_tool_receipt_ids", [])))
    for alias, actor in actors.items():
        receipts = _plain_json(_attr(actor, "native_receipts", default=[]))
        commitments = _plain_json(_attr(actor, "ongoing_commitments", category="native_p5", default=[]))
        for receipt in receipts:
            receipt_id = receipt.get("receipt_id")
            kind = receipt.get("ongoing_task_kind")
            if (not receipt_id or receipt_id in seen or receipt.get("settled") is not True
                    or receipt.get("kind") != "give" or receipt.get("item_id") != tool_id
                    or kind not in {"lend_tool", "return_tool"}):
                continue
            commitment = next((item for item in commitments
                               if item.get("commitment_id") == receipt.get("ongoing_commitment_id")), None)
            if not commitment or commitment.get("tool_id") != tool_id:
                continue
            recipient_alias = actor_alias_by_id.get(receipt.get("recipient_id"))
            if recipient_alias not in actors or receipt.get("recipient_id") is None:
                continue
            receipt_minute = receipt.get("sim_minute")
            if (type(receipt_minute) is not int
                    or tool_id not in receipt.get("before_inventory_ids", [])
                    or tool_id in receipt.get("after_inventory_ids", [])
                    or tool_id not in receipt.get("recipient_inventory_ids", [])
                    or receipt.get("before_room_id") != receipt.get("after_room_id")
                    or receipt.get("recipient_before_room_id") != receipt.get("before_room_id")
                    or receipt.get("recipient_after_room_id") != receipt.get("before_room_id")):
                continue
            if commitment.get("recipient_alias") != recipient_alias:
                continue
            due_minute = commitment.get("due_minute")
            if type(due_minute) is not int:
                continue
            active_loan = _plain_json(_attr(tool, "p5_station_active_loan", category="native_p5", default=None))
            if kind == "lend_tool":
                if isinstance(active_loan, Mapping) and active_loan.get("status") == "OUT":
                    continue
                lender_alias, borrower_alias = alias, recipient_alias
                loan_id = f"station-loan:{receipt_id}:{tool_id}"
                _set(tool, "p5_station_active_loan", {"loan_id": loan_id, "tool_id": tool_id,
                                                        "lender_alias": lender_alias,
                                                        "borrower_alias": borrower_alias,
                                                        "due_minute": due_minute,
                                                        "loan_receipt_id": receipt_id,
                                                        "loan_request_id": commitment.get("loan_request_id"),
                                                        "status": "OUT"})
                request_id = commitment.get("loan_request_id")
                if request_id:
                    for request_witness in (actors[lender_alias], actors[borrower_alias]):
                        current_request = _plain_json(_attr(request_witness,
                            "p5_station_loan_request", category="native_p5", default=None))
                        if isinstance(current_request, Mapping) and current_request.get("request_id") == request_id:
                            _set(request_witness, "p5_station_loan_request", None, category="native_p5")
                event_type = "P5_STATION_TOOL_LOANED"
                event_args = {"lender_alias": lender_alias, "borrower_alias": borrower_alias,
                              "tool_id": tool_id, "due_minute": due_minute, "loan_id": loan_id,
                              "receipt_id": receipt_id, "commitment_id": commitment["commitment_id"],
                              "outcome": "SETTLED"}
            else:
                if (not isinstance(active_loan, Mapping) or active_loan.get("status") != "OUT"
                        or active_loan.get("borrower_alias") != alias
                        or active_loan.get("lender_alias") != recipient_alias
                        or active_loan.get("due_minute") != due_minute):
                    continue
                # Receipts can be encountered after later callbacks; event time
                # is the physical give boundary, never the projection pass.
                returned_minute = receipt_minute
                outcome = "ON_TIME" if returned_minute <= int(active_loan["due_minute"]) else "LATE"
                loan_id = str(active_loan["loan_id"])
                lender_alias, borrower_alias = recipient_alias, alias
                _set(tool, "p5_station_active_loan", {**active_loan, "status": "RETURNED",
                                                       "returned_minute": returned_minute,
                                                       "return_receipt_id": receipt_id,
                                                       "outcome": outcome})
                event_type = "P5_STATION_TOOL_RETURNED"
                event_args = {"lender_alias": lender_alias, "borrower_alias": borrower_alias,
                              "tool_id": tool_id, "due_minute": due_minute,
                              "returned_minute": returned_minute, "loan_id": loan_id,
                              "receipt_id": receipt_id, "commitment_id": commitment["commitment_id"],
                              "outcome": outcome}
            append_event(scene_id, {"event_type": event_type, "event_id": f"station:{receipt_id}",
                                    "typed_args": event_args, "receipt_id": receipt_id, "sealed": True})
            # Only actors whose location at the actual give receipt is
            # evidenced may retain the event as local knowledge.
            receipt_minute = receipt.get("sim_minute")
            witnesses = {alias}
            if (receipt.get("after_room_id") == receipt.get("before_room_id")
                    and receipt.get("recipient_before_room_id") == receipt.get("before_room_id")
                    and receipt.get("recipient_after_room_id") == receipt.get("before_room_id")):
                witnesses.add(recipient_alias)
            for witness_alias in witnesses:
                witness = actors[witness_alias]
                known = _plain_json(_attr(witness, "p5_station_known_tool_events",
                                          category="native_p5", default=[]))
                lender = actors[lender_alias]
                borrower = actors[borrower_alias]
                known.append({"event_type": event_type.lower(), "event_id": f"station:{receipt_id}",
                              "receipt_id": receipt_id, "loan_id": loan_id, "tool_id": tool_id,
                              "lender_id": int(lender.id), "borrower_id": int(borrower.id),
                              "lender_alias": lender_alias, "borrower_alias": borrower_alias,
                              "due_minute": due_minute,
                              **({"returned_minute": returned_minute, "outcome": outcome}
                                 if kind == "return_tool" else {"outcome": "SETTLED"}),
                              "settled": True, "witnessed_by_actor_id": int(witness.id),
                              "witnessed_by_alias": witness_alias,
                              "witnessed_minute": int(receipt_minute)})
                _set(witness, "p5_station_known_tool_events", known, category="native_p5")
            seen.add(receipt_id)
    meta = _plain_json(_attr(pickup, "p5_station_meta", category="native_p5", default={}))
    meta["projected_tool_receipt_ids"] = sorted(seen)
    _set(pickup, "p5_station_meta", meta, category="native_p5")


@_inline_callbacks
def _apply_intervention(scene_id, row, bundle):
    from twisted.internet import defer
    if not isinstance(row, Mapping):
        raise ValueError("P5 intervention row must be an object")
    if row.get("kind") == "author_opportunity":
        required = {"at", "kind", "operation", "opportunity_id"}
        if not required.issubset(row) or set(row) - required - {"candidate_guard"}:
            raise ValueError("author intervention rows require at/kind/operation/opportunity_id")
        action = row["opportunity_id"]
        if row["operation"] != "open_passage" or action not in world.ROUTE_ACTIONS:
            raise ValueError("unsupported P5 author intervention or route action")
        guard = row.get("candidate_guard")
        if guard is not None:
            pickup, _ = _scene_objects(scene_id)
            current_now = int(_attr(pickup, "p4_clock")["now"])
            current_events = int(_attr(pickup, "p5_event_coverage_minute", category="native_p5", default=0))
            current_values = int(_attr(pickup, "p5_snapshot_coverage_minute", category="native_p5", default=0))
            guard_valid = _candidate_guard_matches(
                guard, scene_id=scene_id, bundle_version=bundle.version, now=current_now,
                events_through=current_events, values_through=current_values,
                action=action, opportunity_id=row["opportunity_id"])
            if not guard_valid:
                result = {"settled": False, "status": "STALE_CANDIDATE",
                          "reason": "scene, author version, next-minute boundary, or sealed frontier changed",
                          "candidate_guard": _plain_json(guard),
                          "current": {"scene_id": scene_id, "bundle_version": bundle.version,
                                      "now": current_now, "events_through": current_events,
                                      "values_through": current_values,
                                      "selected_action": action,
                                      "opportunity_id": row["opportunity_id"]}}
                provenance = "stale_planner_candidate"
                command_receipt = None
                from tools.native_platform_v0.p3.p4_world import append_event
                append_event(scene_id, {"event_type": "P5_INTERVENTION",
                                        "event_id": f"p5:{_attr(pickup, 'scenario_seed', default=0)}:{row['at']}:intervention:{provenance}",
                                        "typed_args": {"kind": provenance, "intervention": dict(row),
                                                       "settlement": result, "command_receipt": None,
                                                       "bundle_version": bundle.version}, "sealed": True})
                defer.returnValue(result)
        actor = next(obj for obj in _scene_objects(scene_id)[1]
                     if _attr(obj, "p5_actor_alias", category="native_p5") == "A")
        result = world.activate_opportunity(scene_id, actor, action, bundle,
                                           expected_version=bundle.version)
        provenance = "author_opportunity"
        command_receipt = None
    elif row.get("kind") == "station_request_tool_loan":
        required = {"at", "kind", "tool_id", "lender_alias", "borrower_alias", "due_minute"}
        if (set(row) != required or type(row.get("at")) is not int
                or row.get("lender_alias") != "A" or row.get("borrower_alias") != "B"):
            raise ValueError("station_request_tool_loan requires exact registered A/B request fields")
        if type(row.get("tool_id")) is not int or type(row.get("due_minute")) is not int:
            raise ValueError("station loan request requires exact tool id and absolute integer due minute")
        pickup, rows = _scene_objects(scene_id)
        content = _attr(pickup, "p5_station_content_v1", category="native_p5")
        if not isinstance(content, Mapping) or row["tool_id"] != content.get("tool_id"):
            raise ValueError("station loan request must use the exact registered tool")
        player = next((obj for obj in rows if _attr(obj, "p3_control_role") == "player"), None)
        if player is None:
            raise ValueError("generated P5 player is missing")
        command = (f"station-request-loan {row['tool_id']} A B {row['due_minute']}")
        yield defer.maybeDeferred(player.execute_cmd, command)
        result = _plain_json(_attr(player, "p5_station_last_loan_request_result",
                                   category="native_p5", default={}))
        request = result.get("request") if isinstance(result, Mapping) else None
        receipt = result.get("receipt") if isinstance(result, Mapping) else None
        settled = bool(isinstance(result, Mapping) and result.get("settled") is True
                       and isinstance(request, Mapping)
                       and request.get("tool_id") == row["tool_id"]
                       and request.get("lender_alias") == "A"
                       and request.get("borrower_alias") == "B"
                       and request.get("due_minute") == row["due_minute"]
                       and request.get("requested_minute") == int(row["at"]))
        command_receipt = {"actor_id": int(player.id), "actor_alias": "player",
                           "operation": "station-request-loan", "submitted_command": command,
                           "request": request, "receipt": receipt, "settled": settled,
                           "provenance": "native_player_station_request_command"}
        result = {"settled": settled,
                  "status": "REQUESTED" if settled else "WORLD_VALIDATION_REJECTED",
                  "reason": None if settled else result.get("reason", "request command did not settle"),
                  "request": request, "receipt": receipt}
        provenance = "native_player_station_request_command"
    elif row.get("kind") == "player_command":
        if set(row) != {"at", "kind", "operation", "item_alias"}:
            raise ValueError("player interventions require at/kind/operation/item_alias")
        operation, item_alias = row["operation"], row["item_alias"]
        story_enabled = _attr(_scene_objects(scene_id)[0], "p5_story_request", category="native_p5") is not None
        station_enabled = _attr(_scene_objects(scene_id)[0], "p5_station_content_v1", category="native_p5") is not None
        allowed_items = ({"courier_supply", "resident_parcel"} |
                         ({"note"} if story_enabled else set()) |
                         ({"shared_station_tool", "station_tool"} if station_enabled else set()))
        if operation not in {"get", "drop"} or item_alias not in allowed_items:
            raise ValueError("P5 player intervention supports only get/drop of a named generated item")
        _, rows = _scene_objects(scene_id)
        player = next((obj for obj in rows if _attr(obj, "p3_control_role") == "player"), None)
        physical_alias = "shared_station_tool" if item_alias == "station_tool" else item_alias
        item = next((obj for obj in rows if _attr(obj, "p5_item_alias", category="native_p5") == physical_alias), None)
        if player is None or item is None:
            raise ValueError("P5 generated player or intervention item is missing")
        command = f"{operation} {item.key}"
        before_location = int(item.location.id) if item.location else None
        before_inventory = [int(obj.id) for obj in player.contents]
        yield defer.maybeDeferred(player.execute_cmd, command)
        after_location = int(item.location.id) if item.location else None
        after_inventory = [int(obj.id) for obj in player.contents]
        settled = (item in player.contents if operation == "get" else
                   item.location and player.location and item.location.id == player.location.id
                   and item not in player.contents)
        command_receipt = {"actor_id": int(player.id), "actor_alias": "player",
                           "operation": operation, "submitted_command": command,
                           "item_id": int(item.id), "before_location_id": before_location,
                           "after_location_id": after_location,
                           "before_inventory_ids": before_inventory,
                           "after_inventory_ids": after_inventory, "settled": bool(settled),
                           "provenance": "native_player_command"}
        result = {"settled": bool(settled), "status": "SETTLED" if settled else "WORLD_VALIDATION_REJECTED",
                  "receipt": command_receipt}
        provenance = "player_native_command"
    elif row.get("kind") == "author_story_edit":
        if set(row) != {"at", "kind", "expected_version", "request"}:
            raise ValueError("author_story_edit requires at/kind/expected_version/request")
        from tools.native_platform_v0.p5.story_process.native import edit_story_request
        result = edit_story_request(scene_id, row["request"], row["expected_version"])
        provenance = "author_story_process_edit"
        command_receipt = None
    elif row.get("kind") == "activate_ongoing_station":
        if set(row) != {"at", "kind", "expected_version"}:
            raise ValueError("activate_ongoing_station requires at/kind/expected_version")
        from tools.native_platform_v0.p5.ongoing_station.controller import record_activation
        result = record_activation(scene_id, row["expected_version"], int(row["at"]))
        provenance = "ongoing_station_author_activation"
        command_receipt = None
    elif row.get("kind") == "edit_ongoing_station_author":
        if set(row) != {"at", "kind", "expected_version", "author"}:
            raise ValueError("edit_ongoing_station_author requires at/kind/expected_version/author")
        from tools.native_platform_v0.p5.ongoing_station.controller import record_edit
        result = record_edit(scene_id, row["author"], row["expected_version"], int(row["at"]))
        provenance = "ongoing_station_author_edit"
        command_receipt = None
    else:
        raise ValueError("unknown P5 intervention kind")
    pickup, _ = _scene_objects(scene_id)
    from tools.native_platform_v0.p3.p4_world import append_event
    append_event(scene_id, {"event_type": "P5_INTERVENTION",
                            "event_id": f"p5:{_attr(pickup, 'scenario_seed', default=0)}:{row['at']}:intervention:{provenance}",
                            "typed_args": {"kind": provenance, "intervention": dict(row),
                                           "settlement": result, "command_receipt": command_receipt,
                                           "bundle_version": bundle.version}, "sealed": True})
    defer.returnValue(result)


def _round_deferred(scene_id, intervention=None, edit=None):
    from twisted.internet import defer

    @defer.inlineCallbacks
    def execute():
        from tools.native_platform_v0.p3.p4_world import advance_clock, append_event
        from tools.native_platform_v0.p5.agency import step_actor
        from twisted.internet import defer as d

        pickup, rows = _scene_objects(scene_id)
        actor_callback = step_actor
        if _attr(pickup, "p5_story_request", category="native_p5") is not None:
            from tools.native_platform_v0.p5.story_process.actor import step_story_aware_actor
            actor_callback = step_story_aware_actor
        elif _attr(pickup, "p5_ongoing_station_profile", category="native_p5") is not None:
            from tools.native_platform_v0.p5.ongoing_station.controller import actor_callback as station_callback
            actor_callback = station_callback
        clock = advance_clock(scene_id)
        minute = int(clock["now"])
        edit_result = None
        if edit is not None:
            if not isinstance(edit, Mapping) or set(edit) != {"at", "raw_bundle", "expected_version"}:
                raise ValueError("P5 edit rows require exactly at/raw_bundle/expected_version")
            edit_result = edit_author_bundle(scene_id, edit["raw_bundle"], edit["expected_version"])
            append_event(scene_id, {"event_type": "P5_AUTHOR_EDIT_ATTEMPT",
                                    "event_id": f"p5:{_attr(pickup, 'scenario_seed', default=0)}:{minute}:edit:{edit['expected_version']}",
                                    "typed_args": {"expected_version": edit["expected_version"],
                                                   "result": edit_result}, "sealed": True})
        bundle = _bundle_for(pickup)
        intervention_result = (yield _apply_intervention(scene_id, intervention, bundle)
                               if intervention is not None else None)
        enabled = _attr(pickup, "p5_director_enabled", category="native_p5") is True
        director = _director(scene_id, bundle, enabled=enabled)
        actors = {str(_attr(obj, "p5_actor_alias", category="native_p5")): obj
                  for obj in rows if _attr(obj, "activity_profile") == world.PROFILE}
        actor_rows = []
        for alias in ("A", "B"):
            actor = actors[alias]
            log_before = list(_attr(actor, "log", default=[]))
            receipt_before = list(_attr(actor, "native_receipts", default=[]))
            # Preserve any existing P3 planned/executing primitive first. The
            # ongoing station arbitrates only when the native action slot is free.
            callback = (step_actor if actor_callback.__name__ == "actor_callback"
                        and isinstance(_attr(actor, "pending_action", category="native_p3"), Mapping)
                        else actor_callback)
            callback_result = yield d.maybeDeferred(callback, actor)
            log_after = list(_attr(actor, "log", default=[]))
            receipt_after = list(_attr(actor, "native_receipts", default=[]))
            actor_rows.append({"actor_alias": alias, "callback_result_type": type(callback_result).__name__,
                               "local_decisions": log_after[len(log_before):],
                               "native_receipts": receipt_after[len(receipt_before):],
                               "snapshot": _snapshot_actor(actor)})
        completed = _complete_minute(scene_id, minute)
        station_result = None
        if _attr(pickup, "p5_ongoing_station_profile", category="native_p5") is not None:
            from tools.native_platform_v0.p5.ongoing_station.controller import publish_after_seal
            station_result = publish_after_seal(scene_id, minute)
        story_result = None
        if _attr(pickup, "p5_story_request", category="native_p5") is not None:
            from tools.native_platform_v0.p5.story_process.native import build_sealed_state, apply_story_decision
            from tools.native_platform_v0.p5.story_process.model import load_request
            from tools.native_platform_v0.p5.story_process.planning import plan_story_process
            story_state = build_sealed_state(scene_id, minute)
            if story_state is not None:
                story_request = load_request(_plain_json(
                    _attr(pickup, "p5_story_request", category="native_p5")))
                strategy = _attr(pickup, "p5_story_strategy", category="native_p5", default="gtpyhop")
                story_decision = plan_story_process(story_request, story_state, strategy=strategy)
                queued = apply_story_decision(scene_id, story_state, story_decision)
                story_result = {"decision": story_decision, **queued,
                                "bound_note_id": story_request.objective.get("note_id"),
                                "effects_applied": False,
                                "controller_events": queued.get("controller_events", []),
                                "sealed_frontier": completed["trace_frontier"]}
            else:
                raw_request = load_request(_plain_json(
                    _attr(pickup, "p5_story_request", category="native_p5")))
                story_result = {"status": "WAITING_FOR_SEALED_NATIVE_NOTE_RESPONSE",
                                "bound_note_id": raw_request.objective.get("note_id"),
                                "effects_applied": False,
                                "sealed_frontier": completed["trace_frontier"],
                                "diagnostic": "no bound exact LoveNote with verified sealed SOCIAL_REQUEST and physical receipt"}
        bundle = _bundle_for(pickup)
        verdicts, trace = _current_verdicts(scene_id, bundle)
        defer.returnValue({"minute": minute, "edits": [edit_result] if edit_result else [],
                           "interventions": [] if intervention_result is None else [intervention_result],
                           **({"story_process": story_result} if story_result is not None else {}),
                           **({"ongoing_station": station_result} if station_result is not None else {}),
                           "director": director, "actor_steps": actor_rows,
                           "snapshot": completed["snapshot"], "minute_complete": True,
                           "event_complete": completed["event_complete"],
                           "unsealed_event_ids": completed["unsealed_event_ids"],
                           "trace_frontier": completed["trace_frontier"],
                           "verdicts": verdicts, "typed_trace": world.serialize_typed_trace(trace)})
    return execute()


def _evidence(scene_id, bundle):
    pickup, rows = _scene_objects(scene_id)
    verdicts, trace = _current_verdicts(scene_id, bundle)
    actors = [obj for obj in rows if _attr(obj, "activity_profile") == world.PROFILE]
    now = int(_attr(pickup, "p4_clock")["now"])
    frontier = min(int(_attr(pickup, "p5_event_coverage_minute", category="native_p5", default=0)),
                   int(_attr(pickup, "p5_snapshot_coverage_minute", category="native_p5", default=0)))
    reasons = []
    if now != int(_attr(pickup, "p5_horizon", category="native_p5")):
        reasons.append("horizon_not_reached")
    if frontier < int(_attr(pickup, "p5_horizon", category="native_p5")):
        reasons.append("sealed_prefix_short_of_horizon")
    for actor in actors:
        alias = _attr(actor, "p5_actor_alias", category="native_p5")
        if _attr(actor, "status") == "ERROR":
            reasons.append(f"actor_{alias}_error")
        pending = _attr(actor, "pending_action")
        if isinstance(pending, Mapping) and pending.get("status") == "executing":
            reasons.append(f"actor_{alias}_execution_in_doubt")
        if _attr(actor, "p4_social_status") in {"UNAVAILABLE", "SOCIAL_SETTLEMENT_PENDING",
                                                 "WORLD_SETTLEMENT_PENDING", "UNSUPPORTED_NATIVE_ACTION",
                                                 "STALE_NATIVE_PROPOSAL", "WORLD_VALIDATION_REJECTED"}:
            reasons.append(f"actor_{alias}_social_{_attr(actor, 'p4_social_status')}")
    event_frontier = int(_attr(pickup, "p5_event_coverage_minute", category="native_p5", default=0))
    value_frontier = int(_attr(pickup, "p5_snapshot_coverage_minute", category="native_p5", default=0))
    planning_frontier = min(event_frontier, value_frontier)
    planning = _director_planning_view(scene_id, bundle, now=now,
                                        verdicts_through_minute=planning_frontier)
    prefix_sealed = (event_frontier == value_frontier == now and any(
        isinstance(row, Mapping) and row.get("minute") == now
        for row in _attr(pickup, "p5_world_snapshots", category="native_p5", default=[])))
    story_evidence = None
    if _attr(pickup, "p5_story_request", category="native_p5") is not None:
        raw_story = _attr(pickup, "p5_story_meta", category="native_p5", default={})
        from tools.native_platform_v0.p5.story_process.model import load_request
        from tools.native_platform_v0.p5.story_process.native import build_sealed_state
        from tools.native_platform_v0.p5.story_process.planning import _typedir_monitor
        request = load_request(_plain_json(
            _attr(pickup, "p5_story_request", category="native_p5")))
        sealed_state = build_sealed_state(scene_id, now)
        story_evidence = {"schema": "story-process-native-evidence-v1",
                          "request": dict(request.raw),
                          "strategy": _attr(pickup, "p5_story_strategy", category="native_p5"),
                          "bound_note_id": request.objective.get("note_id"),
                          "controller_decisions": list(raw_story.get("controller_decisions", [])),
                          "controller_events": list(raw_story.get("controller_events", [])),
                          "pending_task_requests": list(raw_story.get("task_offers", [])),
                          "stale_future_request_ids": list(raw_story.get("stale_future_request_ids", [])),
                          "actor_tasks": [{"actor_alias": _attr(actor, "p5_actor_alias", category="native_p5"),
                                           "task": deepcopy(_attr(actor, "p5_story_task", category="native_p5"))}
                                          for actor in actors],
                          "receipts": list(raw_story.get("receipts", [])),
                          "real_verdicts": (_typedir_monitor(request, sealed_state)
                                            if sealed_state is not None else [{
                                                "verdict": "NOT_SATISFIED",
                                                "status": "NO_NATIVE_NOTE_EVIDENCE",
                                                "request_id": request.request_id,
                                                "sealed_frontier": now,
                                                "reason": "the exact LoveNote has not been physically created, delivered, and sealed"}]),
                          "controller_authored_npc_task_requests": int(raw_story.get(
                              "controller_authored_npc_task_requests", 0)),
                          "controller_authored_npc_commands": int(raw_story.get(
                              "controller_authored_npc_commands", 0)),
                          "execution_authority": "native_actor_callback_only"}
    station_evidence = None
    if _attr(pickup, "p5_ongoing_station_profile", category="native_p5") is not None:
        from tools.native_platform_v0.p5.ongoing_station.controller import evidence as station_evidence_for
        station_evidence = station_evidence_for(scene_id, now)
    return {"evidence_schema": "p5-live-trace-v1",
            "source": "native_platform_v0.p5.service._evidence",
            "prefix_status": "SEALED_COMPLETE" if prefix_sealed else "INCOMPLETE",
            "bundle_identity": {"bundle_id": bundle.bundle_id, "version": bundle.version,
                                "sha256": _bundle_sha256(bundle)},
            "scene_id": scene_id, "now": now,
            "horizon": int(_attr(pickup, "p5_horizon", category="native_p5")),
            "complete_through": {"events": int(_attr(pickup, "p5_event_coverage_minute", category="native_p5", default=0)),
                                  "values": int(_attr(pickup, "p5_snapshot_coverage_minute", category="native_p5", default=0))},
            "run_status": "COMPLETE" if not reasons else "INCOMPLETE",
            "incomplete_reasons": reasons,
            "pending_future_nonexecuted": {
                _attr(actor, "p5_actor_alias", category="native_p5"): _pending_identity(actor)
                for actor in actors if isinstance(_attr(actor, "pending_action"), Mapping)
                and _attr(actor, "pending_action").get("status") == "planned"},
            "controller_authored_npc_commands": (story_evidence["controller_authored_npc_commands"]
                                                  if story_evidence else 0),
            **({"story_process": story_evidence} if story_evidence is not None else {}),
            **({"ongoing_station": station_evidence} if station_evidence is not None else {}),
            "verdicts": verdicts, "typed_trace": world.serialize_typed_trace(trace),
            "ledger": list(_attr(pickup, "p4_ledger", default=[])),
            "world_snapshots": list(_attr(pickup, "p5_world_snapshots", category="native_p5", default=[])),
            "actor_evidence": [_snapshot_actor(obj) for obj in rows
                               if _attr(obj, "activity_profile") == world.PROFILE],
            "world_capability_projection": _planner_scene_binding(scene_id),
            "planning_view": {
                "schema": "p5-native-planning-view-v1",
                "source": "native_platform_v0.p5.service._director_planning_view",
                "scene_id": scene_id,
                "based_on_minute": now,
                "bundle_identity": {"bundle_id": bundle.bundle_id,
                                    "version": bundle.version,
                                    "sha256": _bundle_sha256(bundle)},
                "frontiers": {"events_through": event_frontier,
                              "values_through": value_frontier},
                "state": planning["state"]}}


def get_trace(scene_id):
    pickup, _ = _scene_objects(scene_id)
    return _evidence(scene_id, _bundle_for(pickup))


def step_world(scene_id, rounds=1, *, interventions=(), edits=()):
    from twisted.internet import defer

    if type(rounds) is not int or not 1 <= rounds <= 50:
        raise ValueError("P5 rounds must be an integer in [1,50]")
    interventions = list(interventions)
    edits = list(edits)
    @defer.inlineCallbacks
    def execute():
        results = []
        for _ in range(rounds):
            pickup, _rows = _scene_objects(scene_id)
            now = int(_attr(pickup, "p4_clock")["now"])
            horizon = int(_attr(pickup, "p5_horizon", category="native_p5"))
            if now >= horizon:
                raise ValueError("P5 scenario has reached its authored horizon")
            next_minute = now + 1
            edit_rows = [row for row in edits if row.get("at") == next_minute]
            intervention_rows = [row for row in interventions if row.get("at") == next_minute]
            if len(edit_rows) > 1 or len(intervention_rows) > 1:
                raise ValueError("at most one P5 bundle edit and intervention may occur per minute")
            row = yield _round_deferred(scene_id,
                                        intervention_rows[0] if intervention_rows else None,
                                        edit_rows[0] if edit_rows else None)
            results.append(row)
        pickup, _rows = _scene_objects(scene_id)
        active = _bundle_for(pickup)
        defer.returnValue({"scene_id": scene_id, "rounds": results, "final": _evidence(scene_id, active),
                           "incomplete_reason": None})
    return execute()


def run_p5_scenario(*, owner, bundle, initial_social_preset, horizon, interventions=(), edits=(),
                    director_enabled=True, seed=0, shared_supply=False, initial_main_open=True,
                    story_process=None, story_strategy="gtpyhop", ongoing_station=None):
    from twisted.internet import defer

    created = reset_p5_scenario(owner=owner, bundle=bundle,
                                initial_social_preset=initial_social_preset, horizon=horizon,
                                seed=seed, director_enabled=director_enabled,
                                shared_supply=shared_supply, initial_main_open=initial_main_open,
                                story_process=story_process, story_strategy=story_strategy,
                                ongoing_station=ongoing_station)
    if isinstance(created, Mapping) and created.get("ok") is False:
        return dict(created)
    @defer.inlineCallbacks
    def execute():
        run = yield step_world(created["scene_id"], rounds=horizon,
                               interventions=interventions, edits=edits)
        defer.returnValue({"ok": True, "scene": created, **run,
                           "run_status": run["final"]["run_status"],
                           "controller_authored_npc_commands": 0})
    return execute()


__all__ = ["reset_p5_scenario", "edit_author_bundle", "step_world", "get_trace", "run_p5_scenario"]

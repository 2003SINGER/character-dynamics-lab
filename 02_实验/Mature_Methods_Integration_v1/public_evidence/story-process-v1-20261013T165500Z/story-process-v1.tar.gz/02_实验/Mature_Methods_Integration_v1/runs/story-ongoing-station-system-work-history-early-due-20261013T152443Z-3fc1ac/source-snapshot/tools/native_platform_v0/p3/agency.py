"""Local observation, explicit goal arbitration, and bounded actor-step control.

Evennia remains the only world and receipt authority. This module never queries
ObjectDB or accepts the world object as a planner input.
"""

from copy import deepcopy
from datetime import datetime, timezone
import threading
from collections.abc import Mapping

from .planning import freeze, plan_next, plan_patrol, thaw

CATEGORY = "native_p3"
_SOCIAL_CLIENTS = {}
_SOCIAL_CLIENTS_LOCK = threading.RLock()


def _get(obj, key, default=None):
    return obj.attributes.get(key, category=CATEGORY, default=default)


def _station_get(obj, key, default=None):
    return obj.attributes.get(key, category="native_p5", default=default)


def _set(obj, key, value):
    obj.attributes.add(key, value, category=CATEGORY)


def _append(actor, event):
    log = list(_get(actor, "log", []))
    log.append(event)
    _set(actor, "log", log)


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _obj_ref(obj):
    return {"id": obj.id, "dbref": obj.dbref, "key": obj.key}


def observe_actor(actor):
    """Build O from own inventory, current room, visible exits/items, and memory.

    The assigned task identifiers are authored task metadata. Item location is
    refreshed only when the assigned item is visible locally or in own inventory.
    """
    room = actor.location
    if room is None:
        raise ValueError("actor has no current room")

    item_id = _get(actor, "task_item_id")
    destination_id = _get(actor, "task_destination_id")
    activity_profile = _get(actor, "activity_profile", "legacy_delivery_v0")
    delivery_task = _get(actor, "delivery_task", True)
    inventory = [_obj_ref(obj) for obj in actor.contents]
    visible_items = []
    current_exit_rows = []
    p4_profile = activity_profile in ("p4_story_v0", "p5_story_v0")
    for obj in room.contents:
        if obj.id == actor.id:
            continue
        if obj.access(actor, "view", default=True):
            visible_items.append({**_obj_ref(obj), "room_id": room.id})
    for edge in room.exits:
        destination = getattr(edge, "destination", None)
        if destination is not None and edge.access(actor, "view", default=True):
            exit_row = {"key": edge.key, "destination_id": destination.id,
                        "destination_dbref": destination.dbref}
            if p4_profile:
                exit_row["traversable"] = bool(edge.access(actor, "traverse", default=True))
            current_exit_rows.append(exit_row)

    # Retain only observed edges and sightings. No global world lookup occurs here.
    knowledge = deepcopy(_get(actor, "witnessed", {"edges": {}, "objects": {}}))
    room_edges = knowledge["edges"].setdefault(str(room.id), {})
    for edge in current_exit_rows:
        room_edges[str(edge["destination_id"])] = edge["key"]
    if p4_profile:
        traversability = knowledge.setdefault("traversability", {})
        room_traversability = traversability.setdefault(str(room.id), {})
        for edge in current_exit_rows:
            room_traversability[str(edge["destination_id"])] = edge["traversable"]
    observed_item = next((row for row in visible_items if item_id is not None and row["id"] == item_id), None)
    held_item = next((row for row in inventory if item_id is not None and row["id"] == item_id), None)
    if item_id is None:
        item_location = None
        task_item = {"id": None, "key": None}
    elif observed_item:
        old = knowledge["objects"].get(str(item_id), {})
        if old.get("room_id") != room.id or old.get("key") != observed_item["key"] or old.get("status") != "seen":
            knowledge["objects"][str(item_id)] = {"room_id": room.id, "key": observed_item["key"],
                                                 "last_seen_at": _stamp(), "status": "seen"}
    elif held_item:
        old = knowledge["objects"].get(str(item_id), {})
        if old.get("room_id") != "inventory" or old.get("key") != held_item["key"] or old.get("status") != "held":
            knowledge["objects"][str(item_id)] = {"room_id": "inventory", "key": held_item["key"],
                                                 "last_seen_at": _stamp(), "status": "held"}
    elif item_knowledge := knowledge["objects"].get(str(item_id)):
        if item_knowledge.get("room_id") == room.id:
            item_knowledge.update({"room_id": None, "status": "not_visible_in_last_seen_room",
                                   "absence_observed_at": _stamp()})

    if item_id is not None:
        item_knowledge = knowledge["objects"].get(str(item_id), {})
        item_location = (room.id if observed_item else None if held_item else
                         item_knowledge.get("room_id") if isinstance(item_knowledge.get("room_id"), int) else None)
    exits = list(current_exit_rows)
    known_exits = {int(source): tuple(int(destination) for destination in rows)
                   for source, rows in knowledge["edges"].items()}
    if item_id is not None:
        task_item = {"id": item_id, "key": (observed_item or held_item or {}).get(
            "key", _get(actor, "task_item_key"))}
    own_delivery_receipts = list(_get(actor, "native_receipts", []))
    delivered = bool(observed_item and room.id == destination_id)
    if activity_profile == "p5_story_v0":
        # A player placing an item at its destination is visible W state, not
        # proof that this actor completed its assigned task.
        delivered = any(
            row.get("kind") == "drop" and row.get("settled") is True
            and str(row.get("item_id")) == str(item_id)
            and row.get("after_item_room_id") == destination_id
            for row in own_delivery_receipts
        )
    observation = {
        "room_id": room.id,
        "inventory": inventory,
        "visible_items": visible_items,
        "task_item": task_item,
        "task_destination": destination_id,
        "item_location": item_location,
        "item_held": held_item is not None,
        "delivered": delivered,
        "own_delivery_receipts": own_delivery_receipts,
        "known_exits": known_exits,
        "exits": exits,
        "witnessed": [{"room_id": room.id, "kind": "current_room", "dbref": room.dbref}],
        "retained_witnesses": list(knowledge["objects"].values()),
    }
    if activity_profile == "p5_story_v0" and _station_get(actor, "p5_station_profile_enabled", False):
        # Station capabilities are projected only from this actor's room and
        # inventory. No scene-wide object lookup or peer receipt feed occurs.
        local_ids = {int(row["id"]) for row in visible_items + inventory}
        station_tools = []
        station_supplies = []
        station_storages = []
        station_repair_targets = []
        station_peers = []
        for obj in (*room.contents, *actor.contents):
            if int(obj.id) not in local_ids or not obj.access(actor, "view", default=True):
                continue
            if _station_get(obj, "p5_station_tool") is True:
                lease = _station_get(obj, "p5_station_tool_lease", {})
                loan = _station_get(obj, "p5_station_active_loan")
                tool_room = room if obj in actor.contents else obj.location
                station_tools.append({"id": int(obj.id), "room_id": int(tool_room.id) if tool_room else None,
                                      "visible": obj in room.contents, "held_by_actor_id": int(actor.id) if obj in actor.contents else None,
                                      "lease_status": lease.get("status"),
                                      "workbench_room_id": _station_get(obj, "p5_station_workbench_room_id"),
                                      "loan": deepcopy(loan) if isinstance(loan, Mapping) else None})
            if _station_get(obj, "p5_supply_inspection_status") is not None:
                station_supplies.append({"id": int(obj.id), "room_id": int(obj.location.id) if obj.location else None,
                                         "visible": obj in room.contents, "held_by_actor_id": int(actor.id) if obj in actor.contents else None,
                                         "inspection_status": _station_get(obj, "p5_supply_inspection_status")})
            if _station_get(obj, "p5_station_storage") is True:
                station_storages.append({"id": int(obj.id), "room_id": int(obj.location.id) if obj.location else None,
                                         "visible": True})
        for exit_obj in room.exits:
            if _station_get(exit_obj, "p5_repair_target") is True and exit_obj.access(actor, "view", default=True):
                station_repair_targets.append({"id": int(exit_obj.id), "room_id": int(room.id),
                                               "key": str(exit_obj.key),
                                               "alias": _station_get(exit_obj, "p5_exit_alias"),
                                               "destination_id": int(exit_obj.destination.id) if exit_obj.destination else None,
                                               "traversable": bool(exit_obj.access(actor, "traverse", default=True)),
                                               "last_repair_receipt": thaw(_station_get(
                                                   exit_obj, "p5_last_repair_receipt"))})
        for peer in room.contents:
            if peer is actor or _get(peer, "p3_scene_id") != _get(actor, "p3_scene_id"):
                continue
            alias = _station_get(peer, "p5_actor_alias")
            if alias in {"A", "B"}:
                station_peers.append({"id": int(peer.id), "alias": alias, "room_id": int(room.id),
                                      "visible": bool(peer.access(actor, "view", default=True))})
        observation.update({"station_tools": station_tools, "station_supplies": station_supplies,
                            "station_storages": station_storages,
                            "station_repair_targets": station_repair_targets,
                            "station_peers": station_peers,
                            "station_task_bindings": thaw(_station_get(actor, "p5_station_task_bindings", [])),
                            "station_loan_request": thaw(_station_get(actor, "p5_station_loan_request")),
                            "known_tool_events": thaw(_station_get(actor, "p5_station_known_tool_events", []))})
    if p4_profile:
        observation["known_traversability"] = {
            int(source): {int(destination): bool(value) for destination, value in rows.items()}
            for source, rows in knowledge.get("traversability", {}).items()
        }
    view = {
        "actor_id": actor.id,
        "activity_contract": {"profile": activity_profile, "delivery_task": delivery_task,
                               "source": "scenario-authored-activity-profile"},
        "goal_contract": {"goal": _get(actor, "goal", "deliver_supply"), "item_id": item_id,
                           "destination_id": destination_id, "source": "scenario-authored-task"},
        "observation": observation,
    }
    _set(actor, "witnessed", knowledge)
    previous = _get(actor, "last_observation")
    _set(actor, "last_observation", deepcopy(view))
    if previous != view:
        _append(actor, {"at": _stamp(), "kind": "observation", "room": room.dbref,
                        "visible_item_ids": [row["id"] for row in visible_items],
                        "inventory_ids": [row["id"] for row in inventory],
                        "visible_exit_keys": [row["key"] for row in exits]})
    return freeze(view)


def choose_goal(local_view):
    """Apply the opt-in fixed-priority activity rule; this is not learned utility."""
    view = local_view
    goal = view["goal_contract"]["goal"]
    profile = view.get("activity_contract", {}).get("profile", "legacy_delivery_v0")
    delivery_task = view.get("activity_contract", {}).get("delivery_task", True) is True
    if profile not in ("legacy_delivery_v0", "delivery_patrol_v0",
                       "delivery_patrol_recovery_v0"):
        return {"goal": None, "reason": "unsupported activity profile", "rule": "p3-authored-goal-v0",
                "status": "UNSUPPORTED_PROFILE", "candidates": [], "choice": None,
                "inputs": {"profile": profile, "delivery_task": delivery_task}}
    if profile == "legacy_delivery_v0" and not delivery_task:
        return {"goal": None, "reason": "delivery task was cancelled; patrol is not enabled in the legacy profile",
                "rule": "p3-authored-goal-v0", "status": "NO_TASK", "candidates": [], "choice": None,
                "inputs": {"profile": profile, "delivery_task": False}}
    if goal != "deliver_supply":
        return {"goal": None, "reason": "no supported authored task", "rule": "p3-authored-goal-v0",
                "status": "NO_TASK", "candidates": [], "choice": None,
                "inputs": {"profile": profile, "delivery_task": delivery_task}}
    observation = view["observation"]
    own_receipt = bool(observation["task_item"].get("id") is not None and any(
                      row.get("kind") == "drop" and row.get("settled") and
                      str(row.get("item_id")) == str(observation["task_item"]["id"]) and
                      row.get("after_item_room_id") == observation["task_destination"]
                      for row in observation["own_delivery_receipts"]))
    if profile == "delivery_patrol_v0":
        candidates = ["deliver_supply", "patrol"] if delivery_task and not own_receipt else ["patrol"]
        if delivery_task and not own_receipt:
            reason = ("delivery outranks patrol until this actor has its own matching settled drop receipt; "
                      "visible destination state alone does not complete the task")
            return {"goal": "deliver_supply", "reason": reason,
                    "rule": "delivery_before_patrol_v0", "status": "ACTIVE",
                    "candidates": candidates, "choice": "deliver_supply",
                    "inputs": {"profile": profile, "delivery_task": True,
                               "own_delivery_receipt": False}}
        reason = ("matching settled drop receipt permanently completes this actor's delivery task"
                  if own_receipt else "no active delivery task; use the opt-in patrol activity")
        return {"goal": "patrol", "reason": reason, "rule": "delivery_before_patrol_v0",
                "status": "ACTIVE", "candidates": candidates, "choice": "patrol",
                "inputs": {"profile": profile, "delivery_task": delivery_task,
                           "own_delivery_receipt": own_receipt}}
    if profile == "delivery_patrol_recovery_v0":
        item_id = observation["task_item"].get("id")
        item_location = observation.get("item_location")
        item_held = observation.get("item_held") is True
        item_currently_visible = bool(item_id is not None and any(
            str(row.get("id")) == str(item_id) for row in observation.get("visible_items", ())))
        binding_valid = item_id is not None and observation.get("task_destination") is not None
        available_under_local_observation = item_held or item_currently_visible or item_location is not None
        local_evidence = {
            "assigned_item_id": item_id,
            "destination_id": observation.get("task_destination"),
            "item_held": item_held,
            "item_currently_visible": item_currently_visible,
            "retained_item_location": item_location,
            "binding_valid": binding_valid,
            "own_delivery_receipt": own_receipt,
        }
        if not delivery_task:
            return {"goal": "patrol", "reason": "delivery task was cancelled; use the opt-in patrol activity",
                    "rule": "delivery_before_patrol_recovery_v0", "status": "ACTIVE",
                    "candidates": ["patrol"], "choice": "patrol",
                    "delivery_status": "CANCELLED",
                    "delivery_reason": "delivery_task is false in the authored activity contract",
                    "local_evidence": local_evidence,
                    "inputs": {"profile": profile, "delivery_task": False,
                               "delivery_status": "CANCELLED", "local_evidence": local_evidence}}
        if own_receipt:
            return {"goal": "patrol", "reason": "matching settled drop receipt permanently completes this actor's delivery task",
                    "rule": "delivery_before_patrol_recovery_v0", "status": "ACTIVE",
                    "candidates": ["deliver_supply", "patrol"], "choice": "patrol",
                    "delivery_status": "SETTLED",
                    "delivery_reason": "this actor has its own matching settled drop receipt",
                    "local_evidence": local_evidence,
                    "inputs": {"profile": profile, "delivery_task": True,
                               "delivery_status": "SETTLED", "local_evidence": local_evidence}}
        if not binding_valid:
            return {"goal": "deliver_supply", "reason": "delivery binding is invalid; keep delivery selected so the planner reports the binding failure",
                    "rule": "delivery_before_patrol_recovery_v0", "status": "ACTIVE",
                    "candidates": ["deliver_supply", "patrol"], "choice": "deliver_supply",
                    "delivery_status": "INVALID_BINDING",
                    "delivery_reason": "assigned item or destination is missing from the actor-local task contract",
                    "local_evidence": local_evidence,
                    "inputs": {"profile": profile, "delivery_task": True,
                               "delivery_status": "INVALID_BINDING", "local_evidence": local_evidence}}
        if not available_under_local_observation:
            return {"goal": "patrol", "reason": "assigned item is absent from current local observation and has no retained last-known room; patrol while reobserving",
                    "rule": "delivery_before_patrol_recovery_v0", "status": "ACTIVE",
                    "candidates": ["deliver_supply", "patrol"], "choice": "patrol",
                    "delivery_status": "SUSPENDED_LOCAL_ITEM_UNAVAILABLE",
                    "delivery_reason": "temporary suspension is derived only from actor-local absence evidence",
                    "local_evidence": local_evidence,
                    "inputs": {"profile": profile, "delivery_task": True,
                               "delivery_status": "SUSPENDED_LOCAL_ITEM_UNAVAILABLE",
                               "local_evidence": local_evidence}}
        return {"goal": "deliver_supply", "reason": "assigned item is available in own inventory, current visibility, or retained witnessed location; GTPyhop continues delivery",
                "rule": "delivery_before_patrol_recovery_v0", "status": "ACTIVE",
                "candidates": ["deliver_supply", "patrol"], "choice": "deliver_supply",
                "delivery_status": "ACTIVE",
                "delivery_reason": "delivery has priority while local evidence supports item availability",
                "local_evidence": local_evidence,
                "inputs": {"profile": profile, "delivery_task": True,
                           "delivery_status": "ACTIVE", "local_evidence": local_evidence}}
    if own_receipt:
        return {"goal": None, "reason": "this actor has a settled drop receipt for the assigned item and destination",
                "rule": "p3-authored-goal-v0", "status": "ACTOR_DELIVERY_SETTLED",
                "candidates": ["deliver_supply"], "choice": None,
                "inputs": {"profile": profile, "delivery_task": delivery_task,
                           "own_delivery_receipt": True}}
    if observation["delivered"]:
        return {"goal": None, "reason": "world goal is visibly satisfied, but no actor drop receipt proves who delivered it",
                "rule": "p3-authored-goal-v0", "status": "WORLD_GOAL_SATISFIED_EXTERNAL",
                "candidates": ["deliver_supply"], "choice": None,
                "inputs": {"profile": profile, "delivery_task": delivery_task,
                           "own_delivery_receipt": False}}
    return {"goal": goal, "reason": "continue the scenario-authored delivery objective",
            "rule": "p3-authored-goal-v0", "status": "ACTIVE",
            "candidates": ["deliver_supply"], "choice": goal,
            "inputs": {"profile": profile, "delivery_task": delivery_task,
                       "own_delivery_receipt": False}}


def make_decision(actor):
    """Observe, arbitrate, and propose at most one delivery or patrol primitive."""
    view = observe_actor(actor)
    choice = choose_goal(view)
    if choice["goal"] is None:
        return {"view": view, "goal": choice, "planner": None, "intent": None}
    if choice["goal"] == "patrol":
        observation = view["observation"]
        signature = sorted((str(edge["key"]), int(edge["destination_id"]))
                           for edge in observation.get("exits", ()))
        state = get_value(actor, "patrol_rejected_state")
        saved_signature = (sorted((str(row[0]), int(row[1])) for row in state.get("exits", ()))
                           if state else None)
        if not state or state.get("room_id") != observation["room_id"] or saved_signature != signature:
            state = {"room_id": observation["room_id"], "exits": signature, "rejected": []}
            set_value(actor, "patrol_rejected_state", state)
        rejected = [(str(row[0]), int(row[1])) for row in state.get("rejected", ())]
        planned = plan_patrol(view, rejected)
    else:
        planned = plan_next(view, choice["goal"])
    return {"view": view, "goal": choice, "planner": planned, "intent": planned.get("intent")}


def record(actor, event):
    _append(actor, {"at": _stamp(), **event})


def set_value(actor, key, value):
    _set(actor, key, value)


def get_value(actor, key, default=None):
    return _get(actor, key, default)


def _visible_item_in_room(actor, item_id):
    room = actor.location
    if not room:
        return None
    return next((obj for obj in room.contents
                 if obj.id == item_id and obj.access(actor, "view", default=True)), None)


def _dispatch_pending(actor, pending):
    """Run one native command and settle only from the resulting Evennia state."""
    operation = pending["intent"]
    view = thaw(pending["view"])
    ongoing_task = pending.get("ongoing_task") or {}
    item_id = ongoing_task.get("item_id", view["goal_contract"].get("item_id"))
    before_room = actor.location.id if actor.location else None
    before_inventory = [obj.id for obj in actor.contents]
    before_item_room = before_room if item_id is not None and _visible_item_in_room(actor, item_id) else None
    command = None
    rejection = None
    if operation["operator"] == "move":
        edge = next((ex for ex in actor.location.exits if ex.key == operation["exit_key"]
                     and ex.destination and ex.destination.id == operation["destination_id"]), None) if actor.location else None
        if edge is None:
            rejection = "observed exit is no longer available"
        else:
            command = edge.key
    elif operation["operator"] == "get":
        target = _visible_item_in_room(actor, item_id)
        if target is None:
            profile = view.get("activity_contract", {}).get("profile")
            prior_item = view.get("observation", {}).get("task_item", {})
            if ongoing_task.get("item_key"):
                prior_item = {**prior_item, "key": ongoing_task["item_key"]}
            is_recovery_profile = profile == "delivery_patrol_recovery_v0"
            is_native_scene_profile = profile in ("p4_story_v0", "p5_story_v0")
            allows_native_missing_get = is_recovery_profile or is_native_scene_profile
            was_locally_visible = any(
                str(row.get("id")) == str(item_id)
                for row in view.get("observation", {}).get("visible_items", ())
            )
            # For C1 recovery evidence, let Evennia's ordinary local `get <key>`
            # validation reject a formerly visible item that disappeared after
            # planning. Never use a dbref/global search, and refuse ambiguous
            # same-key substitutes rather than taking another object's item.
            same_key_objects = ([obj for obj in actor.location.contents
                                 if obj.key == prior_item.get("key") and
                                 obj.access(actor, "view", default=True)]
                                if allows_native_missing_get and actor.location else [])
            if (allows_native_missing_get and was_locally_visible and
                    prior_item.get("key") and not same_key_objects):
                command = f"get {prior_item['key']}"
            elif (allows_native_missing_get and same_key_objects and
                  all(obj.id != item_id for obj in same_key_objects)):
                rejection = "assigned item is absent and a same-key local object makes native get ambiguous"
            else:
                rejection = "assigned item is not visible in the actor's current room"
        else:
            command = f"get {target.key}"
    elif operation["operator"] == "drop":
        target = next((obj for obj in actor.contents if obj.id == item_id), None)
        if target is None:
            rejection = "assigned item is not in the actor's inventory"
        elif actor.location.id != operation["room_id"]:
            rejection = "actor is not at the observed destination room"
        else:
            command = f"drop {target.key}"
    elif operation["operator"] == "give" and ongoing_task:
        target = next((obj for obj in actor.contents if obj.id == item_id), None)
        recipient_id = operation.get("recipient_id")
        recipient = next((obj for obj in actor.location.contents
                          if obj.id == recipient_id and obj is not actor
                          and obj.access(actor, "view", default=True)), None) if actor.location else None
        if target is None:
            rejection = "committed handover item is not in the actor's inventory"
        elif recipient is None:
            rejection = "registered recipient is not currently visible in the actor's room"
        else:
            command = f"give {target.key} = {recipient.key}"
    elif operation["operator"] == "store_item" and ongoing_task:
        target = next((obj for obj in actor.contents if int(obj.id) == int(item_id or -1)), None)
        storage_id = operation.get("storage_id", ongoing_task.get("storage_destination_id"))
        if target is None:
            rejection = "registered supply is not held by the actor"
        elif type(storage_id) is not int:
            rejection = "registered station storage id is missing"
        else:
            actor.attributes.add("p5_station_last_store_result", None, category="native_p5")
            command = f"station-store {int(target.id)}"
    elif operation["operator"] == "use_tool" and ongoing_task:
        # This registered native operation acquires only the scenario's single
        # station lease. Effects happen in a later callback after its due minute.
        from tools.native_platform_v0.p5.ongoing_station.work import start_work
        from tools.native_platform_v0.p5.ongoing_station.work import next_action_id
        from tools.native_platform_v0.p3.p4_world import clock_for_actor
        now_minute = int(clock_for_actor(actor)["now"])
        action_id = pending.get("operation_id")
        if not isinstance(action_id, str) or not action_id:
            action_id = next_action_id(actor, ongoing_task.get("commitment_id"), now_minute)
        work_task = {**ongoing_task, "action_id": action_id}
        result = start_work(actor, work_task, now_minute=now_minute,
                            scene_id=str(get_value(actor, "p3_scene_id")))
        set_value(actor, "pending_action", None)
        if result.get("ok"):
            record(actor, {"kind": "ongoing_station_work_started", **result,
                           "commitment_id": ongoing_task.get("commitment_id")})
        else:
            record(actor, {"kind": "ongoing_station_work_start_rejected", **result,
                           "commitment_id": ongoing_task.get("commitment_id")})
        return result
    else:
        rejection = "unsupported primitive"

    if rejection:
        _settle_pending(actor, pending, before_room, before_inventory, before_item_room,
                        "WORLD_VALIDATION_REJECTED", rejection, dispatch_succeeded=False)
        return

    executing = {**pending, "status": "executing", "submitted_command": command}
    if operation["operator"] == "give" and ongoing_task.get("task_kind") in {"lend_tool", "return_tool"}:
        recipient_before = next((obj for obj in actor.location.contents
                                 if obj.id == operation.get("recipient_id")), None) if actor.location else None
        executing["recipient_before_room_id"] = (
            int(recipient_before.location.id) if recipient_before and recipient_before.location else None)
    set_value(actor, "pending_action", executing)
    operation_id = pending.get("operation_id")
    actor.ndb.p3_pending_operation_id = operation_id
    try:
        deferred = actor.execute_cmd(command)
    except Exception as exc:  # command dispatch errors are recorded, never treated as success
        _settle_pending(actor, executing, before_room, before_inventory, before_item_room,
                        "COMMAND_ERROR", f"{type(exc).__name__}: {exc}", dispatch_succeeded=False)
        return

    def completed(result):
        if hasattr(result, "getErrorMessage"):
            _settle_pending(actor, executing, before_room, before_inventory, before_item_room,
                            "COMMAND_ERROR", result.getErrorMessage(), dispatch_succeeded=False)
        else:
            _settle_pending(actor, executing, before_room, before_inventory, before_item_room,
                            None, None, dispatch_succeeded=True)
        return result

    if hasattr(deferred, "addBoth"):
        deferred.addBoth(completed)
    else:
        completed(deferred)
    return deferred


def _settle_pending(actor, pending, before_room, before_inventory, before_item_room, failure, detail,
                    dispatch_succeeded):
    intent = pending["intent"]
    ongoing_task = pending.get("ongoing_task") or {}
    item_id = ongoing_task.get("item_id", pending["view"]["goal_contract"].get("item_id"))
    after_room = actor.location.id if actor.location else None
    after_inventory = [obj.id for obj in actor.contents]
    recipient_id = intent.get("recipient_id") if intent.get("operator") == "give" else None
    recipient = next((obj for obj in actor.location.contents if obj.id == recipient_id), None) \
        if recipient_id is not None and actor.location else None
    recipient_inventory = [obj.id for obj in recipient.contents] if recipient is not None else []
    after_item_room = after_room if item_id is not None and _visible_item_in_room(actor, item_id) else None
    if intent["operator"] == "move":
        settled = bool(dispatch_succeeded and after_room == intent["destination_id"] and before_room != after_room)
    elif intent["operator"] == "get":
        settled = bool(dispatch_succeeded and item_id in after_inventory and item_id not in before_inventory)
    elif intent["operator"] == "give":
        settled = bool(dispatch_succeeded and item_id in before_inventory and item_id not in after_inventory
                       and item_id in recipient_inventory)
    elif intent["operator"] == "store_item":
        store_result = actor.attributes.get("p5_station_last_store_result", category="native_p5", default={})
        settled = bool(dispatch_succeeded and store_result.get("settled") is True
                       and store_result.get("item_id") == item_id
                       and store_result.get("storage_id") == intent.get("storage_id",
                                                                            ongoing_task.get("storage_destination_id")))
    else:
        settled = bool(dispatch_succeeded and item_id in before_inventory and
                       after_item_room == intent["room_id"] and item_id not in after_inventory)
    if not settled and detail is None:
        detail = ("native command completed without a reported error, but the observed world state "
                  f"did not show the expected {intent['operator']} transition")
    status = "SETTLED" if settled else failure or "WORLD_VALIDATION_REJECTED"
    event_id = f"p3:{actor.id}:{get_value(actor, 'tick_count', 0)}:{len(get_value(actor, 'log', []))}"
    receipt = {"receipt_id": event_id, "kind": intent["operator"], "actor_dbref": actor.dbref,
               "item_id": item_id, "before_room_id": before_room, "after_room_id": after_room,
               "before_item_room_id": before_item_room, "after_item_room_id": after_item_room,
               "goal": pending.get("goal", {}).get("choice", pending.get("goal", {}).get("goal")),
               "activity_profile": get_value(actor, "activity_profile", "legacy_delivery_v0"),
               "submitted_command": pending.get("submitted_command"),
               "before_inventory_ids": before_inventory, "after_inventory_ids": after_inventory,
               "dispatch_succeeded": dispatch_succeeded, "settled": settled}
    if intent["operator"] == "give":
        receipt.update({"recipient_id": recipient_id,
                        "recipient_dbref": recipient.dbref if recipient is not None else None,
                        "recipient_inventory_ids": recipient_inventory})
        if ongoing_task.get("task_kind") in {"lend_tool", "return_tool"}:
            receipt.update({
                "recipient_before_room_id": pending.get("recipient_before_room_id"),
                "recipient_after_room_id": (int(recipient.location.id)
                                             if recipient is not None and recipient.location else None),
                "loan_request_id": ongoing_task.get("loan_request_id"),
            })
    if ongoing_task:
        receipt.update({"ongoing_commitment_id": ongoing_task.get("commitment_id"),
                        "ongoing_task_kind": ongoing_task.get("task_kind")})
    profile = get_value(actor, "activity_profile", "legacy_delivery_v0")
    if profile in ("p4_story_v0", "p5_story_v0"):
        # P4 has an explicit simulated clock. Keep this annotation P4-only so old
        # receipt formats remain byte-for-byte compatible.
        from .p4_world import clock_for_actor

        clock = clock_for_actor(actor)
        receipt.update({"sim_minute": clock["now"], "deadline": clock["deadline"],
                        "time_unit": clock.get("unit", "simulated-minute")})
    set_value(actor, "last_outcome", {"status": status, "intent": intent, "detail": detail,
                                     "receipt": receipt})
    set_value(actor, "pending_action", None)
    if getattr(actor, "ndb", None) is not None:
        actor.ndb.p3_pending_operation_id = None
    if intent["operator"] == "get" and not settled and item_id is not None and after_room == before_room:
        knowledge = get_value(actor, "witnessed", {"edges": {}, "objects": {}})
        fact = knowledge.get("objects", {}).get(str(item_id))
        if fact and fact.get("room_id") == after_room:
            fact.update({"room_id": None, "status": "not_visible_after_rejected_get",
                         "absence_observed_at": _stamp()})
            set_value(actor, "witnessed", knowledge)
    if settled:
        native_receipts = list(get_value(actor, "native_receipts", []))
        native_receipts.append(receipt)
        set_value(actor, "native_receipts", native_receipts)
    if intent["operator"] == "move" and pending.get("goal", {}).get("choice") == "patrol":
        state = get_value(actor, "patrol_rejected_state")
        if not settled:
            move_view = pending["view"]["observation"]
            p4_profile = pending.get("view", {}).get("activity_contract", {}).get("profile") in {
                "p4_story_v0", "p5_story_v0"}
            signature = sorted(
                (str(edge["key"]), int(edge["destination_id"]), bool(edge.get("traversable")))
                if p4_profile else (str(edge["key"]), int(edge["destination_id"]))
                for edge in move_view.get("exits", ()))
            saved_signature = (sorted(tuple(row) for row in state.get("exits", ())) if state else None)
            if not state or state.get("room_id") != before_room or saved_signature != signature:
                state = {"room_id": before_room, "exits": signature, "rejected": []}
            rejected = list(state.get("rejected", []))
            fingerprint = [str(intent["exit_key"]), int(intent["destination_id"])]
            if fingerprint not in rejected:
                rejected.append(fingerprint)
            state["rejected"] = rejected
            set_value(actor, "patrol_rejected_state", state)
        elif after_room != before_room:
            set_value(actor, "patrol_rejected_state", None)
    settlement = {"kind": "execution_settlement", "status": status, "intent": intent,
                  "receipt": receipt, "detail": detail}
    profile = get_value(actor, "activity_profile", "legacy_delivery_v0")
    if profile in ("p4_story_v0", "p5_story_v0"):
        settlement.update({"sim_minute": receipt["sim_minute"], "deadline": receipt["deadline"],
                           "time_unit": receipt["time_unit"]})
    if (profile == "p5_story_v0" and intent["operator"] == "drop" and settled):
        from tools.native_platform_v0.p5.world import record_delivery_receipt

        record_delivery_receipt(actor, receipt)
    record(actor, settlement)


def _maybe_social_after_delivery(actor, local_view):
    """Propose P3-B social action; native world settlement is a later script tick."""
    if get_value(actor, "mode") != "b" or get_value(actor, "social_attempted", False):
        return
    target_id = get_value(actor, "p3_social_target_id")
    visible_ids = {row["id"] for row in local_view["observation"]["visible_items"]}
    if target_id not in visible_ids or not actor.location:
        return
    target = next((obj for obj in actor.location.contents if obj.id == target_id and
                   obj.access(actor, "view", default=True)), None)
    if target is None:
        return
    record(actor, {"kind": "goal_choice", "goal": "native_ensemble_interaction",
                   "reason": "P3-B authored social objective; assigned parcel already settled",
                   "target_id": target.id, "room_id": actor.location.id})
    try:
        from tools.native_platform_v0.bridge import evennia_bridge
        from tools.native_platform_v0.bridge.social import execute_social, propose_social
        scene_id = get_value(actor, "scene_id")
        with _SOCIAL_CLIENTS_LOCK:
            client = _SOCIAL_CLIENTS.get(scene_id)
            if client is None or client.proc.poll() is not None:
                client = evennia_bridge.EnsembleProcess()
                _SOCIAL_CLIENTS[scene_id] = client
        attempt = get_value(actor, "social_attempt_count", 0) + 1
        set_value(actor, "social_attempt_count", attempt)
        role = actor.attributes.get("ensemble_character_id", category="ensemble_bridge")
        scenario_seed = get_value(actor, "scenario_seed", 0)
        social_view = {"target": target, "target_visible": True, "room_id": actor.location.id,
                       "source_event_id": f"native-p3b:{scenario_seed}:{role}:social-after-delivery:attempt:{attempt}"}
        proposal = propose_social(actor, social_view, {"ensemble_client": client},
                                  seed=f"p3b-seed-v0:{scenario_seed}:{role}:social-after-delivery")
        record(actor, {"kind": "social_proposal", "proposal": proposal})
        if not proposal.get("ok"):
            set_value(actor, "social_attempted", True)
            record(actor, {"kind": "social_outcome", "result": proposal})
            return
        set_value(actor, "pending_social", {"status": "planned", "proposal": proposal,
                                             "target_id": target.id, "scene_id": scene_id,
                                             "attempt": attempt})
    except Exception as exc:
        result = {"ok": False, "status": "SOCIAL_ADAPTER_ERROR",
                  "error": f"{type(exc).__name__}: {exc}"}
        set_value(actor, "social_attempted", True)
        set_value(actor, "social_result", result)
        record(actor, {"kind": "social_outcome", "result": result})


def _settle_social_pending(actor, pending):
    """Revalidate current-room visibility before one native social settlement."""
    from tools.native_platform_v0.bridge import evennia_bridge
    from tools.native_platform_v0.bridge.social import execute_social

    scene_id = pending["scene_id"]
    client = _SOCIAL_CLIENTS.get(scene_id)
    if client is None or client.proc.poll() is not None:
        set_value(actor, "pending_social", None)
        result = {"ok": False, "status": "SOCIAL_PROPOSAL_INTERRUPTED",
                  "error": "scene-local Ensemble process is unavailable; no world receipt inferred"}
        set_value(actor, "social_result", result)
        set_value(actor, "social_attempted", False)
        record(actor, {"kind": "social_outcome", "result": result})
        return
    target = None
    if actor.location:
        target = next((obj for obj in actor.location.contents
                       if obj.id == pending["target_id"] and obj.access(actor, "view", default=True)), None)
    result = execute_social(client, pending["proposal"], {
        "actor": actor, "target": target, "target_visible": target is not None,
    })
    set_value(actor, "pending_social", None)
    set_value(actor, "social_result", result)
    set_value(actor, "social_attempted", result.get("status") != "WORLD_VALIDATION_REJECTED")
    record(actor, {"kind": "social_outcome", "result": result})


try:
    from evennia import DefaultScript
except Exception:  # permits pure unit tests without a configured Evennia/Django server
    DefaultScript = object
if not isinstance(DefaultScript, type):
    DefaultScript = object


class P3AutonomyScript(DefaultScript):
    """Persistent, independent scheduler loop; each tick observes or settles one primitive."""

    def at_script_creation(self):
        self.key = self.key or "native-p3-autonomy"
        self.desc = "Persistent actor-local HTN courier loop with native command settlement."
        actor = getattr(self, "obj", None)
        drive = _get(actor, "drive_mode", "timer") if actor else "timer"
        interval = _get(actor, "interval_seconds", 4) if actor else 4
        # Evennia 6.0.0 stores db_interval as a non-null integer; zero disables timing.
        self.interval = interval if drive == "timer" else 0
        self.persistent = True

    def at_repeat(self):
        actor = self.obj
        if actor is None:
            self.stop()
            return
        if get_value(actor, "activity_profile", "legacy_delivery_v0") == "p4_story_v0":
            from .p4_agency import step_actor as step_p4_actor
            return step_p4_actor(actor)
        if get_value(actor, "activity_profile", "legacy_delivery_v0") == "p5_story_v0":
            from tools.native_platform_v0.p5.agency import step_actor as step_p5_actor
            return step_p5_actor(actor)
        status = get_value(actor, "status", "RUNNING")
        if status == "PAUSED":
            return
        tick = get_value(actor, "tick_count", 0) + 1
        set_value(actor, "tick_count", tick)
        record(actor, {"kind": "timer_tick", "tick": tick, "status_before": status})
        pending = get_value(actor, "pending_action")
        if pending:
            if pending.get("status") == "planned":
                return _dispatch_pending(actor, pending)
            elif pending.get("status") == "executing" and not getattr(actor.ndb, "p3_pending_operation_id", None):
                # A persisted in-flight command may have been interrupted by a server restart.
                # Never infer settlement from the coincidental current state; clear and reobserve.
                set_value(actor, "pending_action", None)
                set_value(actor, "last_outcome", {"status": "INTERRUPTED_IN_DOUBT",
                                                   "intent": pending["intent"], "receipt": None})
                record(actor, {"kind": "execution_interrupted", "intent": pending["intent"],
                               "reason": "server restart or lost in-process Deferred; no receipt inferred"})
            return
        pending_social = get_value(actor, "pending_social")
        if pending_social:
            _settle_social_pending(actor, pending_social)
            return
        try:
            decision = make_decision(actor)
        except Exception as exc:
            set_value(actor, "status", "ERROR")
            record(actor, {"kind": "loop_error", "error": f"{type(exc).__name__}: {exc}"})
            return
        selection = decision["goal"]
        record(actor, {"kind": "goal_choice", "inputs": selection.get("inputs"),
                       "candidates": selection.get("candidates", []),
                       "rule": selection.get("rule"), "choice": selection.get("choice"),
                       "reason": selection.get("reason"), "goal": selection,
                       "activity_profile": decision["view"]["activity_contract"],
                       "view": thaw(decision["view"]), "planner": decision["planner"]})
        if selection.get("status") == "NO_TASK":
            set_value(actor, "status", "IDLE")
            record(actor, {"kind": "activity_idle", "reason": selection["reason"]})
            return
        if decision["goal"].get("status") in ("ACTOR_DELIVERY_SETTLED", "WORLD_GOAL_SATISFIED_EXTERNAL"):
            outcome = decision["goal"]["status"]
            if status != outcome:
                set_value(actor, "status", outcome)
                record(actor, {"kind": "goal_satisfied_by_local_observation", "status": outcome,
                               "evidence": decision["goal"]["reason"],
                               "native_actor_receipts": decision["view"]["observation"]["own_delivery_receipts"]})
            if outcome == "ACTOR_DELIVERY_SETTLED":
                _maybe_social_after_delivery(actor, thaw(decision["view"]))
            return
        if decision["intent"] is None:
            planner = decision["planner"] or {}
            if selection.get("choice") == "patrol":
                set_value(actor, "status", "PATROL_WAITING")
                record(actor, {"kind": "activity_wait", "activity": "patrol",
                               "status": planner.get("status"), "reason": planner.get("reason"),
                               "candidate_exits": planner.get("candidate_exits", [])})
            else:
                set_value(actor, "status", "BLOCKED")
                record(actor, {"kind": "blocked", "reason": planner.get("reason")})
            return
        set_value(actor, "status", "RUNNING")
        pending = {"status": "planned", "planned_at_tick": tick,
                   "operation_id": f"p3:{actor.id}:{tick}",
                   "goal": decision["goal"], "planner": decision["planner"],
                   "intent": decision["intent"], "view": thaw(decision["view"])}
        set_value(actor, "pending_action", pending)
        record(actor, {"kind": "primitive_intent", "pending_action": pending})


def step_actor(actor):
    """Run one real script callback only in the explicit manual test fixture."""
    from evennia.scripts.models import ScriptDB

    if get_value(actor, "drive_mode") != "manual":
        raise ValueError("step_actor is available only for the explicit manual test fixture")
    script = ScriptDB.objects.filter(id=get_value(actor, "script_id")).first()
    if script is None:
        raise RuntimeError("persistent P3 actor script is missing")
    return script.at_repeat()

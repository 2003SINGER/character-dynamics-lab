"""Render a readable chronological replay from sealed native evidence."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def build_replay(trace: Mapping[str, Any]) -> str:
    station = trace.get("ongoing_station", {})
    station = station if isinstance(station, Mapping) else {}
    events = trace.get("ledger", [])
    events = [row for row in events if isinstance(row, Mapping)] if isinstance(events, list) else []
    actor_decisions = station.get("actor_goal_decisions", [])
    actor_decisions = ([row for row in actor_decisions if isinstance(row, Mapping)]
                       if isinstance(actor_decisions, list) else [])
    actor_evidence = trace.get("actor_evidence", [])
    actor_evidence = ([row for row in actor_evidence if isinstance(row, Mapping)]
                      if isinstance(actor_evidence, list) else [])
    alias_by_id = {row.get("actor_id"): row.get("actor_alias") for row in actor_evidence
                   if row.get("actor_id") is not None}
    if not actor_decisions:
        actor_decisions = [entry for actor in actor_evidence
                           for entry in actor.get("log", [])
                           if isinstance(entry, Mapping)
                           and entry.get("kind") == "ongoing_station_decision"]
    rows: list[tuple[int, str, str]] = []
    seen_ids: set[str] = set()
    for event in events:
        minute = event.get("minute")
        if type(minute) is not int:
            continue
        kind = str(event.get("event_type", "native_event"))
        event_id = str(event.get("event_id", "missing-event-id"))
        seen_ids.add(event_id)
        args = event.get("typed_args", {})
        detail = ""
        if isinstance(args, Mapping):
            actor = args.get("actor_alias") or args.get("role")
            operation = args.get("operation") or args.get("kind")
            receipt = args.get("receipt_id")
            detail = "; ".join(str(value) for value in
                                (f"actor={actor}" if actor is not None else None,
                                 f"operation={operation}" if operation is not None else None,
                                 f"receipt={receipt}" if receipt is not None else None)
                                if value)
        rows.append((minute, f"Native event {kind}", f"{event_id}" + (f" — {detail}" if detail else "")))
    for actor in actor_evidence:
        alias = actor.get("actor_alias", actor.get("actor_id", "unknown actor"))
        receipts = actor.get("native_receipts", [])
        for receipt in receipts if isinstance(receipts, list) else []:
            if not isinstance(receipt, Mapping) or receipt.get("settled") is not True:
                continue
            receipt_id = str(receipt.get("receipt_id", "missing-receipt-id"))
            minute = receipt.get("sim_minute", receipt.get("minute"))
            if type(minute) is not int or receipt_id in seen_ids:
                continue
            seen_ids.add(receipt_id)
            rows.append((minute, f"NPC {alias}: settled {receipt.get('kind', 'native action')}",
                         f"{receipt_id}; commitment={receipt.get('ongoing_commitment_id', 'unlinked')}"))
    for decision in actor_decisions:
        minute = decision.get("minute")
        if type(minute) is not int:
            continue
        actor_id = decision.get("actor_id")
        alias = decision.get("actor_alias", alias_by_id.get(actor_id, actor_id or "unknown actor"))
        commitment = decision.get("commitment")
        commitment = commitment if isinstance(commitment, Mapping) else {}
        goal = commitment.get("goal_id", decision.get("selected_goal"))
        source = commitment.get("source", decision.get("source", "unknown source"))
        disposition = decision.get("disposition", "undocumented disposition")
        rationale = decision.get("rationale", "no rationale recorded")
        decision_id = decision.get("decision_id", "decision id not supplied")
        commitment_detail = []
        if commitment.get("commitment_id") is not None:
            commitment_detail.append(f"commitment={commitment['commitment_id']}")
        if commitment.get("task_kind") is not None:
            commitment_detail.append(f"task={commitment['task_kind']}")
        if commitment.get("route_waypoints"):
            commitment_detail.append(f"route_waypoints={commitment['route_waypoints']}")
        if commitment.get("waypoint_receipts"):
            commitment_detail.append(f"waypoint_receipts={commitment['waypoint_receipts']}")
        intent = decision.get("intent")
        intent_detail = (f"; intent={intent.get('operator', intent.get('primitive', 'native'))}"
                         if isinstance(intent, Mapping) else "")
        rows.append((minute, f"NPC {alias}: {source} goal {goal} / {disposition}",
                     f"{decision_id}; {rationale}"
                     + (f"; {'; '.join(commitment_detail)}" if commitment_detail else "")
                     + intent_detail))
    rows.sort(key=lambda row: (row[0], row[1], row[2]))
    lines = ["# Ongoing Station — Native Run Replay", "",
             f"Scene: `{trace.get('scene_id', 'unknown')}` · "
             f"status: `{trace.get('run_status', 'unknown')}` · "
             f"sealed through: `{trace.get('complete_through', {})}`", "",
             "This replay is derived from the saved ledger and actor-decision rows. "
             "Each line retains a source event/decision identifier; missing rationale is labeled, not invented.", ""]
    if not rows:
        lines.append("No renderable sealed events or actor decisions were present.")
    else:
        for minute, title, evidence in rows:
            lines.append(f"- **Minute {minute}: {title}.** {evidence}")
    lines.extend(["", "## Outcome boundary", "",
                  "A proposal is not an accepted commitment; an accepted commitment is not a settled action. "
                  "Only the native ledger, receipt, and independent database readback establish physical effects."])
    return "\n".join(lines) + "\n"

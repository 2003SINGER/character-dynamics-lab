# Ongoing station runner

This package contains the fixed case inputs, one-scene runner, evidence audit,
and readable replay for the opt-in P5 ongoing-station profile. The runner uses
the existing authenticated P3 control service, one-minute `step_world` calls,
`get_trace`, and the separate read-only P5 DB exporter. It does not issue NPC
commands or call `observe_actor`; actor choices and physical actions must come
from the native callbacks and world receipts.

## T1: author-free autonomy

`cases/suite.json` fixes seed, initial preset, world settings, and horizon. The
profile has `author: null`; the empty legacy bundle contributes no authored
constraint. T1 records both role IDs, each role's self-goal decisions and
commitment history, native settled receipts, and a subsequent distinct
self-goal that is either physically receipted or still has its matching native
pending execution. The audit returns `NOT_CERTIFIED` when any source is absent
or malformed; a planner proposal alone is insufficient.

The JSON exporter is scoped to the explicit scene ID and returns the persisted
objects under `scenes[].objects[]`. The raw export is copied byte-for-byte into
the run directory and hashed before auditing. Minute files retain only each
round's incremental delta; the full cumulative trace is saved once at the end.
Run directories are unique and failures are preserved.

Preflight is read-only:

```sh
python -m tools.native_platform_v0.p5.ongoing_station.runner \
  --case-id t1-no-author-autonomy
```

Creating a native scene requires the explicit `--execute` flag and separate
operator authorization. This README does not authorize a run. The matched
author/strategy cases remain not runnable until their inputs, native hooks,
and focused tests are frozen.

## Runtime ownership and role goals

The nested, validated `AuthorBundle` remains the only source of story goals. The
`ongoing-station-author-v1` wrapper binds those existing constraints to registered
control modes and immutable task grants; the station projection is derived from
that source and is not separately edited. A sealed-ledger controller uses the
existing story-process GTPyhop planner to turn a currently applicable constraint
into future actor task offers. The NPC callback receives only its eligible offers
and the projection identity; it builds its own local view through P3
`observe_actor`, never from the controller's global world snapshot.

Each actor keeps its own goal/commitment history and current commitments
(`ACCEPTED`, `IN_PROGRESS`, `SUSPENDED`, `SETTLED`, or terminal expiry evidence).
An existing commitment is retained while feasible; lost local item evidence
suspends it without erasing it, and later local re-observation may resume it. A
competing offer records a concrete defer reason when work is active or the exact
item is not locally available. There is no first-invitation refusal rule or
synthetic refusal event. Commitments settle only from a new matching native
receipt, after the receipt frontier captured when that commitment was accepted.

Own tasks and author tasks enter the same opt-in P3 actor task planner. P3's
pinned GTPyhop runtime, actor-local known-exit graph, and route helper are reused;
the station task methods decompose delivery/archive, handover, and real route
activity into one proposed native primitive. P3's existing pending-action
dispatcher remains the only place that executes move/get/drop, with an opt-in
give operator for a registered visible recipient. Completion comes from the
resulting Evennia state and receipt, not from the HTN prediction. A routine route
is a real two-leg out-and-back movement commitment: its first waypoint does not
settle the goal, and only its own ordered, commitment-tagged receipts for both
waypoints complete it. An author offer arriving between legs is logged as
deferred against that still-active commitment; no refusal is scripted.

The method reuse boundary is deliberate: this integrates the already-pinned
GTPyhop implementation and its DFS method search, and adapts the existing P3
observation, route helper, primitive dispatcher, and receipt structure. It does
not port Praxish, add a second pathfinder, infer psychological utility weights,
or claim a general BDI architecture. New work is the station-specific author
binding/offer projection, persistent commitment arbitration and history, task
methods/operators, and their native integration and tests.

## Reserved LLM insertion points

No LLM call is part of the current native runtime. Future experiments may place
one model boundary between author prose and the registered `AuthorBundle`
constraints, and another between an actor's local observation/commitment history
and a candidate goal explanation. In both cases the current strict schemas,
actor-local visibility, native action validation, and receipt-based settlement
remain authoritative. No model download, embedding index, fine-tuning, or model
generated world effect is included here.

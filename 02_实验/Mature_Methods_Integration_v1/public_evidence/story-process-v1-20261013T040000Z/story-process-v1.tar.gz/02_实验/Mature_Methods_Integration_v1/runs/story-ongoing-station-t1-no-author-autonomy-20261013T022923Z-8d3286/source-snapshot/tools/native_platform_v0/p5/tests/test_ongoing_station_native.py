import unittest
from unittest.mock import patch

from tools.native_platform_v0.p5.ongoing_station.native import (
    initialize_station, meta_for, profile_for,
)
from tools.native_platform_v0.p5.tests.test_ongoing_station_model import profile


class Attributes:
    def __init__(self):
        self.values = {}

    def add(self, key, value, category=None):
        self.values[(category, key)] = value

    def get(self, key, category=None, default=None):
        return self.values.get((category, key), default)


class Obj:
    def __init__(self):
        self.attributes = Attributes()


class OngoingStationNativeTests(unittest.TestCase):
    def test_null_author_profile_initializes_autonomy_state_without_author_goal(self):
        pickup, actor_a, actor_b = Obj(), Obj(), Obj()
        loaded = initialize_station(pickup, {"A": actor_a, "B": actor_b}, profile(horizon=40))
        self.assertEqual(loaded.horizon, 40)
        self.assertEqual(profile_for(pickup).station_id, "station-1")
        self.assertEqual(meta_for(pickup)["author_status"], "ABSENT")
        for actor in (actor_a, actor_b):
            self.assertEqual(actor.attributes.get("ongoing_commitments", category="native_p5"), [])
            self.assertEqual(actor.attributes.get("ongoing_goal_history", category="native_p5"), [])
            self.assertIsNone(actor.attributes.get("ongoing_task_offer", category="native_p5"))

    def test_invalid_station_profile_rejected_before_evennia_or_scene_creation(self):
        from tools.native_platform_v0.p5.service import reset_p5_scenario
        from tools.native_platform_v0.p5.tests.test_p5_bundle import sample

        invalid = profile()
        invalid["extra"] = "must fail closed"
        with patch.dict("sys.modules", {"evennia": None}):
            result = reset_p5_scenario(owner=None, bundle=sample(), ongoing_station=invalid)
        self.assertFalse(result["scene_created"])
        self.assertEqual(result["error"]["code"], "INVALID_ONGOING_STATION")

    def test_controller_request_is_a_strict_projection_of_the_bundle_constraint(self):
        from tools.native_platform_v0.p5.ongoing_station.controller import _runtime_request
        from tools.native_platform_v0.p5.ongoing_station.model import compile_projection, load_profile
        from tools.native_platform_v0.p5.story_process.model import load_request
        from tools.native_platform_v0.p5.tests.test_ongoing_station_model import author

        projection = compile_projection(load_profile(profile(author())))
        constraint = next(row for row in projection.constraints if row["constraint_id"] == "archive-goal")
        raw = _runtime_request(load_profile(profile(author())), projection, constraint,
                               constraint["control"], "scene-1", 71)
        request = load_request(raw)
        self.assertEqual(request.objective["note_id"], 71)
        self.assertEqual(request.objective["by_minute"], 24)
        self.assertEqual(request.control["allowed_methods"], ["file_by_B", "return_then_file_by_A"])

    def test_station_typed_event_requires_matching_physical_native_receipt(self):
        from tools.native_platform_v0.p5.ongoing_station.controller import _typed_events
        from tools.native_platform_v0.p5 import service

        actor_a, actor_b = Obj(), Obj()
        actor_a.id, actor_b.id = 10, 20
        actor_a.contents, actor_b.contents = [], []
        actor_a.attributes.add("native_receipts", [{"receipt_id": "receipt-1", "kind": "drop",
            "settled": True, "item_id": 71, "after_item_room_id": 90,
            "ongoing_commitment_id": "commit-1"}], category="native_p3")
        actor_a.attributes.add("ongoing_commitments", [{"commitment_id": "commit-1",
            "task_kind": "archive_note", "destination_id": 90}], category="native_p5")
        actors = {"A": actor_a, "B": actor_b}
        ledger = [{"event_id": "station-receipt:receipt-1",
                   "event_type": "P5_ONGOING_STATION_NOTE_ARCHIVED", "version": 1,
                   "minute": 1, "sequence": 4,
                   "typed_args": {"receipt_id": "receipt-1", "commitment_id": "commit-1",
                       "actor_alias": "A", "item_id": 71, "settled": True}}]
        events = _typed_events("scene-1", 71, 1, ledger, actors, service, all_rows=[actor_a, actor_b])
        self.assertEqual([row["event_type"] for row in events], ["p5_note_archived"])
        actor_a.attributes.add("native_receipts", [], category="native_p3")
        self.assertEqual(_typed_events("scene-1", 71, 1, ledger, actors, service,
                                       all_rows=[actor_a, actor_b]), [])


if __name__ == "__main__":
    unittest.main()

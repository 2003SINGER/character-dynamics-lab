"""Opt-in actor callback for persistent station commitments over P3 local HTN."""

from copy import deepcopy
from collections.abc import Mapping
import json

from tools.native_platform_v0.p3.agency import get_value, observe_actor, record, set_value
from tools.native_platform_v0.p3.planning import plan_actor_task, thaw

from .goals import ACTIVE, arbitrate, refresh_commitment

DECISION_SCHEMA = "ongoing-station-actor-decision-v1"
_STATION_CATEGORY = "native_p5"


def _station_get(actor, key, default=None):
    return actor.attributes.get(key, category=_STATION_CATEGORY, default=default)


def _station_set(actor, key, value):
    actor.attributes.add(key, value, category=_STATION_CATEGORY)


def _projection_value(projection, key, fallback=None):
    if projection is None:
        return fallback
    if isinstance(projection, Mapping):
        return projection.get(key, fallback)
    return getattr(projection, key, fallback)


def _local_signature(view):
    observation = view.get("observation", {})
    evidence = {
        "room_id": observation.get("room_id"),
        "exits": observation.get("exits", []),
        "known_exits": observation.get("known_exits", {}),
        "known_traversability": observation.get("known_traversability", {}),
        "inventory_ids": sorted(str(row.get("id")) for row in observation.get("inventory", [])),
        "visible_items": sorted((str(row.get("id")), row.get("room_id"))
                                for row in observation.get("visible_items", [])),
        "retained_witnesses": sorted((str(row.get("id")), row.get("room_id"))
                                      for row in observation.get("retained_witnesses", [])),
        "item_location": observation.get("item_location"),
    }
    return json.dumps(evidence, sort_keys=True, separators=(",", ":"), default=str)


def _self_offers(actor, view, now_minute, receipts):
    contract = view.get("goal_contract", {})
    task_kind = contract.get("goal")
    if task_kind not in {"deliver_supply", "archive_note", "handover_note"}:
        task_kind = "deliver_supply" if contract.get("item_id") is not None else None
    offer_rows = []
    matching_drop = any(row.get("settled") is True and row.get("kind") == "drop"
                        and str(row.get("item_id")) == str(contract.get("item_id"))
                        and row.get("after_item_room_id") == contract.get("destination_id")
                        for row in receipts)
    if task_kind and not matching_drop and contract.get("item_id") is not None:
        offer_rows.append({
            "offer_id": f"self:{actor.id}:{task_kind}:{contract['item_id']}:{contract.get('destination_id')}",
            "source": "SELF", "goal_id": f"self-goal:{actor.id}:{task_kind}",
            "task_kind": task_kind, "item_id": contract.get("item_id"),
            "destination_id": contract.get("destination_id"),
            "recipient_id": contract.get("recipient_id"),
            "deadline_minute": None, "prerequisites": [], "constraint_id": None,
            "item_key": view.get("observation", {}).get("task_item", {}).get("key"),
            "last_known_item_room": view.get("observation", {}).get("item_location"),
        })
    previous_move = next((row for row in reversed(receipts)
                          if row.get("settled") is True and row.get("kind") == "move"
                          and row.get("before_room_id") is not None
                          and row.get("after_room_id") is not None), None)
    current = view.get("observation", {}).get("room_id")
    target = previous_move.get("before_room_id") if previous_move and previous_move.get("after_room_id") == current else None
    if target is None:
        exits = sorted(view.get("observation", {}).get("exits", ()),
                       key=lambda row: (str(row.get("key", "")).casefold(),
                                        int(row.get("destination_id", -1))))
        target = next((row.get("destination_id") for row in exits
                       if row.get("destination_id") is not None and row.get("destination_id") != current), None)
    if target is not None and target != current:
        route_no = int(_station_get(actor, "ongoing_route_sequence", 0))
        waypoints = [target, current]
        offer_rows.append({
            "offer_id": f"self:{actor.id}:routine_route:{route_no}:{target}",
            "source": "SELF", "goal_id": f"self-goal:{actor.id}:routine_route:{route_no}",
            "task_kind": "routine_route", "item_id": None,
            "destination_id": target, "recipient_id": None,
            "route_origin_id": current, "route_waypoints": waypoints,
            "waypoint_receipts": [None, None],
            "deadline_minute": None, "prerequisites": [], "constraint_id": None,
            "item_key": None, "last_known_item_room": None,
        })
    return offer_rows


def _commitment_from_offer(offer, now_minute, receipts):
    return {
        "commitment_id": offer.get("offer_id"), "source": offer.get("source"),
        "goal_id": offer.get("goal_id"), "status": "ACCEPTED",
        "task_kind": offer.get("task_kind"), "item_id": offer.get("item_id"),
        "destination_id": offer.get("destination_id"),
        "recipient_id": offer.get("recipient_id"),
        "deadline_minute": offer.get("deadline_minute"),
        "accepted_minute": now_minute, "updated_minute": now_minute,
        "reason": "accepted from actor-local feasible candidate set",
        "receipt_ids": [], "source_offer_id": offer.get("offer_id"),
        "item_key": offer.get("item_key"),
        "route_origin_id": offer.get("route_origin_id"),
        "route_waypoints": deepcopy(offer.get("route_waypoints")),
        "waypoint_receipts": deepcopy(offer.get("waypoint_receipts")),
        "source_method_id": offer.get("source_method_id"),
        "control_source": offer.get("control_source"),
        "grant_id": offer.get("grant_id"),
        "projection_id": offer.get("projection_id"),
        "constraint_id": offer.get("constraint_id"),
        "last_known_item_room": offer.get("last_known_item_room"),
        "prerequisites": deepcopy(offer.get("prerequisites", [])),
        "receipt_frontier": [row.get("receipt_id") for row in receipts
                             if row.get("receipt_id") is not None],
    }


def advance_actor(actor, station_projection, offers, now_minute):
    """Advance one actor's goal/commitment state and propose one shared P3 HTN intent.

    ``station_projection`` must already be derived from the unique author source;
    it is used only as source/version provenance, never to inspect hidden world state.
    This callback does not dispatch an action or settle a goal.
    """
    view = observe_actor(actor)
    # Evennia SaverList/SaverDict values must be detached recursively before
    # mutation; shallow list copies can silently discard nested attribute edits.
    receipts = thaw(get_value(actor, "native_receipts", []))
    commitments = thaw(_station_get(actor, "ongoing_commitments", []))
    history = thaw(_station_get(actor, "ongoing_goal_history", []))
    offers = thaw(offers or [])
    old_commitments = deepcopy(commitments)
    refreshed = [refresh_commitment(row, receipts, now_minute) for row in commitments]
    commitments = refreshed
    observation = view.get("observation", {})
    visible_or_held = {str(row.get("id")) for row in
                       (list(observation.get("inventory", ())) + list(observation.get("visible_items", ())))}
    retained = {str(row.get("id")) for row in observation.get("retained_witnesses", ())
                if isinstance(row.get("room_id"), int)}
    for row in commitments:
        if row.get("item_id") is not None:
            # A task's location binding is learned only from this actor's P3 O,
            # never copied from a controller's global object lookup.
            local_item_room = observation.get("item_location")
            if local_item_room is not None:
                row["last_known_item_room"] = local_item_room
        if row.get("status") in {"ACCEPTED", "IN_PROGRESS"} and row.get("item_id") is not None \
                and str(row["item_id"]) not in visible_or_held | retained:
            row["status"] = "SUSPENDED"
            row["reason"] = "assigned item is unavailable in current actor-local observation/history"
            row["updated_minute"] = now_minute

    # Every settled routine receipt creates the next real route candidate from
    # the prior locally witnessed room; sequence advances only on receipt.
    for prior, current in zip(old_commitments, commitments):
        if prior.get("status") in ACTIVE and current.get("status") == "SETTLED" \
                and current.get("task_kind") == "routine_route":
            _station_set(actor, "ongoing_route_sequence",
                         int(_station_get(actor, "ongoing_route_sequence", 0)) + 1)

    local_signature = _local_signature(view)
    suspended = [row for row in commitments if row.get("status") == "SUSPENDED"]
    retryable_suspended_ids = {str(row.get("commitment_id")) for row in suspended
                               if row.get("suspended_observation") != local_signature}
    candidates = list(offers) + _self_offers(actor, view, now_minute, receipts)
    # Do not repeatedly retry an unchanged failed decomposition. A changed
    # actor-local observation makes the same durable commitment eligible again.
    blocked_self_ids = {str(row.get("commitment_id")) for row in suspended
                        if row.get("suspended_observation") == local_signature}
    candidates = [row for row in candidates
                  if not (row.get("source") == "SELF" and str(row.get("offer_id")) in blocked_self_ids)]
    # A suspended commitment remains durable but competes again only after local
    # evidence changes; it does not monopolize the execution slot.
    candidates.extend({**row, "offer_id": row.get("source_offer_id") or row.get("commitment_id"),
                       "source": row.get("source"), "goal_id": row.get("goal_id")}
                      for row in commitments if row.get("status") == "SUSPENDED"
                      and str(row.get("commitment_id")) in retryable_suspended_ids)
    pending = get_value(actor, "pending_action")
    arbitration = arbitrate(candidates, commitments, view, now_minute, busy=bool(pending))
    for deferred in arbitration.get("deferred_offers", ()):
        history.append({"minute": now_minute, "event": "AUTHOR_OFFER_DEFERRED",
                        "offer_id": deferred.get("offer_id"),
                        "blocking_commitment_id": deferred.get("blocking_commitment_id"),
                        "blocking_commitment_status": deferred.get("blocking_commitment_status"),
                        "blocking_task_kind": deferred.get("blocking_task_kind"),
                        "blocking_route_waypoints": deferred.get("blocking_route_waypoints"),
                        "blocking_waypoint_receipts": deferred.get("blocking_waypoint_receipts", []),
                        "reason": deferred.get("reason"),
                        "evidence_receipt_ids": deferred.get("evidence_receipt_ids", [])})
    for candidate in arbitration.get("candidates", ()):
        if candidate.get("eligible") is False and any(
                offer.get("offer_id") == candidate.get("offer_id") and offer.get("source") == "AUTHOR"
                for offer in offers or ()):
            history.append({"minute": now_minute, "event": "AUTHOR_OFFER_DEFERRED",
                            "offer_id": candidate.get("offer_id"), "reason": candidate.get("reason"),
                            "evidence_receipt_ids": []})
    selected = arbitration.get("selected")
    commitment = None
    if selected and selected.get("commitment_id"):
        commitment = next((row for row in commitments
                           if row.get("commitment_id") == selected.get("commitment_id")
                           and row.get("status") in ACTIVE), None)
    if selected and commitment is None:
        local_offer = dict(selected)
        local_offer["last_known_item_room"] = observation.get("item_location")
        commitment = _commitment_from_offer(local_offer, now_minute, receipts)
        commitments.append(commitment)
        history.append({"minute": now_minute, "event": "COMMITMENT_ACCEPTED",
                        "commitment_id": commitment["commitment_id"],
                        "source": commitment["source"], "reason": arbitration.get("reason"),
                        "source_method_id": commitment.get("source_method_id"),
                        "control_source": commitment.get("control_source"),
                        "grant_id": commitment.get("grant_id"),
                        "projection_id": commitment.get("projection_id"),
                        "constraint_id": commitment.get("constraint_id"),
                        "route_waypoints": deepcopy(commitment.get("route_waypoints")),
                        "evidence_receipt_ids": []})

    planner = None
    intent = None
    disposition = arbitration.get("disposition", "WAIT")
    rationale = arbitration.get("reason", "no feasible candidate")
    if commitment:
        if pending:
            disposition = "CONTINUE"
            rationale = "preserve existing native pending action and actor commitment"
        else:
            task = {**commitment, "goal_id": commitment.get("goal_id"),
                    "task_kind": commitment.get("task_kind"),
                    "item_id": commitment.get("item_id"),
                    "destination_id": commitment.get("destination_id"),
                    "recipient_id": commitment.get("recipient_id")}
            planner = plan_actor_task(view, task)
            intent = planner.get("intent")
            if intent is not None and commitment.get("status") in {"ACCEPTED", "SUSPENDED"}:
                commitment["status"] = "IN_PROGRESS"
                commitment["updated_minute"] = now_minute
                history.append({"minute": now_minute, "event": "COMMITMENT_IN_PROGRESS",
                                "commitment_id": commitment["commitment_id"],
                                "reason": "shared P3 HTN proposed or resumed first primitive",
                                "evidence_receipt_ids": []})
            elif planner.get("status") in {"NO_PLAN", "BLOCKED", "BUDGET"}:
                commitment["status"] = "SUSPENDED"
                commitment["updated_minute"] = now_minute
                commitment["reason"] = planner.get("reason")
                commitment["suspended_observation"] = local_signature
                disposition = "DEFERRED"
                rationale = planner.get("reason", "current local plan unavailable")

    for before, after in zip(old_commitments, commitments):
        if before.get("status") != after.get("status"):
            if after.get("status") == "SETTLED":
                history.append({"minute": now_minute, "event": "COMMITMENT_SETTLED",
                                "commitment_id": after.get("commitment_id"),
                                "reason": after.get("reason"),
                                "evidence_receipt_ids": list(after.get("receipt_ids", []))})
            elif after.get("status") in {"EXPIRED", "SUSPENDED"}:
                history.append({"minute": now_minute, "event": f"COMMITMENT_{after['status']}",
                                "commitment_id": after.get("commitment_id"),
                                "reason": after.get("reason"), "evidence_receipt_ids": []})

    # Do not drop historical commitments; rows are updated in place by identity.
    _station_set(actor, "ongoing_commitments", commitments)
    _station_set(actor, "ongoing_goal_history", history)
    decision = {
        "schema": DECISION_SCHEMA, "actor_id": actor.id, "minute": now_minute,
        "author_source": {"station_id": _projection_value(station_projection, "station_id"),
                          "version": _projection_value(station_projection, "version"),
                          "bundle_hash": _projection_value(
                              station_projection, "bundle_hash",
                              _projection_value(station_projection, "source_sha256"))},
        "goal_candidates": arbitration.get("candidates", []),
        "selected_goal": commitment.get("commitment_id") if commitment else None,
        "disposition": disposition, "rationale": rationale,
        "commitment": deepcopy(commitment), "planner": planner, "intent": intent,
        "view": thaw(view), "pending_action_preserved": bool(pending),
    }
    record(actor, {"kind": "ongoing_station_decision", **decision})
    return decision


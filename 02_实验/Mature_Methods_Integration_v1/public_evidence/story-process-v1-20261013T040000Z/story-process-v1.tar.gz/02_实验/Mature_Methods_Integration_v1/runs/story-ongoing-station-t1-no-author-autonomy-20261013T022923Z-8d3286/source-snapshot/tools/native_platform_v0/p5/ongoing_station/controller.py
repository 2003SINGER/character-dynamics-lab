"""Minute-boundary coordinator for the opt-in ongoing station.

The controller only compiles author constraints and publishes future actor
offers. It never executes an action or edits a sealed world prefix.
"""
from __future__ import annotations

from copy import deepcopy
from collections.abc import Mapping

from . import native


def initialize(pickup, actors, raw_profile):
    return native.initialize_station(pickup, actors, raw_profile)


def actor_callback(actor):
    """Run one station decision through the shared P3 native dispatcher."""
    from tools.native_platform_v0.p5 import service
    from tools.native_platform_v0.p3.agency import _dispatch_pending
    from tools.native_platform_v0.p5.world import scene_objects

    scene_id = service._attr(actor, "p3_scene_id")
    pickup, _rows = scene_objects(scene_id)
    minute = int(service._attr(pickup, "p4_clock", category="native_p3")["now"])
    meta = native.meta_for(pickup)
    projection = meta.get("published_projection")
    offers = meta.get("task_offers", [])
    from tools.native_platform_v0.p3.p4_social import step_social
    if step_social(actor):
        from tools.native_platform_v0.p3.agency import record
        record(actor, {"sim_minute": minute, "kind": "ongoing_station_social_callback_consumed",
                       "source": "native_p4_social", "goal_arbitration_deferred": True})
        return {"status": "SOCIAL_CALLBACK_CONSUMED", "minute": minute}
    alias = str(service._attr(actor, "p5_actor_alias", category="native_p5"))
    actor_offers = [row for row in offers if row.get("actor_alias") == alias]
    from .actor import advance_actor
    decision = advance_actor(actor, projection, actor_offers, minute)
    if decision.get("intent") is None or service._attr(actor, "pending_action", category="native_p3") is not None:
        return decision
    commitment = decision.get("commitment") or {}
    pending = {"status": "planned", "view": decision["view"],
               "goal": {"choice": commitment.get("goal_id"), "goal": commitment.get("task_kind")},
               "intent": decision["intent"], "ongoing_task": commitment}
    service._set(actor, "pending_action", pending, category="native_p3")
    return _dispatch_pending(actor, pending)


def publish_after_seal(scene_id, minute):
    """Publish only a decision over the just-sealed prefix for next callbacks."""
    from tools.native_platform_v0.p5 import service
    from tools.native_platform_v0.p5.world import scene_objects

    pickup, _rows = scene_objects(scene_id)
    profile = native.profile_for(pickup)
    projection, offers = author_offers(scene_id, minute)
    # author_offers persists its controller decision; reload to avoid clobbering
    # those append-only rows with a stale SaverDict snapshot.
    meta = native.meta_for(pickup)
    meta["published_projection"] = _safe(projection) if projection else None
    meta["task_offers"] = _safe(offers)
    meta["published_at_minute"] = int(minute)
    service._set(pickup, "p5_ongoing_station_meta", meta, category="native_p5")
    return {"published_at_minute": int(minute), "offer_count": len(offers),
            "projection_id": (f"{projection['station_id']}:{projection['version']}:{projection['bundle_hash'][:12]}"
                              if projection and projection.get("bundle_hash") else None)}


def _note_binding(rows, ledger, minute):
    for row in ledger:
        args = row.get("typed_args", {})
        receipt = args.get("physical_receipt", {})
        if (row.get("event_type") == "SOCIAL_REQUEST" and row.get("sealed") is True
                and int(row.get("minute", -1)) <= minute
                and receipt.get("status") == "settled"
                and receipt.get("after_location_id") == args.get("recipient_actor_id")
                and receipt.get("recipient_inventory_actor_id") == args.get("recipient_actor_id")
                and receipt.get("item_id") == args.get("note_id")
                and args.get("initiator_actor_id") is not None
                and args.get("recipient_actor_id") is not None):
            note_id = args.get("note_id")
            request_id = args.get("request_id")
            note = next((obj for obj in rows if int(getattr(obj, "id", -1)) == note_id), None)
            if (type(note_id) is int and note is not None
                    and str(note.attributes.get("p4_note_request_id", category="native_p3")) == str(request_id)):
                return note_id
    return None


def _scene_id(rows):
    for obj in rows:
        value = obj.attributes.get("p5_scene_id", category="native_p3")
        if value is None:
            value = obj.attributes.get("p5_scene_id", category="native_p5")
        if value:
            return str(value)
    return None


def _sealed_response(ledger, rows, note_id, minute):
    from tools.native_platform_v0.p5.world import _verified_social_responses

    verified = {row.get("event_id") for row in _verified_social_responses(ledger, rows,
                                                                            _scene_id(rows))}
    return next((row for row in ledger
                 if row.get("event_type") == "SOCIAL_RESPONSE" and row.get("sealed") is True
                 and row.get("event_id") in verified and int(row.get("minute", -1)) <= minute
                 and row.get("typed_args", {}).get("note_id") == note_id
                 and row.get("typed_args", {}).get("decision") in {"accepted", "rejected"}
                 and row.get("typed_args", {}).get("physical_receipt", {}).get("status") == "settled"), None)


def author_offers(scene_id, minute):
    """Run the existing high-level method search and queue only future offers."""
    from tools.native_platform_v0.p5 import service

    pickup, rows = service._scene_objects(scene_id)
    ledger = [service._plain_json(row) for row in service._attr(pickup, "p4_ledger", default=[])
              if row.get("sealed") is True and int(row.get("minute", -1)) <= minute]
    note_id = _note_binding(rows, ledger, minute)
    response = _sealed_response(ledger, rows, note_id, minute) if note_id else None
    profile = native.profile_for(pickup)
    if profile is None or profile.author is None:
        return {"station_id": profile.station_id, "version": profile.version,
                "bundle_hash": service._attr(pickup, "p5_ongoing_station_meta", category="native_p5", default={}).get("source_sha256"),
                "constraints": []}, []
    if note_id is None:
        projection = native.active_projection(pickup)
        return _projection_view(projection, profile), []
    from tools.native_platform_v0.p5.bundle import DEFAULT_ENTITIES
    from tools.trajectory_constraints_v0.types import StableEntity
    entities = dict(DEFAULT_ENTITIES)
    note_obj = next((obj for obj in rows if int(getattr(obj, "id", -1)) == note_id), None)
    if note_obj is None:
        return None, []
    entities["note"] = StableEntity("Item", str(note_id), str(note_obj.key))
    projection = native.active_projection(pickup, entities=entities)
    if projection is None or response is None:
        return _projection_view(projection, profile), []
    from tools.native_platform_v0.p5.story_process.model import default_actor_postresponse, load_request
    from tools.native_platform_v0.p5.story_process.planning import plan_story_process
    actor_objects = {str(service._attr(obj, "p5_actor_alias", category="native_p5")): obj
                     for obj in rows if service._attr(obj, "p5_actor_alias", category="native_p5") in {"A", "B"}}
    actor_local = {alias: _actor_local_row(actor, note_id, service) for alias, actor in actor_objects.items()}
    from tools.native_platform_v0.p5.story_process.native import _registered_destinations
    archive_room = next((obj for obj in rows
                         if service._attr(obj, "p5_story_archive", category="native_p5") is True), None)
    if archive_room is None:
        archive_id = service._attr(pickup, "p5_station_archive_room_id", category="native_p5")
        archive_room = next((obj for obj in rows if int(obj.id) == int(archive_id)), None) if archive_id else None
    if archive_room is None:
        raise ValueError("active station author constraint has no registered archive destination")
    destinations = _registered_destinations(scene_id, actor_objects, archive_room)
    offers = []
    for constraint in projection.constraints:
        source = constraint["source_constraint"]
        if source.get("kind") != "event_by_deadline" or source.get("event") != "note_archived":
            continue
        binding = constraint["control"]
        deadline = int(source["deadline"])
        raw = _runtime_request(profile, projection, constraint, binding, scene_id, note_id)
        request = load_request(raw)
        state = {"scenario_id": scene_id, "sealed_minute": minute,
                 "horizon": min(profile.horizon, 24), "request_id": request.request_id,
                 "request_version": request.version, "response": _response_projection(response, note_id),
                 "note": _note_state(note_obj, actor_objects), "actors": actor_local,
                 "destinations": destinations, "task_grant": dict(request.task_control_grant),
                 "current_obligations": _current_obligations(actor_objects, service),
                 "typed_trace": {"events": _typed_events(scene_id, note_id, minute, ledger,
                                                            actor_objects, service, all_rows=rows)},
                 "event_registry": request_registry()}
        strategy = service._attr(pickup, "p5_ongoing_station_strategy", category="native_p5", default="gtpyhop")
        decision = plan_story_process(request, state, strategy=strategy)
        # A decomposition can contain both handover and archive. Publish only
        # its first primitive as an actor offer; the next task is recomputed
        # from a later sealed prefix after the real handover receipt.
        for row in decision.get("task_requests", [])[:1]:
            offers.append({"offer_id": row["request_id"], "source": "AUTHOR",
                           "goal_id": constraint["constraint_id"],
                           "task_kind": row["task_kind"], "item_id": row["item_id"],
                           "destination_id": row["destination_id"],
                           "recipient_id": (actor_objects[row["actor_alias"]].id
                                            if row["task_kind"] == "handover_note" else None),
                           "deadline_minute": deadline, "prerequisites": list(row["prerequisites"]),
                           "constraint_id": constraint["constraint_id"], "item_key": note_obj.key,
                           "source_method_id": row["source_method_id"],
                           "control_source": row["control_source"], "grant_id": row["grant_id"],
                           "actor_alias": row["actor_alias"],
                           "projection_id": f"{projection.station_id}:{projection.version}:{projection.source_sha256[:12]}",
                           "entry_guard": constraint.get("locked_fragment", {}).get("entry_guard")
                                          if constraint.get("locked_fragment") else None})
        _save_controller_decision(pickup, constraint, projection, decision, minute, offers)
    return _projection_view(projection, profile), offers


def request_registry():
    from tools.native_platform_v0.p5.story_process.model import story_event_registry
    return story_event_registry()


def _projection_view(projection, profile):
    return {"station_id": profile.station_id, "version": projection.version if projection else profile.version,
            "bundle_id": projection.bundle_id if projection else None,
            "bundle_hash": projection.source_sha256 if projection else None,
            "horizon": profile.horizon,
            "constraints": [dict(row) for row in projection.constraints] if projection else []}


def _runtime_request(profile, projection, constraint, binding, scene_id, note_id):
    from tools.native_platform_v0.p5.story_process.model import default_actor_postresponse
    source = constraint["source_constraint"]
    mode = binding["mode"]
    locked = constraint["locked_fragment"]
    grant_id = f"{profile.station_id}:{constraint['constraint_id']}:fixed-native-grant"
    return {"schema": "story-process-request-v1",
            "request_id": f"{profile.station_id}:{constraint['constraint_id']}",
            "version": projection.version, "scenario_id": scene_id,
            "objective": {"kind": "archive_same_note_after_response", "note_id": note_id,
                          "by_minute": int(source["deadline"]),
                          "deadline_basis": "absolute_scenario_minute",
                          "response_event_type": "p5_note_response",
                          "archive_event_type": "p5_note_archived"},
            "control": {"mode": mode, "file_actor": binding["file_actor"],
                        "allowed_methods": list(binding["allowed_methods"]),
                        "source": binding["source"]},
            "actor_postresponse": default_actor_postresponse(),
            "task_control_grant": {"grant_id": grant_id, "scenario_id": scene_id,
                                    "actor_aliases": ["A", "B"],
                                    "task_kinds": ["handover_note", "archive_note"],
                                    "valid_until_minute": 24},
            "edit_policy": {"editable_future_fields": ["control.file_actor", "control.allowed_methods"],
                            "settled_fields_immutable": True, "grant_immutable": True},
            "locked_fragment": deepcopy(locked)}


def _response_projection(row, note_id):
    if row is None:
        return None
    return {"outcome": row["typed_args"]["decision"], "event_id": row["event_id"],
            "minute": int(row["minute"]), "note_id": note_id}


def _note_state(note, actors):
    holder = next((alias for alias, actor in actors.items() if note in actor.contents), None)
    if holder is None:
        holder = "ROOM" if note.location is not None else None
    return {"item_id": int(note.id), "location_id": int(note.location.id) if note.location else 1,
            "holder_alias": holder}


def _actor_local_row(actor, note_id, service):
    alias = str(service._attr(actor, "p5_actor_alias", category="native_p5"))
    local_items = [int(item.id) for item in actor.contents]
    local_items.extend(int(item.id) for item in (actor.location.contents if actor.location else [])
                       if item.access(actor, "view", default=True))
    commitments = service._plain_json(service._attr(actor, "ongoing_commitments", category="native_p5", default=[]))
    current = next((row for row in reversed(commitments)
                    if row.get("status") in {"ACCEPTED", "IN_PROGRESS", "SUSPENDED"}), None)
    pending = service._attr(actor, "pending_action")
    status = ("IN_PROGRESS" if pending else
              current["status"] if current and current.get("source") == "AUTHOR" else "IDLE")
    if status == "SUSPENDED":
        status = "BLOCKED"
    active = None
    if current and current.get("task_kind") in {"handover_note", "archive_note"}:
        active = {"request_id": str(current.get("commitment_id")),
                  "task_kind": current["task_kind"], "item_id": current.get("item_id"),
                  "destination_id": current.get("destination_id"),
                  "status": "BLOCKED" if current["status"] == "SUSPENDED" else current["status"]}
    declined = next((row for row in reversed(commitments)
                     if row.get("status") == "DECLINED" and row.get("task_kind") in {"handover_note", "archive_note"}), None)
    if declined:
        active = {"request_id": str(declined.get("commitment_id")),
                  "task_kind": declined["task_kind"], "item_id": declined.get("item_id"),
                  "destination_id": declined.get("destination_id"), "status": "REJECTED"}
        status = "REJECTED"
    return {"present": actor.location is not None, "can_receive_note": actor.location is not None,
            "willing_to_archive": True, "locally_observed_item_ids": sorted(set(local_items)),
            "active_task": active, "task_status": status}


def _current_obligations(actors, service):
    result = []
    for alias, actor in actors.items():
        commitments = service._plain_json(service._attr(actor, "ongoing_commitments", category="native_p5", default=[]))
        result.extend({"kind": "actor_commitment", "actor_alias": alias, **row} for row in commitments)
        pending = service._plain_json(service._attr(actor, "pending_action"))
        if pending:
            result.append({"kind": "native_pending_action", "actor_alias": alias,
                           "status": pending.get("status"), "operation_id": pending.get("operation_id")})
    return result


def _typed_events(scene_id, note_id, minute, ledger, actors, service, all_rows=None):
    from tools.native_platform_v0.p5.world import _verified_social_responses
    verified = {row.get("event_id") for row in _verified_social_responses(
        ledger, list(all_rows if all_rows is not None else actors.values()), scene_id)}
    events = []
    for row in ledger:
        if row.get("event_id") in verified and row.get("event_type") == "SOCIAL_RESPONSE" \
                and row.get("typed_args", {}).get("note_id") == note_id:
            args = row["typed_args"]
            by_id = {int(actor.id): alias for alias, actor in actors.items()}
            initiator = by_id.get(args.get("initiator_actor_id"))
            responder = by_id.get(args.get("responder_actor_id"))
            if initiator is None or responder is None or (initiator, responder) != ("A", "B"):
                continue
            events.append({"event_id": row["event_id"], "event_type": "p5_note_response",
                           "version": "1", "provenance": "committed_ledger",
                           "time": int(row["minute"]), "sequence": int(row["sequence"]),
                           "args": {"actor": {"entity_type": "Actor", "stable_id": "A", "label": "A"},
                                    "recipient": {"entity_type": "Actor", "stable_id": "B", "label": "B"},
                                    "item": {"entity_type": "Item", "stable_id": str(note_id), "label": "note"},
                                    "response": args.get("decision")}})
    for row in ledger:
        args = row.get("typed_args", {})
        if row.get("event_type") not in {"P5_ONGOING_STATION_NOTE_ARCHIVED", "P5_ONGOING_STATION_NOTE_HANDED_OVER"}:
            continue
        if args.get("item_id") != note_id or args.get("settled") is not True:
            continue
        actor_alias = args.get("actor_alias")
        if actor_alias not in {"A", "B"}:
            continue
        actor_obj = actors.get(actor_alias)
        if actor_obj is None:
            continue
        receipt_id = args.get("receipt_id")
        receipts = service._plain_json(service._attr(actor_obj, "native_receipts", default=[]))
        receipt = next((item for item in receipts if item.get("receipt_id") == receipt_id
                        and item.get("settled") is True
                        and item.get("item_id") == note_id
                        and item.get("ongoing_commitment_id") == args.get("commitment_id")), None)
        commitments = service._plain_json(service._attr(
            actor_obj, "ongoing_commitments", category="native_p5", default=[]))
        commitment = next((item for item in commitments
                           if item.get("commitment_id") == args.get("commitment_id")), None)
        if receipt is None or commitment is None:
            continue
        event_type = "p5_note_archived" if row["event_type"].endswith("ARCHIVED") else "p5_note_handed_over"
        if event_type == "p5_note_archived" and not (
                receipt.get("kind") == "drop" and commitment.get("task_kind") == "archive_note"
                and receipt.get("after_item_room_id") == commitment.get("destination_id")):
            continue
        typed_args = {"actor": {"entity_type": "Actor", "stable_id": actor_alias, "label": actor_alias},
                      "item": {"entity_type": "Item", "stable_id": str(note_id), "label": "note"}}
        if event_type == "p5_note_handed_over":
            recipient_alias = args.get("recipient_alias")
            if recipient_alias not in {"A", "B"}:
                continue
            recipient = actors.get(recipient_alias)
            if (receipt.get("kind") != "give" or commitment.get("task_kind") != "handover_note"
                    or recipient is None or receipt.get("recipient_id") != int(recipient.id)
                    or note_id not in receipt.get("recipient_inventory_ids", [])):
                continue
            typed_args["recipient"] = {"entity_type": "Actor", "stable_id": recipient_alias,
                                       "label": recipient_alias}
        events.append({"event_id": row["event_id"], "event_type": event_type, "version": "1",
                       "provenance": "committed_ledger", "time": int(row["minute"]),
                       "sequence": int(row["sequence"]), "args": typed_args})
    return events


def evidence(scene_id, now):
    """Readback of profile ownership, actor commitments, offers and real receipts."""
    from tools.native_platform_v0.p5 import service
    from tools.native_platform_v0.p5.world import scene_objects

    pickup, rows = scene_objects(scene_id)
    profile = native.profile_for(pickup)
    if profile is None:
        return None
    meta = native.meta_for(pickup)
    actors = {str(service._attr(obj, "p5_actor_alias", category="native_p5")): obj
              for obj in rows if service._attr(obj, "p5_actor_alias", category="native_p5") in {"A", "B"}}
    raw_author = service._attr(pickup, "p5_ongoing_station_author", category="native_p5")
    ledger = service._plain_json(service._attr(pickup, "p4_ledger", default=[]))
    note_id = _note_binding(rows, ledger, now)
    typed_events = _typed_events(scene_id, note_id, now,
                                 ledger,
                                 actors, service, all_rows=rows) if note_id is not None else []
    verdicts = _author_verdicts(scene_id, pickup, rows, raw_author, note_id, typed_events, now)
    commitments = []
    decisions = []
    for alias, actor in actors.items():
        actor_commitments = service._plain_json(service._attr(
            actor, "ongoing_commitments", category="native_p5", default=[]))
        commitments.extend({"actor_id": int(actor.id), "actor_alias": alias, **row}
                           for row in actor_commitments)
        actor_log = service._plain_json(service._attr(actor, "log", default=[]))
        decisions.extend({"actor_alias": alias, **row} for row in actor_log
                         if row.get("kind") == "ongoing_station_decision")
    activation_events = [row for row in ledger if row.get("event_type") == "P5_ONGOING_STATION_ACTIVATION"]
    return {"schema": "ongoing-station-native-evidence-v1",
            "station_id": profile.station_id, "profile_version": profile.version,
            "horizon": profile.horizon, "author_status": meta.get("author_status"),
            "source_sha256": meta.get("source_sha256"), "active_author_version": meta.get("active_author_version"),
            "active_author_sha256": native._digest(raw_author) if raw_author else None,
            "projection_history": meta.get("projection_history", []),
            "activation_event_ids": meta.get("activation_event_ids", []),
            "activation_events": activation_events,
            "controller_decisions": meta.get("controller_decisions", []),
            "actor_goal_decisions": decisions,
            "actor_decisions": decisions,
            "commitments": commitments,
            "pending_offers": meta.get("task_offers", []),
            "stale_projection_ids": meta.get("stale_projection_ids", []),
            "stale_offer_ids": meta.get("stale_offer_ids", []),
            "actor_commitments": {alias: service._plain_json(service._attr(
                actor, "ongoing_commitments", category="native_p5", default=[])) for alias, actor in actors.items()},
            "actor_goal_history": {alias: service._plain_json(service._attr(
                actor, "ongoing_goal_history", category="native_p5", default=[])) for alias, actor in actors.items()},
            "native_receipts": {alias: [row for row in service._plain_json(service._attr(
                actor, "native_receipts", default=[])) if row.get("ongoing_task_kind")] for alias, actor in actors.items()},
            "bound_note_id": note_id, "typed_events": typed_events, "real_verdicts": verdicts,
            "execution_authority": "shared_P3_actor_callback_and_native_receipts"}


def _author_verdicts(scene_id, pickup, rows, raw_author, note_id, typed_events, now):
    if not raw_author:
        return []
    try:
        from tools.native_platform_v0.p5.bundle import DEFAULT_ENTITIES, load_bundle
        from tools.native_platform_v0.p5.monitor import evaluate_bundle
        from tools.native_platform_v0.p5.story_process.model import story_event_registry
        from tools.trajectory_constraints_v0.trace import Event, Trace
        from tools.trajectory_constraints_v0.types import StableEntity
        from fractions import Fraction
        note_obj = next((obj for obj in rows if note_id is not None and int(obj.id) == note_id), None)
        entities = dict(DEFAULT_ENTITIES)
        if note_obj is not None:
            entities["note"] = StableEntity("Item", str(note_id), str(note_obj.key))
        bundle = load_bundle(service._plain_json(raw_author["bundle"]),
                             registry=story_event_registry(), entities=entities)
        trace = Trace(now=Fraction(now))
        for row in sorted(typed_events, key=lambda item: (item["time"], item["sequence"])):
            args = {key: StableEntity(value["entity_type"], value["stable_id"], value.get("label", ""))
                    if isinstance(value, Mapping) and set(value) >= {"entity_type", "stable_id"} else value
                    for key, value in row["args"].items()}
            trace.add_event(Event(row["event_id"], row["event_type"], Fraction(row["time"]),
                                  int(row["sequence"]), args, row["version"], row["provenance"]))
        trace.seal_events_through(Fraction(now))
        return evaluate_bundle(bundle, trace, registry=story_event_registry())
    except Exception as exc:
        return [{"status": "INDETERMINATE", "reason": f"typed station readback failed: {type(exc).__name__}: {exc}"}]


def _save_controller_decision(pickup, constraint, projection, decision, minute, offers):
    meta = native.meta_for(pickup)
    rows = list(meta.get("controller_decisions", []))
    rows.append({"minute": minute, "constraint_id": constraint["constraint_id"],
                 "station_id": projection.station_id, "source_bundle_id": projection.bundle_id,
                 "source_version": projection.version, "source_sha256": projection.source_sha256,
                 "decision": _safe(decision), "offer_ids": [row["offer_id"] for row in offers]})
    meta["controller_decisions"] = rows
    meta["task_offers"] = list(offers)
    pickup.attributes.add("p5_ongoing_station_meta", meta, category="native_p5")


def _safe(value):
    if isinstance(value, Mapping):
        return {str(k): _safe(v) for k, v in value.items() if k != "event_registry"}
    if isinstance(value, (list, tuple)):
        return [_safe(v) for v in value]
    if hasattr(value, "to_json"):
        return value.to_json()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def record_activation(scene_id, expected_version, minute):
    from tools.native_platform_v0.p5 import service
    from tools.native_platform_v0.p3.p4_world import append_event

    pickup, rows = service._scene_objects(scene_id)
    note = next((obj for obj in rows if service._attr(obj, "p4_note_request_id") is not None), None)
    entities = None
    if note is not None:
        from tools.native_platform_v0.p5.bundle import DEFAULT_ENTITIES
        from tools.trajectory_constraints_v0.types import StableEntity
        entities = dict(DEFAULT_ENTITIES)
        entities["note"] = StableEntity("Item", str(note.id), str(note.key))
    result = native.activate_author(pickup, expected_version=expected_version, now=minute,
                                    entities=entities)
    if result.get("ok") is True:
        meta = native.meta_for(pickup)
        event_id = f"station:{scene_id}:{minute}:activate:{expected_version}"
        meta["activation_event_ids"] = list(meta.get("activation_event_ids", [])) + [event_id]
        native._store_meta(pickup, meta)
    append_event(scene_id, {"event_type": "P5_ONGOING_STATION_ACTIVATION",
                            "event_id": f"station:{scene_id}:{minute}:activate:{expected_version}",
                            "typed_args": {"result": result, "expected_version": expected_version},
                            "sealed": True})
    return result


def record_edit(scene_id, raw_author, expected_version, minute):
    from tools.native_platform_v0.p5 import service
    from tools.native_platform_v0.p3.p4_world import append_event

    pickup, rows = service._scene_objects(scene_id)
    note = next((obj for obj in rows if service._attr(obj, "p4_note_request_id") is not None), None)
    entities = None
    if note is not None:
        from tools.native_platform_v0.p5.bundle import DEFAULT_ENTITIES
        from tools.trajectory_constraints_v0.types import StableEntity
        entities = dict(DEFAULT_ENTITIES)
        entities["note"] = StableEntity("Item", str(note.id), str(note.key))
    prior = evidence(scene_id, int(minute))
    prior_verdicts = (prior or {}).get("real_verdicts", {})
    constraint_rows = (prior_verdicts.get("constraints", [])
                       if isinstance(prior_verdicts, Mapping) else [])
    completed = {row["constraint_id"] for row in constraint_rows if row.get("status") == "SATISFIED"}
    evidenced = {row["constraint_id"] for row in constraint_rows if row.get("witness") is not None}
    result = native.edit_author(pickup, raw_author, expected_version=expected_version,
                                now=minute, completed_ids=completed,
                                evidenced_ids=evidenced, entities=entities)
    if result.get("ok") is True:
        meta = native.meta_for(pickup)
        current_offers = list(meta.get("task_offers", []))
        stale_ids = [row.get("offer_id") for row in current_offers
                     if row.get("source") == "AUTHOR" and row.get("offer_id")]
        meta["stale_offer_ids"] = list(meta.get("stale_offer_ids", [])) + stale_ids
        meta["task_offers"] = [row for row in current_offers if row.get("source") != "AUTHOR"]
        meta["published_projection"] = None
        meta["published_at_minute"] = int(minute)
        native._store_meta(pickup, meta)
        result["stale_offer_ids"] = stale_ids
    append_event(scene_id, {"event_type": "P5_ONGOING_STATION_AUTHOR_EDIT",
                            "event_id": f"station:{scene_id}:{minute}:edit:{expected_version}",
                            "typed_args": {"result": result, "expected_version": expected_version},
                            "sealed": True})
    return result


__all__ = ["initialize", "actor_callback", "publish_after_seal", "author_offers",
           "record_activation", "record_edit"]

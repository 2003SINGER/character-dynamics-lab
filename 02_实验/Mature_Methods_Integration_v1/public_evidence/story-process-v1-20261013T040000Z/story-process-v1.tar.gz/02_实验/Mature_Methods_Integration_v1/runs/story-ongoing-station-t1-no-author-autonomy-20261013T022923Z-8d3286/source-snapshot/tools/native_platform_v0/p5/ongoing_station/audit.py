"""Evidence-only checks for the first no-author ongoing-station case."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def _rows(value: Any) -> list[dict[str, Any]]:
    return [dict(row) for row in value if isinstance(row, Mapping)] if isinstance(value, list) else []


def _scene_db(db: Mapping[str, Any], scene_id: str) -> Mapping[str, Any] | None:
    scenes = db.get("scenes", [])
    if not isinstance(scenes, list):
        return None
    return next((row for row in scenes if isinstance(row, Mapping)
                 and row.get("scene_id") == scene_id), None)


def _actor_native_state(db: Mapping[str, Any], actor_id: int,
                        scene_id: str) -> tuple[list[dict[str, Any]], Mapping[str, Any], Mapping[str, Any]]:
    scene = _scene_db(db, scene_id)
    objects = scene.get("objects", []) if isinstance(scene, Mapping) else []
    for obj in objects if isinstance(objects, list) else []:
        if not isinstance(obj, Mapping) or obj.get("id") != actor_id:
            continue
        attrs = obj.get("attributes", {})
        if not isinstance(attrs, Mapping):
            return [], {}, {}
        native = attrs.get("native_p3", {})
        if not isinstance(native, Mapping):
            native = {}
        station = attrs.get("native_p5", {})
        if not isinstance(station, Mapping):
            station = {}
        return _rows(native.get("native_receipts", [])), native, station
    return [], {}, {}


def _no_author_profile(db: Mapping[str, Any], scene_id: str,
                       scene_identity: Mapping[str, Any]) -> bool:
    scene = _scene_db(db, scene_id)
    rooms = scene_identity.get("rooms", {})
    origin_id = rooms.get("origin") if isinstance(rooms, Mapping) else None
    objects = scene.get("objects", []) if isinstance(scene, Mapping) else []
    pickup = next((row for row in objects if isinstance(row, Mapping)
                   and row.get("id") == origin_id), None)
    attrs = pickup.get("attributes", {}) if isinstance(pickup, Mapping) else {}
    station = attrs.get("native_p5", {}) if isinstance(attrs, Mapping) else {}
    if not isinstance(station, Mapping):
        return False
    profile = station.get("p5_ongoing_station_profile")
    meta = station.get("p5_ongoing_station_meta")
    return (isinstance(profile, Mapping) and profile.get("author", "missing") is None
            and isinstance(meta, Mapping) and meta.get("author_status") == "ABSENT"
            and station.get("p5_ongoing_station_author") is None
            and station.get("p5_ongoing_station_staged_author") is None)


def audit_t1(trace: Mapping[str, Any], scene: Mapping[str, Any],
             db: Mapping[str, Any]) -> dict[str, Any]:
    """Check author-free self-goal -> physical settlement -> next self-goal.

    Missing or schema-drifted evidence is NOT_CERTIFIED, never inferred from a
    planner proposal or the episode's final status.
    """
    station = trace.get("ongoing_station")
    if not isinstance(station, Mapping):
        return {"schema": "ongoing-station-t1-audit-v1", "status": "NOT_CERTIFIED",
                "pass": False, "reason": "final trace omitted ongoing_station evidence"}
    decisions = _rows(station.get("actor_goal_decisions", station.get("actor_decisions")))
    if not decisions:
        for actor_row in _rows(trace.get("actor_evidence")):
            for log_row in _rows(actor_row.get("log")):
                if log_row.get("kind") == "ongoing_station_decision":
                    decisions.append(log_row)
    commitments = _rows(station.get("commitments", station.get("actor_commitments")))
    scene_id = trace.get("scene_id")
    scene_actors = scene.get("actors", {})
    aliases = {alias: row.get("id") for alias, row in scene_actors.items()
               if isinstance(scene_actors, Mapping) and isinstance(row, Mapping)}
    activation_events = station.get("activation_events", [])
    activation_ids = station.get("activation_event_ids", [])
    has_author_activation = bool(activation_events or activation_ids)
    db_has_null_author_profile = (isinstance(scene_id, str)
                                  and _no_author_profile(db, scene_id, scene))
    author_sources = [row for row in decisions
                      if row.get("source") == "AUTHOR"
                      or (isinstance(row.get("commitment"), Mapping)
                          and row["commitment"].get("source") == "AUTHOR")]
    per_actor: dict[str, Any] = {}
    for alias in ("A", "B"):
        actor_id = aliases.get(alias)
        actor_decisions = [row for row in decisions if row.get("actor_id") == actor_id]
        self_decisions = [row for row in actor_decisions
                          if (isinstance(row.get("commitment"), Mapping)
                              and row["commitment"].get("source") == "SELF")]
        actor_commitments = [row for row in commitments
                             if (row.get("actor_id") == actor_id or row.get("actor_alias") == alias)
                             and row.get("source") == "SELF"]
        settled = [row for row in actor_commitments
                   if row.get("status") == "SETTLED" and row.get("receipt_ids")]
        physical_receipts, native_actor, station_actor = (_actor_native_state(db, actor_id, scene_id)
                                                          if type(actor_id) is int and isinstance(scene_id, str)
                                                          else ([], {}, {}))
        persisted_commitments = _rows(station_actor.get("ongoing_commitments", []))
        if persisted_commitments:
            actor_commitments = persisted_commitments
        receipt_rows = {row.get("receipt_id"): row for row in physical_receipts
                        if row.get("settled") is True and row.get("receipt_id")}
        receipt_ids = set(receipt_rows)
        witnessed_settled = [row for row in settled
                             if any(receipt_id in receipt_ids
                                    and receipt_rows[receipt_id].get("ongoing_commitment_id") == row.get("commitment_id")
                                    for receipt_id in row.get("receipt_ids", []))]
        later_self_choice = False
        for commitment in witnessed_settled:
            settled_at = commitment.get("updated_minute")
            goal_id = commitment.get("goal_id")
            if type(settled_at) is not int:
                continue
            for selected in actor_decisions:
                later = selected.get("commitment")
                if (not isinstance(later, Mapping) or later.get("source") != "SELF"
                        or later.get("goal_id") == goal_id
                        or not later.get("commitment_id")
                        or later.get("commitment_id") == commitment.get("commitment_id")
                        or type(selected.get("minute")) is not int
                        or selected["minute"] <= settled_at):
                    continue
                later_row = next((row for row in actor_commitments
                                  if row.get("commitment_id") == later.get("commitment_id")
                                  and row.get("source") == "SELF"), None)
                later_receipt = bool(later_row and any(
                    receipt_id in receipt_ids
                    and receipt_rows[receipt_id].get("ongoing_commitment_id") == later_row.get("commitment_id")
                    for receipt_id in later_row.get("receipt_ids", [])))
                pending = native_actor.get("pending_action")
                pending_task = pending.get("ongoing_task") if isinstance(pending, Mapping) else None
                pending_for_later = (isinstance(pending_task, Mapping)
                                     and pending_task.get("commitment_id") == later.get("commitment_id"))
                if later_row and later_row.get("status") in {"ACCEPTED", "IN_PROGRESS", "SETTLED"} \
                        and (later_receipt or pending_for_later):
                    later_self_choice = True
                    break
            if later_self_choice:
                break
        per_actor[alias] = {
            "actor_id": actor_id,
            "self_goal_decision_count": len(self_decisions),
            "self_commitment_count": len(actor_commitments),
            "settled_self_commitments_with_native_db_receipt": len(witnessed_settled),
            "later_distinct_self_goal_selected_and_dispatched_or_pending": later_self_choice,
            "pass": bool(witnessed_settled and later_self_choice),
        }
    passed = (all(row.get("pass") is True for row in per_actor.values())
              and not has_author_activation and not author_sources
              and isinstance(_scene_db(db, scene_id), Mapping)
              and db_has_null_author_profile)
    return {"schema": "ongoing-station-t1-audit-v1",
            "status": "PASS" if passed else "NOT_CERTIFIED",
            "pass": passed,
            "criteria": {
                "zero_author_activation": not has_author_activation and not author_sources,
                "independent_db_confirms_author_null": db_has_null_author_profile,
                "both_roles_self_goal_settle_then_reselect": all(
                    row.get("pass") is True for row in per_actor.values()),
                "trace_db_scene_identity_matches": isinstance(_scene_db(db, scene_id), Mapping)},
            "actors": per_actor,
            "evidence_source": "native actor decisions + persisted Evennia commitments + independent Evennia DB receipts",
            "limits": ["Does not establish psychological realism or algorithmic advantage."]}

import json
from pathlib import Path
import unittest
from unittest.mock import patch

from tools.native_platform_v0.p5.ongoing_station.audit import audit_t1
from tools.native_platform_v0.p5.ongoing_station.model import load_profile
from tools.native_platform_v0.p5.ongoing_station.replay import build_replay
from tools.native_platform_v0.p5.ongoing_station.runner import (
    SUITE_PATH, _allocate_run_dir, _compact_step, load_case, run_case,
)


class OngoingStationRunnerTests(unittest.TestCase):
    def test_t1_is_author_null_and_fixed_seed_horizon(self):
        suite, case = load_case("t1-no-author-autonomy", SUITE_PATH)
        self.assertIsNone(suite["common"]["ongoing_station"]["author"])
        self.assertEqual((suite["common"]["seed"], suite["common"]["horizon"]),
                         (20261013, 24))
        self.assertFalse(case["expected"]["npc_commands_from_runner"])
        self.assertFalse(case["expected"]["external_actor_observation"])
        self.assertEqual(set(suite["acceptance_contract"]),
                         {"T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "hold_until"})
        self.assertTrue(suite["future_matched_pair_contract"]["not_yet_runnable"])
        self.assertEqual(suite["run_policy"]["max_scenes"], 3)
        profile = load_profile(suite["common"]["ongoing_station"])
        self.assertIsNone(profile.author)
        bundle_path = SUITE_PATH.parent / suite["common"]["bundle"]
        bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
        from tools.native_platform_v0.p5.story_process.model import story_event_registry
        from tools.native_platform_v0.p5.bundle import load_bundle
        self.assertEqual(load_bundle(bundle, registry=story_event_registry()).goals, ())

    def test_run_requires_explicit_execute_and_does_not_contact_rpc(self):
        calls = []
        with self.assertRaises(PermissionError):
            run_case("t1-no-author-autonomy", call_rpc=lambda *args: calls.append(args))
        self.assertEqual(calls, [])

    def test_run_directories_are_non_overwriting_and_publication_compatible(self):
        created = set()
        token = iter(("abc111", "def222"))

        def mkdir(path, mode=0o777, parents=False, exist_ok=False):
            key = str(path)
            if key in created and not exist_ok:
                raise FileExistsError(key)
            created.add(key)

        with patch("pathlib.Path.mkdir", autospec=True, side_effect=mkdir), \
                patch("secrets.token_hex", side_effect=lambda _n: next(token)):
            root = Path("/virtual/runs")
            first = _allocate_run_dir(root, "t1-no-author-autonomy")
            second = _allocate_run_dir(root, "t1-no-author-autonomy")
        self.assertNotEqual(first, second)
        self.assertTrue(first.name.startswith("story-"))

    def test_step_capture_keeps_one_delta_and_rejects_cumulative_shape(self):
        step = {"scene_id": "scene1", "rounds": [{"minute": 1, "actor_steps": [],
                "ongoing_station": {"decisions": []}, "final": {"huge": "trace"}}],
                "final": {"huge": "trace"}}
        compact = _compact_step(step)
        self.assertEqual(compact["round"]["minute"], 1)
        self.assertNotIn("final", compact["round"])
        self.assertEqual(compact["omitted_cumulative_fields"], ["final"])
        with self.assertRaises(RuntimeError):
            _compact_step({"rounds": [{"minute": 1}, {"minute": 2}]})

    def test_t1_audit_uses_exact_scene_database_export_and_post_selection_receipt(self):
        trace = {
            "scene_id": "scene1",
            "ongoing_station": {
                "activation_events": [],
                "actor_goal_decisions": [
                    {"actor_id": 10, "minute": 1, "commitment": {
                        "commitment_id": "self-a", "source": "SELF", "goal_id": "deliver"}},
                    {"actor_id": 10, "minute": 5, "commitment": {
                        "commitment_id": "route-a", "source": "SELF", "goal_id": "routine"}},
                ],
                "commitments": [
                    {"actor_id": 10, "commitment_id": "self-a", "source": "SELF",
                     "goal_id": "deliver", "status": "SETTLED", "updated_minute": 4,
                     "receipt_ids": ["r1"]},
                    {"actor_id": 10, "commitment_id": "route-a", "source": "SELF",
                     "goal_id": "routine", "status": "SETTLED", "updated_minute": 6,
                     "receipt_ids": ["r2"]},
                ],
            },
        }
        scene = {"scene_id": "scene1", "rooms": {"origin": 1},
                 "actors": {"A": {"id": 10}, "B": {"id": 20}}}
        db = {"schema": "native-p3-db-evidence-v1", "scenes": [{"scene_id": "scene1", "objects": [
            {"id": 1, "attributes": {"native_p5": {
                "p5_ongoing_station_profile": {"author": None},
                "p5_ongoing_station_meta": {"author_status": "ABSENT"}}}},
            {"id": 10, "attributes": {"native_p3": {"native_receipts": [
                {"receipt_id": "r1", "settled": True, "ongoing_commitment_id": "self-a"},
                {"receipt_id": "r2", "settled": True, "ongoing_commitment_id": "route-a"}]}}},
            {"id": 20, "attributes": {"native_p3": {"native_receipts": [
                {"receipt_id": "r3", "settled": True, "ongoing_commitment_id": "self-b"}]}}},
        ]}]}
        # A valid actor B record must independently contain both a first and a later
        # distinct settled goal; add the same verified shape for the second role.
        trace["ongoing_station"]["actor_goal_decisions"] += [
            {"actor_id": 20, "minute": 1, "commitment": {
                "commitment_id": "self-b", "source": "SELF", "goal_id": "deliver-b"}},
            {"actor_id": 20, "minute": 8, "commitment": {
                "commitment_id": "route-b", "source": "SELF", "goal_id": "routine-b"}},
        ]
        trace["ongoing_station"]["commitments"] += [
            {"actor_id": 20, "commitment_id": "self-b", "source": "SELF",
             "goal_id": "deliver-b", "status": "SETTLED", "updated_minute": 7,
             "receipt_ids": ["r3"]},
            {"actor_id": 20, "commitment_id": "route-b", "source": "SELF",
             "goal_id": "routine-b", "status": "SETTLED", "updated_minute": 9,
             "receipt_ids": ["r4"]},
        ]
        actor_b = next(row for row in db["scenes"][0]["objects"] if row["id"] == 20)
        actor_b["attributes"]["native_p3"]["native_receipts"].append(
            {"receipt_id": "r4", "settled": True, "ongoing_commitment_id": "route-b"})
        actor_a = next(row for row in db["scenes"][0]["objects"] if row["id"] == 10)
        actor_a["attributes"]["native_p5"] = {"ongoing_commitments": [
            row for row in trace["ongoing_station"]["commitments"] if row["actor_id"] == 10]}
        actor_b["attributes"]["native_p5"] = {"ongoing_commitments": [
            row for row in trace["ongoing_station"]["commitments"] if row["actor_id"] == 20]}
        result = audit_t1(trace, scene, db)
        self.assertTrue(result["pass"], json.dumps(result, sort_keys=True))
        actor_b["attributes"]["native_p5"]["ongoing_commitments"].pop()
        self.assertFalse(audit_t1(trace, scene, db)["pass"])
        actor_b["attributes"]["native_p5"]["ongoing_commitments"].append(
            trace["ongoing_station"]["commitments"][-1])
        trace["ongoing_station"]["activation_event_ids"] = ["activation-1"]
        self.assertFalse(audit_t1(trace, scene, db)["pass"])
        trace["ongoing_station"]["activation_event_ids"] = []
        db["scenes"][0]["scene_id"] = "another-scene"
        self.assertFalse(audit_t1(trace, scene, db)["pass"])

    def test_t1_audit_does_not_certify_plan_without_later_physical_receipt(self):
        trace = {"scene_id": "scene1", "ongoing_station": {
            "activation_events": [], "actor_goal_decisions": [
                {"actor_id": 10, "minute": 1, "commitment": {"source": "SELF", "goal_id": "g1"}},
                {"actor_id": 10, "minute": 4, "commitment": {"source": "SELF", "goal_id": "g2"}},
            ], "commitments": [{"actor_id": 10, "source": "SELF", "goal_id": "g1",
                "status": "SETTLED", "updated_minute": 3, "receipt_ids": ["r1"]}]}}
        db = {"scenes": [{"scene_id": "scene1", "objects": [
            {"id": 10, "attributes": {"native_p3": {"native_receipts": [
                {"receipt_id": "r1", "settled": True}]}}}]}]}
        result = audit_t1(trace, {"rooms": {"origin": 1},
                                  "actors": {"A": {"id": 10}}}, db)
        self.assertFalse(result["pass"])
        self.assertFalse(result["actors"]["A"]["later_distinct_self_goal_selected_and_dispatched_or_pending"])

    def test_replay_is_chronological_and_keeps_source_ids(self):
        trace = {"scene_id": "scene1", "run_status": "COMPLETE", "complete_through": 24,
                 "ledger": [{"minute": 4, "event_id": "e4", "event_type": "P3_RECEIPT"},
                            {"minute": 2, "event_id": "e2", "event_type": "P3_INTENT"}],
                 "ongoing_station": {"actor_goal_decisions": [
                     {"minute": 3, "actor_alias": "A", "decision_id": "d3",
                      "commitment": {"source": "SELF", "goal_id": "g1",
                                     "commitment_id": "route-a", "task_kind": "routine_route",
                                     "route_waypoints": [2, 1],
                                     "waypoint_receipts": ["r1", None]},
                      "disposition": "IN_PROGRESS", "rationale": "local route"}]}}
        replay = build_replay(trace)
        self.assertLess(replay.index("Minute 2"), replay.index("Minute 3"))
        self.assertLess(replay.index("Minute 3"), replay.index("Minute 4"))
        self.assertIn("e2", replay)
        self.assertIn("d3", replay)
        self.assertIn("waypoint_receipts=['r1', None]", replay)

    def test_replay_falls_back_to_actor_logs_and_native_receipts(self):
        trace = {"scene_id": "scene1", "ledger": [], "actor_evidence": [{
            "actor_alias": "A", "actor_id": 10,
            "log": [{"kind": "ongoing_station_decision", "actor_id": 10,
                     "minute": 2, "decision_id": "d2", "commitment": {
                         "source": "SELF", "goal_id": "route", "task_kind": "routine_route"},
                     "intent": {"operator": "move"}, "disposition": "IN_PROGRESS",
                     "rationale": "route selected"}],
            "native_receipts": [{"receipt_id": "r3", "sim_minute": 3,
                                 "settled": True, "kind": "move",
                                 "ongoing_commitment_id": "self-route"}],
        }]}
        replay = build_replay(trace)
        self.assertLess(replay.index("Minute 2"), replay.index("Minute 3"))
        self.assertIn("d2", replay)
        self.assertIn("r3", replay)
        self.assertIn("NPC A", replay)


if __name__ == "__main__":
    unittest.main()

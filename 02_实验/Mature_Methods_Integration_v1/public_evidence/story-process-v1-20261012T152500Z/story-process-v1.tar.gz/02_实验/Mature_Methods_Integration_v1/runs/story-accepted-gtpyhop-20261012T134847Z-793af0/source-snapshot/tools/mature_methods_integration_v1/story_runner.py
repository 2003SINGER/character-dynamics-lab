"""Run one opt-in native story-process case against the existing P5 service.

The native seal callback performs planning. This client only advances one
minute at a time, reacts to returned native evidence, and reads one full final
trace and one independent DB export. It never invokes a planner or NPC command.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import secrets
import shutil
import subprocess
from typing import Any, Callable, Mapping

from tools.mature_methods_integration_v1.runner import (
    RUNS_DIR as DEFAULT_RUNS_DIR,
    _rpc_record,
    _write_once,
)
from tools.native_platform_v0.p3.mcp_stdio import PROJECT_ROOT, rpc_call
from tools.native_platform_v0.p5.runner import export_db_evidence


SUITE_PATH = PROJECT_ROOT / "tools/mature_methods_integration_v1/story_cases/suite.json"
SOURCE_PATHS = (
    "tools/mature_methods_integration_v1/story_runner.py",
    "tools/mature_methods_integration_v1/story_cases/suite.json",
    "tools/mature_methods_integration_v1/story_cases/story-bundle-v1.json",
    "tools/mature_methods_integration_v1/tests/test_story_cases_contract.py",
    "tools/native_platform_v0/p5/story_process/model.py",
    "tools/native_platform_v0/p5/story_process/__init__.py",
    "tools/native_platform_v0/p5/story_process/native.py",
    "tools/native_platform_v0/p5/story_process/planning.py",
    "tools/native_platform_v0/p5/story_process/actor.py",
    "tools/native_platform_v0/p5/service.py",
    "tools/native_platform_v0/p5/agency.py",
    "tools/native_platform_v0/p5/world.py",
    "tools/native_platform_v0/p3/control_service.py",
    "tools/native_platform_v0/p3/mcp_stdio.py",
)
SCENE_TOKEN = "${scene_id}"


def _sha(raw: bytes) -> str:
    return sha256(raw).hexdigest()


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _git_text(*args: str) -> str | None:
    result = subprocess.run(["git", *args], cwd=PROJECT_ROOT,
                            capture_output=True, text=True, check=False)
    return result.stdout.strip() if result.returncode == 0 else None


def _source_manifest(snapshot_root: Path) -> dict[str, Any]:
    snapshot_root.mkdir(parents=True, exist_ok=False)
    files = {name: _sha((PROJECT_ROOT / name).read_bytes())
             if (PROJECT_ROOT / name).is_file() else "MISSING" for name in SOURCE_PATHS}
    snapshot_paths = {}
    for name, digest in files.items():
        if digest == "MISSING":
            continue
        destination = snapshot_root / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PROJECT_ROOT / name, destination)
        copied_hash = _sha(destination.read_bytes())
        if copied_hash != digest:
            raise RuntimeError(f"source snapshot hash mismatch for {name}")
        snapshot_paths[name] = str(destination.relative_to(snapshot_root))
    packed = json.dumps(files, sort_keys=True, separators=(",", ":")).encode("utf-8")
    remotes = _git_text("remote")
    remote_names = remotes.splitlines() if remotes else []
    review_remote = "origin" if "origin" in remote_names else None
    review_tracking_ref = f"refs/remotes/{review_remote}/webgpt-sync" if review_remote else None
    local_review_hash = _git_text("rev-parse", "refs/heads/webgpt-sync")
    tracking_review_hash = (_git_text("rev-parse", review_tracking_ref)
                            if review_tracking_ref else None)
    return {"git_head": _git_text("rev-parse", "HEAD"),
            "git_branch": _git_text("symbolic-ref", "--short", "HEAD"),
            "remote_review_ref": "refs/heads/webgpt-sync",
            "remote_name": review_remote,
            "remote_tracking_ref": review_tracking_ref,
            "remote_tracking_ref_sha256_target": tracking_review_hash,
            "local_review_ref": "refs/heads/webgpt-sync",
            "local_review_ref_sha": local_review_hash,
            "configured_upstream_ref": _git_text("rev-parse", "--abbrev-ref",
                                                   "--symbolic-full-name", "@{upstream}"),
            "working_tree_file_sha256": files,
            "source_snapshot_relative_paths": snapshot_paths,
            "working_tree_file_set_sha256": _sha(packed)}


def _allocate_run_dir(root: Path, case_id: str) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    slug = "".join(c if c.isalnum() or c in "-_" else "-" for c in case_id)[:48]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    for _ in range(16):
        path = root / f"story-{slug}-{stamp}-{secrets.token_hex(3)}"
        try:
            path.mkdir(exist_ok=False)
            return path
        except FileExistsError:
            continue
    raise FileExistsError("could not allocate a unique non-overwriting story run directory")


def _replace_scene_token(value: Any, scene_id: str) -> Any:
    if isinstance(value, str):
        return value.replace(SCENE_TOKEN, scene_id)
    if isinstance(value, list):
        return [_replace_scene_token(item, scene_id) for item in value]
    if isinstance(value, Mapping):
        return {key: _replace_scene_token(item, scene_id) for key, item in value.items()}
    return deepcopy(value)


def _at_path(value: Any, path: str) -> Any:
    current = value
    for key in path.split("."):
        if isinstance(current, Mapping):
            current = current.get(key)
        elif isinstance(current, list) and key.isdigit():
            index = int(key)
            current = current[index] if index < len(current) else None
        else:
            return None
    return current


def _matching_actions(rules: list[Mapping[str, Any]], observation: Mapping[str, Any],
                      fired: set[int], *, minute: int | None = None) -> list[dict[str, Any]]:
    actions = []
    for index, rule in enumerate(rules):
        if index in fired:
            continue
        if set(rule) == {"at_minute", "action"}:
            if type(rule["at_minute"]) is not int or rule["at_minute"] < 1:
                raise ValueError("scheduled author intervention requires a positive at_minute")
            if rule["at_minute"] == minute:
                action = rule["action"]
                if not isinstance(action, Mapping) or not isinstance(action.get("kind"), str):
                    raise ValueError("scheduled action needs a typed native intervention")
                actions.append({"rule_index": index, "action": deepcopy(dict(action))})
            continue
        condition = rule.get("when")
        if set(rule) != {"when", "action"} or not isinstance(condition, Mapping) or set(condition) != {"path", "equals"}:
            raise ValueError("action needs either at_minute/action or exact when.path/when.equals/action")
        if _at_path(observation, condition["path"]) == condition["equals"]:
            action = rule.get("action")
            if not isinstance(action, Mapping) or not isinstance(action.get("kind"), str):
                raise ValueError("reactive action needs a typed native intervention")
            actions.append({"rule_index": index, "action": deepcopy(dict(action))})
    return actions


def _compact_typed_delta(trace: Any, minute: int) -> Any:
    if not isinstance(trace, Mapping):
        return trace
    result = {key: value for key, value in trace.items() if key not in {"events", "points"}}
    result["events"] = [row for row in trace.get("events", [])
                        if isinstance(row, Mapping) and str(row.get("time")) == str(minute)]
    result["points"] = [row for row in trace.get("points", [])
                        if isinstance(row, Mapping) and str(row.get("time")) == str(minute)]
    return result


def _rpc_step_record(rpc: Callable, run_dir: Path, index: int,
                     args: dict[str, Any], minute: int) -> dict[str, Any]:
    """Persist the request and only the per-minute response, dropping its cumulative final trace."""
    stem = f"rpc-{index:04d}-step_world"
    _write_once(run_dir / f"{stem}-request.json", args)
    try:
        result = rpc("step_world", args)
    except Exception as exc:
        _write_once(run_dir / f"{stem}-error.json", {
            "rpc_operation": "step_world", "error_type": type(exc).__name__,
            "error_message": str(exc)[:500]})
        raise
    rounds = result.get("rounds") if isinstance(result, Mapping) else None
    if not isinstance(rounds, list):
        raise RuntimeError("step_world response omitted rounds[]")
    # service.step_world also returns a cumulative `final` trace; it is intentionally
    # omitted here because the final standalone get_trace below is the sole full copy.
    compact_rounds = []
    for row in rounds:
        if not isinstance(row, Mapping):
            raise RuntimeError("step_world round row must be an object")
        compact_rounds.append({key: row.get(key) for key in
                               ("minute", "edits", "interventions", "director", "actor_steps",
                                "snapshot", "minute_complete", "event_complete",
                                "unsealed_event_ids", "trace_frontier", "verdicts")})
        compact_rounds[-1]["story_process"] = row.get("story_process")
        compact_rounds[-1]["typed_trace"] = _compact_typed_delta(row.get("typed_trace"), minute)
    _write_once(run_dir / f"{stem}-response.json", {
        "scene_id": result.get("scene_id"), "round_count": len(rounds),
        "rounds": compact_rounds, "omitted_cumulative_fields": ["final"]})
    return dict(result)


def _compact_trace_identity(evidence: Mapping[str, Any]) -> dict[str, Any]:
    story = evidence.get("story_process")
    return {"scene_id": evidence.get("scene_id"), "now": evidence.get("now"),
            "complete_through": evidence.get("complete_through"),
            "bundle_identity": evidence.get("bundle_identity"),
            "story_process": story,
            "raw_trace_sha256": _sha(json.dumps(evidence, sort_keys=True,
                                                 ensure_ascii=False, separators=(",", ":"),
                                                 default=str).encode())}


def _patch_request(request: Mapping[str, Any], patch: Mapping[str, Any], *, new_version: int) -> dict[str, Any]:
    result = deepcopy(dict(request))
    for dotted, value in patch.items():
        keys = dotted.split(".")
        if len(keys) != 2 or keys[0] != "control" or keys[1] not in {"file_actor", "allowed_methods"}:
            raise ValueError("future request edit may patch only control.file_actor/allowed_methods")
        result["control"][keys[1]] = deepcopy(value)
    result["version"] = new_version
    return result


def _story_envelope(suite: Mapping[str, Any], case: Mapping[str, Any]) -> dict[str, Any]:
    common = suite["common"]
    envelope = {
        "schema": "story-process-request-v1",
        "request_id": f"story-{case['case_id']}",
        "version": 1,
        "scenario_id": None,
        "objective": deepcopy(common["objective"]),
        "control": deepcopy(case["control"]),
        "actor_postresponse": deepcopy(case.get("actor_postresponse", {
            "accepted": {"B_archive": "WILLING", "B_return": "WILLING", "A_archive": "WILLING"},
            "rejected": {"B_archive": "UNWILLING", "B_return": "WILLING", "A_archive": "WILLING"}})),
        "task_control_grant": deepcopy(common["task_control_grant"]),
        "edit_policy": deepcopy(common["edit_policy"]),
        "locked_fragment": None,
    }
    if case.get("locked_fragment_template") is not None:
        envelope["locked_fragment"] = deepcopy(case["locked_fragment_template"])
    if case.get("objective_override"):
        envelope["objective"].update(deepcopy(case["objective_override"]))
    if case.get("task_control_grant_override"):
        envelope["task_control_grant"].update(deepcopy(case["task_control_grant_override"]))
    return envelope


def run_case(case_id: str, *, suite_path: Path = SUITE_PATH,
             runs_dir: Path = DEFAULT_RUNS_DIR, call_rpc: Callable | None = None,
             export_db: bool = True, lifecycle_dir: Path | None = None) -> tuple[dict[str, Any], Path]:
    """Run exactly one frozen case; an error after reset is always retained."""
    rpc = call_rpc or rpc_call
    suite = _read_json(suite_path)
    matches = [row for row in suite["cases"] if row.get("case_id") == case_id]
    if len(matches) != 1:
        raise ValueError(f"case_id must identify exactly one frozen case: {case_id}")
    case = matches[0]
    if case.get("blocked_until_native_resource_intervention") is True:
        raise RuntimeError("case has no registered lawful resource intervention; refusing to fabricate a player action")
    run_dir = _allocate_run_dir(runs_dir, case_id)
    lifecycle_copy = None
    if lifecycle_dir is not None:
        lifecycle_copy = run_dir / "service-lifecycle"
        shutil.copytree(lifecycle_dir, lifecycle_copy)
    bundle_path = suite_path.parent / suite["common"]["bundle"]
    bundle_bytes = bundle_path.read_bytes()
    bundle = json.loads(bundle_bytes.decode("utf-8"))
    story_request = _story_envelope(suite, case)
    source_manifest = _source_manifest(run_dir / "source-snapshot")
    identity = {"schema": "native-story-process-run-identity-v1",
                "case_id": case_id, "pair_id": case.get("pair_id"),
                "strategy": case["strategy"], "preset": case["preset"],
                "suite_sha256": _sha(suite_path.read_bytes()),
                "bundle_sha256": _sha(bundle_bytes), "source_manifest": source_manifest,
                "runtime": {"horizon": suite["common"]["horizon"],
                            "seed": suite["common"]["seed"],
                            "native_service": "existing P5 / Evennia / Ensemble"},
                "service_lifecycle_artifacts": (str(lifecycle_copy.relative_to(run_dir))
                                                 if lifecycle_copy else None),
                "story_request_template": story_request,
                "raw_private_dialogue_or_database": "NOT_INCLUDED"}
    _write_once(run_dir / "identity.json", identity)
    scene_id: str | None = None
    call_index = 0
    fired: set[int] = set()
    steps: list[dict[str, Any]] = []
    status = "INCOMPLETE"
    error = None
    final_trace = None
    db_evidence, db_export = None, {"status": "NOT_REQUESTED"}
    try:
        reset_args = {"bundle": bundle,
                      "initial_social_preset": case["preset"],
                      "horizon": suite["common"]["horizon"],
                      "seed": suite["common"]["seed"],
                      "director_enabled": True,
                      "shared_supply": suite["common"]["shared_supply"],
                      "initial_main_open": suite["common"]["initial_main_open"],
                      "story_process": story_request,
                      "story_strategy": case["strategy"]}
        call_index += 1
        created = _rpc_record(rpc, run_dir, call_index, "reset_p5_scenario", reset_args)
        scene = created.get("scene", created) if isinstance(created, Mapping) else None
        scene_id = scene.get("scene_id") if isinstance(scene, Mapping) else None
        if not isinstance(scene_id, str) or not scene_id:
            raise RuntimeError("P5 story reset returned no native scene identity")
        _write_once(run_dir / "scene_identity.json", {
            "scene_id": scene_id, "created_at": created.get("created_at") if isinstance(created, Mapping) else None,
            "active_bundle": scene.get("active_bundle"), "preset": scene.get("preset"),
            "seed": scene.get("seed"), "horizon": scene.get("horizon"),
            "player": scene.get("player"), "items": scene.get("items"),
            "story_request_template_sha256": _sha(json.dumps(story_request, sort_keys=True,
                                                               separators=(",", ":")).encode())})
        # One initial full read confirms the scene, request binding and sealed frontier.
        call_index += 1
        initial_args = {"scene_id": scene_id}
        _write_once(run_dir / f"rpc-{call_index:04d}-get_trace-request.json", initial_args)
        initial = rpc("get_trace", initial_args)
        if not isinstance(initial, Mapping):
            raise RuntimeError("initial get_trace response must be an object")
        _write_once(run_dir / "initial-observation.json", _compact_trace_identity(initial))
        if initial.get("scene_id") != scene_id or initial.get("now") != 0:
            raise RuntimeError("fresh native story scene did not begin at sealed minute zero")
        live_story = initial.get("story_process")
        if not isinstance(live_story, Mapping):
            raise RuntimeError("native P5 trace omitted opt-in story_process evidence")
        if live_story.get("request", {}).get("scenario_id") != scene_id:
            raise RuntimeError("native story request was not bound to its generated scene")
        if live_story.get("request", {}).get("task_control_grant", {}).get("scenario_id") != scene_id:
            raise RuntimeError("native story grant was not bound to its generated scene")
        active_request = deepcopy(dict(live_story["request"]))

        horizon = int(suite["common"]["horizon"])
        previous_observation: Mapping[str, Any] = {"story_process": live_story}
        for minute in range(1, horizon + 1):
            matched = _matching_actions(case.get("reactive_actions", []),
                                        previous_observation, fired, minute=minute)
            if len(matched) > 1:
                raise RuntimeError(f"more than one reactive intervention became eligible before minute {minute}")
            interventions: list[dict[str, Any]] = []
            for match in matched:
                action = dict(match["action"])
                kind = action.pop("kind")
                if kind == "author_story_edit":
                    current = active_request
                    expected_version = action.get("expected_version")
                    if expected_version != current.get("version"):
                        raise RuntimeError("declared story edit version does not match the last observed live request")
                    proposed = _patch_request(current, action.get("patch", {}),
                                              new_version=int(current["version"]) + 1)
                    interventions.append({"at": minute, "kind": kind,
                                          "expected_version": expected_version,
                                          "request": proposed})
                elif kind == "player_command":
                    interventions.append({"at": minute, "kind": kind,
                                          "operation": action["operation"],
                                          "item_alias": action["item_alias"]})
                else:
                    raise ValueError(f"unsupported reactive intervention kind: {kind}")
            call_index += 1
            step = _rpc_step_record(rpc, run_dir, call_index, {
                "scene_id": scene_id, "rounds": 1,
                "interventions": interventions, "edits": []}, minute)
            rounds = step.get("rounds") if isinstance(step, Mapping) else None
            if not isinstance(rounds, list) or len(rounds) != 1:
                raise RuntimeError("native story step must return exactly one observed minute")
            delta = rounds[0]
            if delta.get("minute") != minute or delta.get("minute_complete") is not True:
                raise RuntimeError("native step response does not match the expected completed minute")
            story_delta = delta.get("story_process")
            if story_delta is not None and not isinstance(story_delta, Mapping):
                raise RuntimeError("native step story_process delta must be an object or null")
            if story_delta is None:
                # Before the real, settled social request, there is no note to bind
                # and the native planner correctly has no story task to propose.
                story_delta = {"status": "WAITING_FOR_NATIVE_NOTE_RESPONSE",
                               "effects_applied": False,
                               "sealed_frontier": delta.get("trace_frontier")}
            bound_note_id = story_delta.get("bound_note_id")
            if type(bound_note_id) is int and active_request["objective"].get("note_id") is None:
                active_request["objective"]["note_id"] = bound_note_id
            if interventions and interventions[0].get("kind") == "author_story_edit":
                edit_result = next((row for row in delta.get("interventions", [])
                                    if isinstance(row, Mapping)), None)
                proposed = interventions[0]["request"]
                if isinstance(edit_result, Mapping) and edit_result.get("status") == "UPDATED":
                    active_request = deepcopy(proposed)
            for match in matched:
                fired.add(match["rule_index"])
            record = {"minute": minute, "interventions": interventions,
                      "intervention_results": delta.get("interventions"),
                      "trace_frontier": delta.get("trace_frontier"),
                      "story_process": story_delta,
                      "actor_steps": delta.get("actor_steps"),
                      "typed_trace": _compact_typed_delta(delta.get("typed_trace"), minute),
                      "verdicts": delta.get("verdicts")}
            steps.append(record)
            previous_observation = {"story_process": story_delta}
            if story_delta.get("terminal") is True:
                status = "TERMINAL"
                break

        # Exactly one full final trace and a separate committed DB readback.
        call_index += 1
        final_args = {"scene_id": scene_id}
        _write_once(run_dir / f"rpc-{call_index:04d}-get_trace-request.json", final_args)
        final_trace = rpc("get_trace", final_args)
        if not isinstance(final_trace, Mapping):
            raise RuntimeError("final get_trace response must be an object")
        _write_once(run_dir / "final-native-trace.json", final_trace)
        status = final_trace.get("run_status", status)
        if export_db:
            db_evidence, db_export = export_db_evidence(scene_id)
            _write_once(run_dir / "db-export-reference.json", db_export)
            if db_evidence is not None:
                # Preserve the exporter artifact and hash; avoid a second  multi-MB copy.
                _write_once(run_dir / "db-readback-summary.json", {
                    "scene_id": db_evidence.get("scene_id"),
                    "event_count": len(db_evidence.get("ledger", [])) if isinstance(db_evidence.get("ledger"), list) else None,
                    "export_artifact_path": db_export.get("artifact_path"),
                    "export_artifact_sha256": db_export.get("artifact_sha256")})
    except Exception as exc:
        expected_reset_rejection = (
            scene_id is None
            and case.get("expected", {}).get("reset") == "REJECTED_BEFORE_SCENE_CREATE"
            and type(exc) is RuntimeError
            and "P3 control rejected operation (ValueError)" in str(exc))
        if expected_reset_rejection:
            status = "EXPECTED_RESET_REJECTION"
            error = None
            _write_once(run_dir / "reset-rejection-evidence.json", {
                "operation": "reset_p5_scenario", "result": status,
                "native_error": str(exc), "scene_created": False,
                "expected": case["expected"]})
        else:
            error = {"stage": "native_story_run", "error_type": type(exc).__name__,
                     "error_message": str(exc)[:500], "scene_id": scene_id}
            _write_once(run_dir / "failure.json", error)
        if scene_id is not None and final_trace is None:
            # Preserve failure state once; never reset/replay this scene.
            try:
                call_index += 1
                final_args = {"scene_id": scene_id}
                _write_once(run_dir / f"rpc-{call_index:04d}-get_trace-request.json", final_args)
                final_trace = rpc("get_trace", final_args)
                if not isinstance(final_trace, Mapping):
                    raise RuntimeError("failure get_trace response must be an object")
                _write_once(run_dir / "failure-final-native-trace.json", final_trace)
                if export_db:
                    db_evidence, db_export = export_db_evidence(scene_id)
                    _write_once(run_dir / "failure-db-export-reference.json", db_export)
            except Exception as capture_exc:
                _write_once(run_dir / "failure-capture-error.json", {
                    "error_type": type(capture_exc).__name__, "error_message": str(capture_exc)[:300]})
    assessment = _assess_case(case, final_trace, steps, run_dir)
    summary = {"schema": "native-story-process-run-summary-v1", "case_id": case_id,
               "scene_id": scene_id, "status": status, "steps_recorded": len(steps),
               "reactive_rules_fired": sorted(fired), "error": error,
               "assessment": assessment,
               "final_story_process": final_trace.get("story_process") if isinstance(final_trace, Mapping) else None,
               "db_export": db_export, "run_directory": str(run_dir),
               "source_manifest": identity["source_manifest"]}
    _write_once(run_dir / "summary.json", summary)
    return summary, run_dir


def _assess_case(case: Mapping[str, Any], trace: Any, steps: list[Mapping[str, Any]],
                 run_dir: Path) -> dict[str, Any] | None:
    """Emit narrow, evidence-backed outcomes for cases with explicit postconditions."""
    if not isinstance(trace, Mapping):
        return None
    if case.get("case_id") == "resource-held-by-player":
        scene_identity = _read_json(run_dir / "scene_identity.json")
        item_id = (scene_identity.get("items", {}).get("courier_supply", {})
                   if isinstance(scene_identity.get("items"), Mapping) else {})
        item_id = item_id.get("id") if isinstance(item_id, Mapping) else None
        player_id = scene_identity.get("player", {}).get("id") if isinstance(scene_identity.get("player"), Mapping) else None
        minute_two = next((row for row in steps if row.get("minute") == 2), {})
        results = minute_two.get("intervention_results") or []
        result = results[0] if results and isinstance(results[0], Mapping) else {}
        receipt = result.get("receipt") if isinstance(result.get("receipt"), Mapping) else {}
        snapshots = trace.get("world_snapshots", [])
        last_snapshot = snapshots[-1] if snapshots and isinstance(snapshots[-1], Mapping) else {}
        player_holds_item = (type(item_id) is int and type(player_id) is int
                             and last_snapshot.get("item_locations", {}).get("courier_supply") == player_id)
        binding = (trace.get("world_capability_projection", {}).get("task_bindings", {}).get("A", {})
                   if isinstance(trace.get("world_capability_projection"), Mapping) else {})
        actor_a = next((row for row in trace.get("actor_evidence", [])
                        if isinstance(row, Mapping) and row.get("actor_alias") == "A"), {})
        receipts = actor_a.get("native_receipts", []) if isinstance(actor_a, Mapping) else []
        a_lacks_resource = (binding.get("item_alias") == "courier_supply"
                            and binding.get("item_id") == item_id
                            and not any(isinstance(row, Mapping) and row.get("item_id") == item_id
                                        and row.get("kind") == "drop" and row.get("settled") is True
                                        for row in receipts))
        story = trace.get("story_process", {})
        verdicts = story.get("real_verdicts", []) if isinstance(story, Mapping) else []
        no_native_note = (story.get("bound_note_id") is None and any(
            isinstance(row, Mapping) and row.get("status") == "NO_NATIVE_NOTE_EVIDENCE"
            and row.get("verdict") == "NOT_SATISFIED" for row in verdicts))
        assessment = {"resource_get_settled": result.get("status") == "SETTLED"
                      and receipt.get("settled") is True and receipt.get("item_id") == item_id
                      and receipt.get("actor_alias") == "player",
                      "resource_held_through_final_snapshot": player_holds_item,
                      "A_task_binding_is_same_item_and_unsettled": a_lacks_resource,
                      "story_result": "UNBOUND_NO_NATIVE_NOTE" if no_native_note else "NATIVE_NOTE_EVIDENCE_PRESENT_OR_UNCERTAIN",
                      "goal_result": "NOT_SATISFIED" if no_native_note else "NOT_CERTIFIED",
                      "sealed_horizon_reached": trace.get("now") == trace.get("horizon")
                      and trace.get("complete_through", {}).get("events") == trace.get("horizon")
                      and trace.get("complete_through", {}).get("values") == trace.get("horizon"),
                      "causal_chain": case.get("resource_causal_chain")}
        assessment["pass"] = bool(assessment["resource_get_settled"]
                                  and player_holds_item and a_lacks_resource and no_native_note
                                  and assessment["sealed_horizon_reached"])
        return assessment
    if case.get("case_id") == "locked-refusal-abort":
        story = trace.get("story_process", {})
        events = story.get("controller_events", []) if isinstance(story, Mapping) else []
        expected_hash = case.get("locked_fragment_template", {}).get("sequence_sha256")
        abort = next((row for row in events if isinstance(row, Mapping)
                      and row.get("event_type") == "P5_STORY_LOCKED_FRAGMENT_ABORTED"
                      and row.get("sealed") is True), None)
        reason = abort.get("reason", []) if isinstance(abort, Mapping) else []
        decisions = story.get("controller_decisions", []) if isinstance(story, Mapping) else []
        locked_aborted = any(isinstance(row, Mapping)
                             and row.get("status") == "LOCKED_ABORTED"
                             for row in decisions)
        violated = any(isinstance(row, Mapping)
                       and (row.get("status") == "VIOLATED" or row.get("verdict") == "VIOLATED")
                       for row in story.get("real_verdicts", [])) if isinstance(story, Mapping) else False
        assessment = {"abort_event_sealed": abort is not None,
                      "abort_reason": reason,
                      "expected_guard_mismatch_observed": case.get("expected", {}).get("abort_reason") in reason,
                      "locked_core_hash_unchanged": isinstance(abort, Mapping)
                      and abort.get("immutable_sequence_sha256") == expected_hash,
                      "decision_locked_aborted": locked_aborted,
                      "goal_result": "VIOLATED" if violated else "NOT_CERTIFIED",
                      "no_locked_task_requests": all(not row.get("task_requests")
                                                       for row in decisions if isinstance(row, Mapping))}
        assessment["pass"] = all((assessment["abort_event_sealed"],
                                  assessment["expected_guard_mismatch_observed"],
                                  assessment["locked_core_hash_unchanged"],
                                  assessment["decision_locked_aborted"],
                                  assessment["goal_result"] == "VIOLATED",
                                  assessment["no_locked_task_requests"]))
        return assessment
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-id", required=True, help="run exactly one case from story_cases/suite.json")
    parser.add_argument("--suite", type=Path, default=SUITE_PATH)
    parser.add_argument("--runs-dir", type=Path, default=DEFAULT_RUNS_DIR)
    parser.add_argument("--no-db-export", action="store_true")
    parser.add_argument("--reload-existing-evennia", action="store_true",
                        help="stop/start only the configured local Evennia service and retain lifecycle logs")
    args = parser.parse_args()
    lifecycle_dir = None
    if args.reload_existing_evennia:
        lifecycle_dir = _allocate_run_dir(args.runs_dir, f"{args.case_id}-service-lifecycle")
        stop = rpc_call("stop_world", {})
        _write_once(lifecycle_dir / "stop-result.json", stop)
        if not isinstance(stop, Mapping) or stop.get("status") != "STOPPED":
            raise RuntimeError("scoped Evennia stop helper did not report STOPPED; lifecycle evidence retained")
        start = rpc_call("start_world", {})
        _write_once(lifecycle_dir / "start-result.json", start)
        if not isinstance(start, Mapping) or start.get("status") != "STARTED":
            raise RuntimeError("scoped Evennia start helper did not report STARTED; lifecycle evidence retained")
        health = rpc_call("health", {})
        _write_once(lifecycle_dir / "health-result.json", health)
        if not isinstance(health, Mapping) or health.get("status") != "READY":
            raise RuntimeError("authenticated P3 health did not return READY after reload; lifecycle evidence retained")
    result, run_dir = run_case(args.case_id, suite_path=args.suite,
                               runs_dir=args.runs_dir, export_db=not args.no_db_export,
                               lifecycle_dir=lifecycle_dir)
    print(json.dumps({"summary": result, "run_directory": str(run_dir)},
                     ensure_ascii=False, sort_keys=True, indent=2, default=str))
    return 0 if result.get("error") is None else 2


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from tools.mature_methods_integration_v1.story_runner import (
    _assess_case, _at_path, _matching_actions, _patch_request, _replace_scene_token,
    _story_envelope, run_case,
)


ROOT = Path(__file__).resolve().parents[1]
SUITE = json.loads((ROOT / "story_cases/suite.json").read_text(encoding="utf-8"))
BUNDLE = json.loads((ROOT / "story_cases/story-bundle-v1.json").read_text(encoding="utf-8"))


class StoryCaseMatrixContractTests(unittest.TestCase):
    def test_matrix_is_finite_and_limits_first_release(self):
        rows = SUITE["cases"]
        self.assertEqual(len(rows), 14)
        self.assertEqual(SUITE["run_policy"]["max_scenes"], 13)
        self.assertEqual(SUITE["run_policy"]["max_cases_including_precreate_rejection"], 14)
        self.assertEqual(SUITE["run_policy"]["first_scene_release"], "accepted-gtpyhop")
        self.assertEqual(SUITE["run_policy"]["prior_s1_s4_runs"], "DO_NOT_RERUN")
        self.assertEqual(len({row["case_id"] for row in rows}), len(rows))

    def test_two_positive_and_rejection_pairs_hold_conditions_constant(self):
        by_id = {row["case_id"]: row for row in SUITE["cases"]}
        for left_id, right_id in (("accepted-gtpyhop", "accepted-event-driven"),
                                  ("rejected-gtpyhop", "rejected-event-driven"),
                                  ("task-refusal-gtpyhop", "task-refusal-event-driven")):
            left, right = by_id[left_id], by_id[right_id]
            self.assertEqual(left["pair_id"], right["pair_id"])
            self.assertNotEqual(left["strategy"], right["strategy"])
            for key in ("preset", "control", "actor_postresponse", "expected"):
                self.assertEqual(left[key], right[key])
        for case_id in ("accepted-gtpyhop", "accepted-event-driven", "rejected-gtpyhop", "rejected-event-driven"):
            control = by_id[case_id]["control"]
            self.assertEqual(control["mode"], "result_only")
            self.assertIsNone(control["file_actor"])
            self.assertEqual(set(control["allowed_methods"]), {"file_by_B", "return_then_file_by_A"})
        envelope = _story_envelope(SUITE, by_id["accepted-gtpyhop"])
        self.assertEqual(envelope["actor_postresponse"]["rejected"]["B_archive"], "UNWILLING")

    def test_story_goal_is_one_new_note_archive_goal_not_old_delivery_suite(self):
        self.assertEqual(SUITE["common"]["objective"]["kind"], "archive_same_note_after_response")
        self.assertEqual(SUITE["common"]["objective"]["note_id"], None)
        self.assertEqual(SUITE["common"]["objective"]["by_minute"], 24)
        constraint_ids = [row["id"] for row in BUNDLE["constraints"]]
        self.assertEqual(constraint_ids, ["native-note-response"])
        self.assertNotIn("courier-delivery", constraint_ids)
        self.assertNotIn("resident-delivery", constraint_ids)

    def test_rejection_only_registers_return_then_file_method(self):
        row = next(case for case in SUITE["cases"] if case["case_id"] == "rejected-gtpyhop")
        self.assertEqual(row["control"]["allowed_methods"], ["file_by_B", "return_then_file_by_A"])
        self.assertIsNone(row["control"]["file_actor"])
        self.assertTrue(row["expected"]["distinct_future_from_accept"])

    def test_control_sources_are_distinct_and_explicit(self):
        by_id = {row["case_id"]: row for row in SUITE["cases"]}
        self.assertEqual(by_id["process-control"]["control"]["source"], "SYSTEM")
        self.assertEqual(by_id["direct-control"]["control"]["source"], "AUTHORED")
        self.assertEqual(by_id["locked-fragment"]["control"]["mode"], "locked_fragment")
        fragment = by_id["locked-fragment"]["locked_fragment_template"]
        canonical = json.dumps(fragment["sequence"], sort_keys=True, separators=(",", ":")).encode()
        self.assertEqual(fragment["sequence_sha256"], hashlib.sha256(canonical).hexdigest())
        self.assertEqual(fragment["abort_policy"], "ABORT_LOCKED_CORE")

    def test_negative_cases_are_separate_new_goal_witnesses(self):
        negatives = [row for row in SUITE["cases"] if row["case_id"] in {
            "no-task-authority", "resource-held-by-player", "absolute-deadline-negative"}]
        self.assertEqual(len(negatives), 3)
        self.assertTrue(all(row["expected"]["not_p5_four_goal_proxy"] for row in negatives))
        no_authority = next(row for row in negatives if row["case_id"] == "no-task-authority")
        self.assertEqual(no_authority["expected"]["reset"], "REJECTED_BEFORE_SCENE_CREATE")
        resource = next(row for row in negatives if row["case_id"] == "resource-held-by-player")
        self.assertEqual(resource["reactive_actions"][0]["at_minute"], 2)
        self.assertEqual(resource["reactive_actions"][0]["action"]["item_alias"], "courier_supply")
        deadline = next(row for row in negatives if row["case_id"] == "absolute-deadline-negative")
        self.assertEqual(deadline["objective_override"]["by_minute"], 18)
        locked_refusal = next(row for row in SUITE["cases"] if row["case_id"] == "locked-refusal-abort")
        self.assertTrue(locked_refusal["expected"]["abort_event"])


class StoryRunnerContractTests(unittest.TestCase):
    def test_scene_binding_replaces_only_template_strings(self):
        value = {"scenario_id": None, "marker": "${scene_id}", "nested": ["prefix-${scene_id}"]}
        self.assertEqual(_replace_scene_token(value, "scene-1"), {
            "scenario_id": None, "marker": "scene-1", "nested": ["prefix-scene-1"]})

    def test_observation_trigger_is_based_on_returned_native_fields(self):
        rules = [{"when": {"path": "story_process.decision.selected_method", "equals": "file_by_B"},
                  "action": {"kind": "author_story_edit"}}]
        self.assertEqual(_matching_actions(rules, {"story_process": {"decision": {
            "selected_method": "file_by_B"}}}, set())[0]["rule_index"], 0)
        self.assertEqual(_matching_actions(rules, {"story_process": {"decision": {
            "selected_method": "return_then_file_by_A"}}}, set()), [])
        self.assertEqual(_at_path({"rows": [{"minute": 2}]}, "rows.0.minute"), 2)
        scheduled = [{"at_minute": 2, "action": {"kind": "player_command", "operation": "get",
                                                   "item_alias": "courier_supply"}}]
        self.assertEqual(_matching_actions(scheduled, {}, set(), minute=1), [])
        self.assertEqual(_matching_actions(scheduled, {}, set(), minute=2)[0]["action"]["item_alias"],
                         "courier_supply")

    def test_future_edit_patch_cannot_touch_grant_or_permissions(self):
        request = {"version": 1, "control": {"file_actor": None,
                    "allowed_methods": ["file_by_B", "return_then_file_by_A"]}}
        updated = _patch_request(request, {"control.file_actor": "A",
                                  "control.allowed_methods": ["return_then_file_by_A"]}, new_version=2)
        self.assertEqual(updated["version"], 2)
        self.assertEqual(updated["control"]["file_actor"], "A")
        with self.assertRaises(ValueError):
            _patch_request(request, {"task_control_grant.actor_aliases": []}, new_version=2)

    def test_runner_steps_from_incremental_responses_and_keeps_one_final_trace(self):
        suite_copy = json.loads(json.dumps(SUITE))
        suite_copy["cases"] = [row for row in suite_copy["cases"]
                               if row["case_id"] == "accepted-gtpyhop"]
        counts = {"reset": 0, "step": 0, "trace": 0}

        def fake_rpc(operation, args):
            if operation == "reset_p5_scenario":
                counts["reset"] += 1
                return {"ok": True, "scene": {"scene_id": "scene-123", "seed": 1,
                        "horizon": 24, "preset": "hero_intelligence_30_v0",
                        "active_bundle": {"bundle_id": "story", "version": 1}}}
            if operation == "get_trace":
                counts["trace"] += 1
                now = 0 if counts["trace"] == 1 else 24
                request = {"schema": "story-process-request-v1", "request_id": "story-accepted-gtpyhop",
                           "version": 1, "scenario_id": "scene-123",
                           "objective": {**suite_copy["common"]["objective"], "note_id": 123},
                           "control": suite_copy["cases"][0]["control"],
                           "task_control_grant": {**suite_copy["common"]["task_control_grant"],
                                                   "scenario_id": "scene-123"},
                           "edit_policy": suite_copy["common"]["edit_policy"], "locked_fragment": None}
                story = {"request": request, "strategy": "gtpyhop", "bound_note_id": 123,
                         "controller_decisions": [], "receipts": [], "real_verdicts": []}
                return {"scene_id": "scene-123", "now": now,
                        "complete_through": {"events": now, "values": now},
                        "bundle_identity": {"bundle_id": "story", "version": 1},
                        "run_status": "COMPLETE", "story_process": story,
                        "large_ledger": ["not copied until the one final trace"] if now == 24 else []}
            if operation == "step_world":
                counts["step"] += 1
                minute = args["rounds"] if counts["step"] == 1 else counts["step"]
                delta = {"minute": minute, "minute_complete": True,
                         "trace_frontier": {"events_through": minute, "values_through": minute},
                         "story_process": {"decision": {"selected_method": "file_by_B"},
                                           "bound_note_id": 123, "effects_applied": False},
                         "typed_trace": {"now": str(minute), "events": [
                             {"event_id": f"e{minute}", "time": str(minute)}],
                             "points": [{"observable_id": "x", "time": str(minute)}]},
                         "actor_steps": [], "verdicts": []}
                return {"scene_id": "scene-123", "rounds": [delta],
                        "final": {"large_cumulative_evidence": ["do not persist per minute"]}}
            raise AssertionError(operation)

        with tempfile.TemporaryDirectory() as temporary:
            suite_path = Path(temporary) / "suite.json"
            suite_path.write_text(json.dumps(suite_copy), encoding="utf-8")
            (Path(temporary) / "story-bundle-v1.json").write_text(
                json.dumps(BUNDLE), encoding="utf-8")
            summary, run_dir = run_case("accepted-gtpyhop", suite_path=suite_path,
                                        runs_dir=Path(temporary) / "runs",
                                        call_rpc=fake_rpc, export_db=False)
            self.assertIsNone(summary["error"])
            self.assertEqual(summary["steps_recorded"], 24)
            self.assertEqual(counts, {"reset": 1, "step": 24, "trace": 2})
            step_docs = list(run_dir.glob("rpc-*-step_world-response.json"))
            self.assertEqual(len(step_docs), 24)
            self.assertNotIn("large_cumulative_evidence", "".join(
                path.read_text(encoding="utf-8") for path in step_docs))
            self.assertTrue((run_dir / "final-native-trace.json").is_file())
            identity = json.loads((run_dir / "identity.json").read_text(encoding="utf-8"))
            manifest = identity["source_manifest"]
            for source in ("tools/native_platform_v0/p5/story_process/actor.py",
                           "tools/native_platform_v0/p5/story_process/__init__.py"):
                relative = manifest["source_snapshot_relative_paths"][source]
                snapshot = run_dir / "source-snapshot" / relative
                self.assertTrue(snapshot.is_file())
                self.assertEqual(hashlib.sha256(snapshot.read_bytes()).hexdigest(),
                                 manifest["working_tree_file_sha256"][source])
            self.assertEqual(manifest["remote_review_ref"], "refs/heads/webgpt-sync")

    def test_no_authority_rpc_rejection_is_not_reported_as_goal_success(self):
        with tempfile.TemporaryDirectory() as temporary:
            suite_path = Path(temporary) / "suite.json"
            suite_path.write_text(json.dumps(SUITE), encoding="utf-8")
            (Path(temporary) / "story-bundle-v1.json").write_text(json.dumps(BUNDLE), encoding="utf-8")

            def reject_reset(operation, _args):
                if operation == "reset_p5_scenario":
                    raise RuntimeError("P3 control rejected operation (ValueError)")
                self.fail("No scene exists after pre-create rejection")

            summary, run_dir = run_case("no-task-authority", suite_path=suite_path,
                                        runs_dir=Path(temporary) / "runs",
                                        call_rpc=reject_reset, export_db=False)
            self.assertEqual(summary["status"], "EXPECTED_RESET_REJECTION")
            self.assertIsNone(summary["scene_id"])
            self.assertIsNone(summary["error"])
            evidence = json.loads((run_dir / "reset-rejection-evidence.json").read_text(encoding="utf-8"))
            self.assertFalse(evidence["scene_created"])
            self.assertTrue(evidence["expected"]["not_goal_pass"])

    def test_resource_assessment_requires_settled_receipt_persistent_holder_and_no_note_verdict(self):
        with tempfile.TemporaryDirectory() as temporary:
            run_dir = Path(temporary)
            (run_dir / "scene_identity.json").write_text(json.dumps({
                "player": {"id": 30}, "items": {"courier_supply": {"id": 40}}}), encoding="utf-8")
            case = next(row for row in SUITE["cases"] if row["case_id"] == "resource-held-by-player")
            steps = [{"minute": 2, "intervention_results": [{"status": "SETTLED", "receipt": {
                "actor_alias": "player", "item_id": 40, "settled": True}}]}]
            trace = {"world_snapshots": [{"item_locations": {"courier_supply": 30}}],
                     "world_capability_projection": {"task_bindings": {"A": {
                         "item_alias": "courier_supply", "item_id": 40}}},
                     "actor_evidence": [{"actor_alias": "A", "native_receipts": []}],
                     "now": 24, "horizon": 24, "complete_through": {"events": 24, "values": 24},
                     "story_process": {"bound_note_id": None, "real_verdicts": [{
                         "status": "NO_NATIVE_NOTE_EVIDENCE", "verdict": "NOT_SATISFIED"}]}}
            result = _assess_case(case, trace, steps, run_dir)
            self.assertEqual(result["story_result"], "UNBOUND_NO_NATIVE_NOTE")
            self.assertEqual(result["goal_result"], "NOT_SATISFIED")
            self.assertTrue(result["pass"])
            trace["world_snapshots"][0]["item_locations"]["courier_supply"] = 22
            self.assertFalse(_assess_case(case, trace, steps, run_dir)["pass"])

    def test_locked_negative_requires_real_sealed_abort_and_unchanged_core(self):
        case = next(row for row in SUITE["cases"] if row["case_id"] == "locked-refusal-abort")
        digest = case["locked_fragment_template"]["sequence_sha256"]
        trace = {"story_process": {
            "controller_events": [{"event_type": "P5_STORY_LOCKED_FRAGMENT_ABORTED", "sealed": True,
                                   "reason": ["locked_fragment_entry_guard_note_holder_mismatch"],
                                   "immutable_sequence_sha256": digest}],
            "controller_decisions": [{"status": "LOCKED_ABORTED", "task_requests": []}],
            "real_verdicts": [{"status": "VIOLATED"}]}}
        result = _assess_case(case, trace, [], Path("."))
        self.assertTrue(result["pass"])
        trace["story_process"]["controller_events"][0]["immutable_sequence_sha256"] = "different"
        self.assertFalse(_assess_case(case, trace, [], Path("."))["pass"])


if __name__ == "__main__":
    unittest.main()

# Scoped service reload evidence

- Operation: one stop/start reload of the existing configured nativep1 Evennia service and database; no second instance and no scene/database deletion.
- Runtime reported by start log: Evennia 6.0.0, revision `796510a`, ports 14000–14002.
- Stop log source: `outputs/native_platform_p1p2_v0/p1_evennia_20261010/runs/story-m5-reload-stop-20261013T000000Z/stop.log`
- Stop log SHA-256: `0bb92b1c2e486e5635d2dff39cd1a6ed6c6b0d7b2a02e3a8ab4d4d2dad6bb9c1`
- Start log source: `outputs/native_platform_p1p2_v0/p1_evennia_20261010/runs/story-m5-reload-start-20261013T000001Z/start.log`
- Start log SHA-256: `1ed36e9f55569d54ea95aebadceb461a07cb4907b6d844d440b9788687d55717`
- These are lifecycle logs only. No credentials, server configuration, or database binary are included.

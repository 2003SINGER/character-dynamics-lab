# Reload chronology and filename boundary

This directory contains byte-verified lifecycle logs, not an experiment scene.
The `000000Z`/`000001Z` suffixes are operator filenames, **not measured restart times**.
There were two bounded reload operations of the existing configured service:

1. Before the preserved failing E1 scene `20261013090427-19e3d7`, stop source
   `outputs/native_platform_p1p2_v0/p1_evennia_20261010/runs/20261013T085847Z-8623/stop.log`
   and start source
   `outputs/native_platform_p1p2_v0/p1_evennia_20261010/runs/20261013T085850Z-8637/start.log`.
2. After the archive-only projection/work-estimation repairs and before the new
   representative scene `20261013092722-b9b548`, the sources listed in `manifest.md`.

Parent read-back verified that the stop log bytes of both operations are identical
to the archived `stop.log`, SHA-256
`0bb92b1c2e486e5635d2dff39cd1a6ed6c6b0d7b2a02e3a8ab4d4d2dad6bb9c1`;
the two start log files likewise match `start.log`, SHA-256
`1ed36e9f55569d54ea95aebadceb461a07cb4907b6d844d440b9788687d55717`.
The duplicated log bytes are stored once; source paths and operation order remain
distinct here. No precise duration is inferred from filenames or file timestamps.
The reported Git revision `796510a` is the checkout base, not a claim that loaded
working-tree source bytes equal that commit. Actual per-scene source snapshots
carry that distinction. No credentials, configuration, or database binaries are
published.

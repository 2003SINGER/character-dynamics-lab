# Controlled server restart epoch

Purpose: continue the fixed Planner Adapter Integration v1 native matrix after reaching the confirmed 16-scene per-process limit. Parent authorized this restart. No code, configuration, DB, prior scene, or history was deleted or reset.

Stop command: `bash tools/native_platform_v0/evennia/stop_loopback.sh`

Stop output:

```text
Server stopping ...
... Server stopped.
Stopping Portal ...
... Portal stopped.
Evennia shut down.
```

Exit code: 0.

Start command: `bash tools/native_platform_v0/evennia/start_loopback.sh`

Start output:

```text
Portal starting ...
... Portal started.
Server starting  ...
... Server started.
Evennia running.
--------------------------------- Evennia ---
nativep1 Portal 6.0.0 (rev 40048c7)
    external ports:
        telnet-127.0.0.1: 14000
        webserver-proxy-127.0.0.1: 14001
        webclient-websocket-127.0.0.1: 14002
    internal_ports (to Server):
        webserver: 14006
        amp: 14005

nativep1 Server 6.0.0 (rev 40048c7)
    internal ports (to Portal):
        webserver: 14006
        amp : 14005
---------------------------------------------
```

Exit code: 0. Authenticated P3 health after restart: `READY`, service `native-p3-control`, bind `127.0.0.1:14011`.

This is a process-epoch boundary only; the existing Evennia DB and earlier run scenes remain the evidence source. Runs before and after this boundary are reported with their own captured traces and source identities.

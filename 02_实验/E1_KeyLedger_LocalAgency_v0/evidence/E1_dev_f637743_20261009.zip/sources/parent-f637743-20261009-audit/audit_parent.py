#!/usr/bin/env python3
"""Independent parent audit for the frozen E1 development runs."""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[4]
RUNS = ROOT / "runs" / "e1_keyledger_v0" / "dev"
OUT = RUNS / "parent-f637743-20261009-audit"
PRIMARY = "parent-f637743-20261009"
RERUN = "parent-f637743-20261009-rerun"
CAP1 = "parent-f637743-20261009-cap1"
WALL = "parent-f637743-20261009-wall"
HISTORICAL = ("dev-20261009-e1-1", "dev-20261009-e1-1-r2", "dev-20261009-e1-1-r3")
EXPECTED_REVISION = "f637743a8af9faacbb908e8b4bae4b8f4661b193"
VOLATILE_KEYS = {"created_utc", "run_id", "elapsed_seconds", "before_hash", "after_hash"}

EXPECTED = {}
for knowledge in ("known", "unknown"):
    for deadline in (8, 10):
        EXPECTED[(knowledge, "PAY", deadline)] = ("SATISFIED", 8)
        EXPECTED[(knowledge, "TOOL", deadline)] = (
            ("SATISFIED", 9) if deadline == 10 else ("VIOLATED", None))
        EXPECTED[(knowledge, "KEEP", deadline)] = ("VIOLATED", None)


def canonical_hash(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def current_revision():
    result = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True,
                            text=True, check=True)
    return result.stdout.strip()


def audit_source_hashes(manifest):
    hashes = manifest.get("source_hashes")
    if not isinstance(hashes, dict) or len(hashes) != 29:
        raise AssertionError(f"expected 29 source hashes, got {len(hashes or {})}")
    rows = []
    for relative, expected in sorted(hashes.items()):
        path = ROOT / relative
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        rows.append({"path": relative, "manifest_sha256": expected,
                     "current_sha256": actual, "match": actual == expected})
    mismatches = [row for row in rows if not row["match"]]
    return {"count": len(rows), "matches": len(rows) - len(mismatches),
            "all_match": not mismatches, "mismatches": mismatches, "rows": rows}


def goal_witness(case):
    """Extract actual witness only from committed monitor, event, receipt, and seal evidence."""
    trace = case["actual_trace"]
    final, monitor = trace["final"], trace["monitor"]
    deadline = int(case["initial"]["config_pins"]["deadline"])
    producer = final.get("domain", {}).get("producer_version")
    events = [event for event in final.get("events", [])
              if event.get("event_type") == "ledger_acquired"
              and event.get("typed_args") == {
                  "event": "ledger_acquired", "actor": "A", "item": "ledger"}
              and isinstance(event.get("time"), int) and 2 <= event["time"] <= deadline]
    for event in events:
        receipt = next((row for row in final.get("receipts", [])
                        if event.get("event_id") in row.get("event_ids", [])), None)
        sealed = any(seal.get("sealed_through", -1) >= event["time"]
                     and seal.get("sequence_frontier", -1) >= event.get("sequence", 10**18)
                     for seal in final.get("seals", []))
        valid = (receipt is not None and receipt.get("accepted") is True
                 and event.get("producer_version") == producer
                 and receipt.get("producer_version") == producer
                 and receipt.get("status") == "SUCCESS"
                 and receipt.get("outcome") == "COMPLETED"
                 and receipt.get("end_time") == event["time"]
                 and receipt.get("event_ids") == [event.get("event_id")]
                 and receipt.get("event_payloads") == [event]
                 and receipt.get("intent") == {
                     "operator": "take_ledger", "actor": "A", "args": {"item": "ledger"}}
                 and sealed)
        if valid and event.get("event_id") in set(monitor.get("witness_event_ids", [])):
            return {"event_id": event["event_id"], "time": event["time"],
                    "sequence": event["sequence"], "receipt_id": receipt["receipt_id"],
                    "seal_covered": True}
    return None


def actual_check(case):
    initial = case["initial"]
    condition = initial["config_pins"]["e1"]
    deadline = initial["config_pins"]["deadline"]
    expected_status, expected_time = EXPECTED[(condition["knowledge"], condition["policy"], deadline)]
    trace, monitor = case["actual_trace"], case["actual_trace"]["monitor"]
    witness = goal_witness(case)
    if expected_status == "SATISFIED":
        match = (witness is not None and witness["time"] == expected_time
                 and monitor.get("status") == "SATISFIED")
        expected_trace_status = "TRACE_SATISFIED"
    else:
        match = (witness is None and monitor.get("status") == "VIOLATED"
                 and monitor.get("coverage_complete_through", -1) >= deadline)
        expected_trace_status = "TRACE_VIOLATED"
    passed = bool(match and trace.get("trace_status") == expected_trace_status
                  and not trace.get("errors"))
    return {"fixture_id": case["fixture_id"], "expected_monitor": expected_status,
            "expected_witness_time": expected_time, "observed_monitor": monitor.get("status"),
            "observed_witness": witness, "trace_status": trace.get("trace_status"),
            "errors": trace.get("errors", []), "check": "EXPECTED" if passed else "FAIL"}


def strip_volatile(value, counts):
    if isinstance(value, dict):
        out = {}
        for key, child in value.items():
            if key in VOLATILE_KEYS:
                counts[key] += 1
            else:
                out[key] = strip_volatile(child, counts)
        return out
    if isinstance(value, list):
        return [strip_volatile(child, counts) for child in value]
    return value


def first_diff(left, right, path="$"):
    if type(left) is not type(right):
        return path
    if isinstance(left, dict):
        if left.keys() != right.keys():
            return path
        for key in sorted(left):
            found = first_diff(left[key], right[key], f"{path}.{key}")
            if found:
                return found
        return None
    if isinstance(left, list):
        if len(left) != len(right):
            return path
        for index, pair in enumerate(zip(left, right)):
            found = first_diff(pair[0], pair[1], f"{path}[{index}]")
            if found:
                return found
        return None
    return None if left == right else path


def compare_semantics(left, right):
    left_counts, right_counts = Counter(), Counter()
    clean_left = strip_volatile(left, left_counts)
    clean_right = strip_volatile(right, right_counts)
    return {"equal": clean_left == clean_right,
            "first_differing_path": first_diff(clean_left, clean_right),
            "exclusion_counts": {"left": dict(sorted(left_counts.items())),
                                 "right": dict(sorted(right_counts.items())),
                                 "combined": dict(sorted((left_counts + right_counts).items()))}}


def audit_step_hashes(case):
    checked, bad, examples = 0, 0, []
    for index, step in enumerate(case["actual_trace"].get("steps", [])):
        checked += 1
        recalculated = canonical_hash(step.get("state"))
        if step.get("after_hash") != recalculated:
            bad += 1
            if len(examples) < 10:
                examples.append({"step": index, "stored": step.get("after_hash"),
                                 "recalculated": recalculated})
    return {"checked": checked, "mismatches": bad, "all_match": bad == 0, "examples": examples}


def summarize_case(case, run_id):
    trace = case["actual_trace"]
    final = trace["final"]
    witness = goal_witness(case)
    return {
        "run_id": run_id, "fixture_id": case["fixture_id"],
        "condition": {k: case["initial"]["config_pins"]["e1"][k]
                      for k in ("knowledge", "policy")} | {
                          "deadline": case["initial"]["config_pins"]["deadline"]},
        "actual_event_time": witness["time"] if witness else None,
        "actual_witness_event_id": witness["event_id"] if witness else None,
        "a_total_expansions": trace.get("planner_budget", {}).get("expansions"),
        "world_oracle": {k: case["oracles"]["world"].get(k) for k in
                         ("solve_status", "complete", "exhausted", "expansions",
                          "generated", "elapsed_seconds", "earliest_completion_time")},
        "fixed_b_oracle": {k: case["oracles"]["fixed_b"].get(k) for k in
                           ("solve_status", "complete", "exhausted", "expansions",
                            "generated", "elapsed_seconds", "earliest_completion_time")},
        "b_goals": trace.get("monitor", {}).get("B_goals"),
        "actual_actions": [step.get("action", {}).get("operator")
                           for step in trace.get("steps", [])],
        "request_bits": {"W.request_used": final.get("W", {}).get("request_used"),
                         "O_B.request_sent": final.get("O", {}).get("B", {}).get("request_sent")},
        "actual_check": actual_check(case)["check"],
    }


def run_negative_control():
    sys.path.insert(0, str(ROOT))
    from tools.e1_keyledger_v0.executor import Executor
    from tools.e1_keyledger_v0.fixtures import initial_checkpoint
    from tools.e1_keyledger_v0.policy import actor_view, choose_b

    cp_w_false = initial_checkpoint("known", "PAY", 8)
    cp_w_true = deepcopy(cp_w_false)
    cp_w_true["W"]["request_used"] = True
    view_false, view_true = actor_view(cp_w_false, "B"), actor_view(cp_w_true, "B")
    proposal_false, proposal_true = choose_b(view_false), choose_b(view_true)
    start_false = Executor(cp_w_false).start(proposal_false)
    executor_true = Executor(cp_w_true)
    start_true = executor_true.start(proposal_true)
    remains_false = (cp_w_false["O"]["B"].get("request_sent") is False
                     and cp_w_true["O"]["B"].get("request_sent") is False
                     and executor_true.checkpoint()["O"]["B"].get("request_sent") is False)
    passed = (view_false == view_true and proposal_false == proposal_true
              and start_false.get("accepted") is True
              and start_true.get("accepted") is False
              and start_false.get("status") != start_true.get("status")
              and remains_false)
    return {"same_actor_view": view_false == view_true,
            "same_b_proposal": proposal_false == proposal_true,
            "proposal": proposal_false,
            "start_world_request_false": {k: start_false.get(k)
                                          for k in ("accepted", "status", "outcome")},
            "start_world_request_true": {k: start_true.get(k)
                                         for k in ("accepted", "status", "outcome")},
            "O_B_request_sent_remains_false": remains_false,
            "check": "EXPECTED" if passed else "FAIL"}


def main():
    report = {"audit_version": "parent-e1-audit-v1", "primary_run": PRIMARY,
              "rerun": RERUN, "expected_git_revision": EXPECTED_REVISION,
              "checks": {}, "case_summaries": [], "historical": {}}
    log = []
    try:
        head = current_revision()
        report["actual_head"] = head
        report["checks"]["head_is_frozen_revision"] = head == EXPECTED_REVISION

        primary_dir, rerun_dir = RUNS / PRIMARY, RUNS / RERUN
        primary_manifest = read_json(primary_dir / "manifest.json")
        rerun_manifest = read_json(rerun_dir / "manifest.json")
        report["primary_manifest"] = {k: primary_manifest.get(k) for k in
                                      ("run_id", "git_revision", "status",
                                       "formal_experiment", "case_count", "limits")}
        report["checks"]["primary_revision_matches_real_head"] = (
            primary_manifest.get("git_revision") == head == EXPECTED_REVISION)
        report["source_hash_audit"] = audit_source_hashes(primary_manifest)
        report["checks"]["all_29_primary_source_hashes_current"] = (
            report["source_hash_audit"]["all_match"])
        report["rerun_source_hash_audit"] = audit_source_hashes(rerun_manifest)
        report["checks"]["all_29_rerun_source_hashes_current"] = (
            report["rerun_source_hash_audit"]["all_match"])

        primary_files = sorted(primary_dir.glob("E1-*.json"))
        rerun_files = sorted(rerun_dir.glob("E1-*.json"))
        if len(primary_files) != 12 or len(rerun_files) != 12:
            raise AssertionError("primary and rerun must each contain 12 case files")
        primary_cases = {case["fixture_id"]: case for case in map(read_json, primary_files)}
        rerun_cases = {case["fixture_id"]: case for case in map(read_json, rerun_files)}
        if set(primary_cases) != set(rerun_cases):
            raise AssertionError("primary and rerun fixture IDs differ")

        oracle_rows, actual_rows, hash_rows = [], [], []
        for fixture_id in sorted(primary_cases):
            case = primary_cases[fixture_id]
            for oracle_name in ("world", "fixed_b"):
                result = case["oracles"][oracle_name]
                oracle_rows.append({"fixture_id": fixture_id, "oracle": oracle_name,
                    "check": case.get("oracle_checks", {}).get(oracle_name),
                    "complete": result.get("complete"), "solve_status": result.get("solve_status")})
            actual_rows.append(actual_check(case))
            hash_rows.append({"fixture_id": fixture_id, **audit_step_hashes(case)})
            report["case_summaries"].append(summarize_case(case, PRIMARY))

        report["oracle_checks"] = {
            "count": len(oracle_rows),
            "expected": sum(row["check"] == "EXPECTED_VERDICT_CHECK" and row["complete"] is True
                            for row in oracle_rows), "rows": oracle_rows}
        report["actual_checks"] = {
            "count": len(actual_rows),
            "expected": sum(row["check"] == "EXPECTED" for row in actual_rows),
            "rows": actual_rows}
        report["step_after_hash_checks"] = {
            "count": sum(row["checked"] for row in hash_rows),
            "mismatches": sum(row["mismatches"] for row in hash_rows), "rows": hash_rows}
        report["checks"]["24_oracle_verdicts_expected"] = (
            report["oracle_checks"]["count"] == 24 and report["oracle_checks"]["expected"] == 24)
        report["checks"]["12_actual_event_checks_expected"] = (
            report["actual_checks"]["count"] == 12 and report["actual_checks"]["expected"] == 12)
        report["checks"]["primary_no_budgets_or_errors"] = all(
            all(decision.get("plan", {}).get("solve_status") != "BUDGET"
                for decision in case["actual_trace"].get("decisions", []))
            and not case["actual_trace"].get("errors")
            and all(case["oracles"][name].get("solve_status") != "BUDGET"
                    for name in ("world", "fixed_b")) for case in primary_cases.values())
        report["checks"]["all_step_after_hashes_recompute"] = (
            report["step_after_hash_checks"]["mismatches"] == 0)

        manifest_cmp = compare_semantics(primary_manifest, rerun_manifest)
        case_cmps = {fixture_id: compare_semantics(primary_cases[fixture_id], rerun_cases[fixture_id])
                     for fixture_id in sorted(primary_cases)}
        report["primary_rerun_comparison"] = {
            "excluded_keys": sorted(VOLATILE_KEYS), "manifest": manifest_cmp,
            "cases": case_cmps,
            "all_semantic_fields_equal": manifest_cmp["equal"]
                and all(item["equal"] for item in case_cmps.values()),
            "exclusion_counts": {
                "manifest": manifest_cmp["exclusion_counts"],
                "case_documents_combined": {
                    key: sum(item["exclusion_counts"]["combined"].get(key, 0)
                             for item in case_cmps.values())
                    for key in sorted(VOLATILE_KEYS)}}}
        report["checks"]["primary_rerun_semantically_identical"] = (
            report["primary_rerun_comparison"]["all_semantic_fields_equal"])

        report["negative_control"] = run_negative_control()
        report["checks"]["hidden_world_request_noninterference_and_validation"] = (
            report["negative_control"]["check"] == "EXPECTED")

        budget_diagnostics = []
        for run_id in (CAP1, WALL):
            manifest = read_json(RUNS / run_id / "manifest.json")
            if len(manifest.get("results", [])) != 1:
                raise AssertionError(f"{run_id}: expected one diagnostic result")
            case_id = manifest["results"][0]["fixture_id"]
            case = read_json(RUNS / run_id / f"{case_id}.json")
            objects = {}
            for name, result in (
                ("world_oracle", case["oracles"]["world"]),
                ("fixed_b_oracle", case["oracles"]["fixed_b"]),
                ("planner", case["actual_trace"]["planner_last"]),
            ):
                ok = (result.get("solve_status") == "BUDGET"
                      and result.get("complete") is False
                      and result.get("solve_status") != "PROVEN_UNREACHABLE_IN_FINITE_DOMAIN")
                objects[name] = {"solve_status": result.get("solve_status"),
                                 "complete": result.get("complete"),
                                 "termination_reason": result.get("termination_reason"),
                                 "check": "EXPECTED" if ok else "FAIL"}
            budget_diagnostics.append({"run_id": run_id, "fixture_id": case_id, "objects": objects})
        report["budget_diagnostics"] = budget_diagnostics
        report["checks"]["cap1_wall_three_objects_incomplete_budget"] = all(
            item["check"] == "EXPECTED" for row in budget_diagnostics
            for item in row["objects"].values())

        for run_id in HISTORICAL:
            manifest = read_json(RUNS / run_id / "manifest.json")
            diffs = []
            for relative, digest in sorted(manifest.get("source_hashes", {}).items()):
                path = ROOT / relative
                current = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
                if current != digest:
                    diffs.append(relative)
            historical_rows = manifest.get("results", [])
            historical_fail_cases = [row.get("fixture_id") for row in historical_rows
                                     if row.get("status") == "FAIL"
                                     or row.get("actual_trace", {}).get("errors")]
            report["historical"][run_id] = {
                "case_count": manifest.get("case_count"),
                "source_hash_count": len(manifest.get("source_hashes", {})),
                "current_hash_diff_count": len(diffs), "current_hash_diff_paths": diffs,
                "status_counts": dict(sorted(Counter(row.get("status", "MISSING")
                                                      for row in historical_rows).items())),
                "historical_fail_cases": historical_fail_cases,
                "historical_failure_payloads_preserved": True,
                "note": "Historical source differences are reported and are not required to match."}

        report["overall"] = "PASS" if all(report["checks"].values()) else "FAIL"
        log.extend([
            f"Parent audit: {report['overall']}",
            f"HEAD: {head}; primary/rerun source hashes current: "
            f"{report['source_hash_audit']['matches']}/29 and "
            f"{report['rerun_source_hash_audit']['matches']}/29",
            f"Oracle checks: {report['oracle_checks']['expected']}/{report['oracle_checks']['count']}; "
            f"actual event checks: {report['actual_checks']['expected']}/{report['actual_checks']['count']}",
            f"Primary/rerun semantic equality: {report['primary_rerun_comparison']['all_semantic_fields_equal']}",
            f"Volatile exclusions: {json.dumps(report['primary_rerun_comparison']['exclusion_counts'], sort_keys=True)}",
            f"Per-step after_hash: {report['step_after_hash_checks']['mismatches']} mismatches/"
            f"{report['step_after_hash_checks']['count']} checked",
            f"Negative control: {json.dumps(report['negative_control'], ensure_ascii=False, sort_keys=True)}",
            f"CAP1/WALL diagnostics: {json.dumps(budget_diagnostics, ensure_ascii=False, sort_keys=True)}",
            "Primary 12-cell evidence:",
        ])
        log.extend(json.dumps(row, ensure_ascii=False, sort_keys=True)
                   for row in report["case_summaries"])
        log.append("Historical snapshots:")
        log.extend(json.dumps({"run_id": run_id,
                               "source_hash_count": row["source_hash_count"],
                               "current_hash_diff_count": row["current_hash_diff_count"],
                               "current_hash_diff_paths": row["current_hash_diff_paths"],
                               "status_counts": row["status_counts"],
                               "historical_fail_cases": row["historical_fail_cases"]}
                              , ensure_ascii=False, sort_keys=True)
                   for run_id, row in report["historical"].items())
        log.append("Checks: " + json.dumps(report["checks"], ensure_ascii=False, sort_keys=True))
    except Exception as exc:
        report["overall"] = "AUDIT_ERROR"
        report["error"] = {"type": type(exc).__name__, "message": str(exc),
                           "traceback": traceback.format_exc()}
        log.extend([f"Parent audit: AUDIT_ERROR: {type(exc).__name__}: {exc}",
                    report["error"]["traceback"]])

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                                    encoding="utf-8")
    (OUT / "audit.log").write_text("\n".join(log) + "\n", encoding="utf-8")
    print("\n".join(log))
    return 0 if report["overall"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

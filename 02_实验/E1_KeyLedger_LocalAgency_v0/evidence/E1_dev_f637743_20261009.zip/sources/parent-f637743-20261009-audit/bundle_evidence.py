#!/usr/bin/env python3
"""Create and read-back-verify the scoped E1 development evidence bundle."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
DEV = HERE.parent
EVIDENCE = REPO / "02_实验" / "E1_KeyLedger_LocalAgency_v0" / "evidence"
ZIP_NAME = "E1_dev_f637743_20261009.zip"
MANIFEST_NAME = "E1_dev_f637743_20261009.manifest.json"

SOURCE_SPECS = (
    ("dev-20261009-e1-1", DEV / "dev-20261009-e1-1"),
    ("dev-20261009-e1-1-r2", DEV / "dev-20261009-e1-1-r2"),
    ("dev-20261009-e1-1-r3", DEV / "dev-20261009-e1-1-r3"),
    ("parent-f637743-20261009", DEV / "parent-f637743-20261009"),
    ("parent-f637743-20261009-rerun", DEV / "parent-f637743-20261009-rerun"),
    ("parent-f637743-20261009-cap1", DEV / "parent-f637743-20261009-cap1"),
    ("parent-f637743-20261009-wall", DEV / "parent-f637743-20261009-wall"),
    ("parent-f637743-20261009-audit", HERE),
)
COMPACT_NAMES = ("audit.json", "unit-tests.log", "typed-ir-tests.log", "ci-e0.log")
FROZEN_REVISION = "f637743a8af9faacbb908e8b4bae4b8f4661b193"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def selected_sources() -> list[tuple[str, Path, Path]]:
    """Return (member name, source path, source directory alias) records."""
    selected: list[tuple[str, Path, Path]] = []
    for alias, source_dir in SOURCE_SPECS:
        if not source_dir.is_dir():
            raise FileNotFoundError(f"required source directory missing: {source_dir}")
        for path in sorted(source_dir.rglob("*")):
            if path.is_symlink():
                raise RuntimeError(f"refusing symlink in evidence source: {path}")
            if not path.is_file():
                continue
            relative = path.relative_to(source_dir)
            # Original private material is explicitly outside this bundle.
            if any("_private" in part.lower() for part in relative.parts):
                continue
            # Bundle outputs are not source evidence and must never recurse in.
            if path.name in (ZIP_NAME, MANIFEST_NAME):
                continue
            member = f"sources/{alias}/{relative.as_posix()}"
            selected.append((member, path, source_dir))
    names = [row[0] for row in selected]
    if len(names) != len(set(names)):
        raise RuntimeError("duplicate archive member names")
    return selected


def install_without_overwrite(temp_path: Path, output_path: Path) -> None:
    """Publish a completed file using an exclusive same-filesystem hard link."""
    try:
        os.link(temp_path, output_path)
    except FileExistsError as exc:
        raise FileExistsError(f"refusing to overwrite existing output: {output_path}") from exc
    temp_path.unlink()


def main() -> None:
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    zip_path = EVIDENCE / ZIP_NAME
    manifest_path = EVIDENCE / MANIFEST_NAME
    compact_sources = {name: HERE / name for name in COMPACT_NAMES}
    compact_outputs = {name: EVIDENCE / name for name in COMPACT_NAMES}

    # Refuse all collisions before producing any final output.
    for output in (zip_path, manifest_path, *compact_outputs.values()):
        if output.exists():
            raise FileExistsError(f"refusing to overwrite existing output: {output}")
    for name, source in compact_sources.items():
        if not source.is_file():
            raise FileNotFoundError(f"required compact evidence missing ({name}): {source}")

    members = selected_sources()
    entries = []
    with tempfile.TemporaryDirectory(prefix="e1-evidence-", dir=EVIDENCE) as temp_dir:
        temp_root = Path(temp_dir)
        temp_zip = temp_root / ZIP_NAME
        with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, strict_timestamps=False) as archive:
            for member, source, source_dir in members:
                payload = source.read_bytes()
                archive.writestr(member, payload)
                entries.append({
                    "member": member,
                    "source_directory": source_dir.relative_to(REPO).as_posix(),
                    "source_path": source.relative_to(REPO).as_posix(),
                    "size_bytes": len(payload),
                    "sha256": sha256_bytes(payload),
                })

        zip_size = temp_zip.stat().st_size
        zip_hash = sha256_file(temp_zip)

        # Read back every archive member and verify its full byte hash.
        with zipfile.ZipFile(temp_zip, "r") as archive:
            actual_names = archive.namelist()
            expected_names = [entry["member"] for entry in entries]
            if actual_names != expected_names:
                raise RuntimeError("zip member inventory differs from source inventory")
            for entry in entries:
                data = archive.read(entry["member"])
                if len(data) != entry["size_bytes"] or sha256_bytes(data) != entry["sha256"]:
                    raise RuntimeError(f"read-back verification failed: {entry['member']}")

        audit = json.loads((HERE / "audit.json").read_text(encoding="utf-8"))
        old_protocol_hash = next(
            (row.get("manifest_sha256") for row in audit.get("source_hash_audit", {}).get("rows", [])
             if row.get("path") == "00_研究设计/E1_KeyLedger_LocalAgency_Protocol_v0.md"),
            None,
        )
        protocol_path = REPO / "00_研究设计" / "E1_KeyLedger_LocalAgency_Protocol_v0.md"
        current_protocol_hash = sha256_file(protocol_path)
        compact_entries = []
        temp_copies = {}
        for name, source in compact_sources.items():
            temp_copy = temp_root / name
            temp_copy.write_bytes(source.read_bytes())
            temp_copies[name] = temp_copy
            compact_entries.append({
                "source_path": source.relative_to(REPO).as_posix(),
                "output_path": compact_outputs[name].relative_to(REPO).as_posix(),
                "size_bytes": temp_copy.stat().st_size,
                "sha256": sha256_file(temp_copy),
            })

        manifest = {
            "schema": "e1-development-evidence-bundle-v1",
            "source_audit": {
                "run_id": "parent-f637743-20261009",
                "audit_path": (HERE / "audit.json").relative_to(REPO).as_posix(),
                "frozen_git_revision": FROZEN_REVISION,
                "audit_checks": audit.get("checks", {}),
                "formal_experiment": False,
                "solver_rerun_for_bundling": False,
            },
            "post_audit_clarification": {
                "authorization_change": "docs-only clarification of user-authorized E1-1 development scope",
                "code_or_parameter_change": False,
                "protocol_hash_changed": old_protocol_hash != current_protocol_hash,
                "protocol_sha256_at_audit": old_protocol_hash,
                "protocol_sha256_current": current_protocol_hash,
            },
            "source_directories": [
                {"archive_prefix": f"sources/{alias}/",
                 "source_directory": source_dir.relative_to(REPO).as_posix()}
                for alias, source_dir in SOURCE_SPECS
            ],
            "private_material_exclusion": "Any source path component containing '_private' is excluded.",
            "archive": {
                "output_path": zip_path.relative_to(REPO).as_posix(),
                "size_bytes": zip_size,
                "sha256": zip_hash,
                "member_count": len(entries),
                "members": entries,
                "readback_verified": True,
            },
            "compact_evidence_copies": compact_entries,
        }
        temp_manifest = temp_root / MANIFEST_NAME
        temp_manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
                                 encoding="utf-8")

        install_without_overwrite(temp_zip, zip_path)
        install_without_overwrite(temp_manifest, manifest_path)
        for name, temp_copy in temp_copies.items():
            install_without_overwrite(temp_copy, compact_outputs[name])

    print(json.dumps({
        "zip_path": zip_path.relative_to(REPO).as_posix(),
        "zip_size_bytes": zip_size,
        "zip_sha256": zip_hash,
        "member_count": len(entries),
        "manifest_path": manifest_path.relative_to(REPO).as_posix(),
        "compact_copy_count": len(compact_entries),
        "readback_verified": True,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

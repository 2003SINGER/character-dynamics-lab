//-----------------------------------------------------------------------------
/// \par	Copyright 2012-2013 Joseph Vasquez II, All rights reserved
/// \par You can use it though

/// \version Version 1.0, distibuted with Game AI Pro, 2013

///	Description:
///		Defines templated Ngram functions.
/// 	This file is included in ngram.hpp to handle templates. So, do not compile this file on its own
//-----------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Includes for everything
#include <cmath>	///< for pow() (exponent)
#include <cstdlib>	///< for rand()
#include <cstring> ///< for memcpy()

//------------------------------------------------------------------------------
// Includes just for vector array version
#ifdef USE_VECTOR_ARRAYS
	#include <algorithm>	///< for std::lower_bound (binary search) with std::vector
#endif

//------------------------------------------------------------------------------
// Everything is behind the ngram namespace
namespace ngram
{


//------------------------------------------------------------------------------
// Fixed arrays version. This is faster, but uses a bit more memory.
#ifdef USE_FIXED_ARRAYS

//--------------------------------------------------------------------------------------------------
// Clear the data out to be used as a leaf node
template <int E>
void Node_Data<E>::Clear_As_Leaf( void )
{
	most_index = 0;
	total_occurrences = 0;
	for ( int i = 0; i < E; ++i )
	{
		counts[i] = 0;
	}
}
//--------------------------------------------------------------------------------------------------

//--------------------------------------------------------------------------------------------------
// Clear the data out to be used as a branch node
template <int E>
void Node_Data<E>::Clear_As_Branch( void )
{
	most_index = -1;
	total_occurrences = -1;
	for ( int i = 0; i < E; ++i )
	{
		indices[i] = NULL_NODE;
	}
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Add a count to an event.
template <int E>
void Tally_Array<E>::Add_Count ( int event, int count_to_add )
{
	// Event range checking is done already in caller object
	this->counts[event] += count_to_add;

	// This is a new occurrence
	this->total_occurrences += count_to_add;

	// If this is our first occurrence, then this event has the most occurrences
	if ( this->total_occurrences == count_to_add )
	{
		this->most_index = event;
		return;
	}

	// Update the most_index if this event has more than the previous most
	if ( this->counts[this->most_index] < this->counts[event] )
	{
		this->most_index = event;
	}

}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Get the total number of tallies stored under this window
template <int E>
int Tally_Array<E>::Count_Total ( void ) const
{
	return this->total_occurrences;
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Get the event with the most tallies. Lowest event ID one always wins in the case of a tie.
template <int E>
int Tally_Array<E>::Most ( void )
{
	return this->most_index;
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Get the tally count for the event that occurred the most
template <int E>
int Tally_Array<E>::Most_Count ( void ) const
{
	return this->counts[this->most_index];
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Get the tally count for a specific event
template <int E>
int Tally_Array<E>::Count_Of (int event) const
{
	// Event range verification is already done in calling class
	return this->counts[event];
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Memory bank functions


//--------------------------------------------------------------------------------------------------
// Initialize us with the memory we need
template <int E>
void Memory_Bank<E>::Initialize_Memory_Pool ( void * mem_pool, int pool_size_bytes )
{
	// If we already had a memory pool, copy everything over if it will fit. If it won't, throw error
	if ( bank != 0 )
	{
		if ( pool_size_bytes < Bytes_Used() )
		{
			throw "AI, Ngram error: A new memory pool was provided, but it is smaller than our current usage.";
		}

		std::memcpy(mem_pool, bank, Bytes_Used());
	}
	// If we didn't have a pool previously, then our size is zero. Otherwise we keep the same size
	else
	{
		size = 0;
	}

	// Everything is memory checked before coming in here
	bank = reinterpret_cast< Node_Data<E>*> (mem_pool);
	capacity_bytes = pool_size_bytes;
	capacity = capacity_bytes / sizeof(Node_Data<E>);
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Report how many bytes we're using right now
template <int E>
int Memory_Bank<E>::Bytes_Used ( void ) const
{
	return size * sizeof(Node_Data<E>);
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Allocate a new Node_Data<E> object and give us the ID for it
template <int E>
Node_ID Memory_Bank<E>::Alloc_Node( void )
{
	// Check if there's room
	if ( size == capacity )
	{
		// Call user callback to alert them of out of memory error
		(*out_of_memory_callback)();
		return -1;
	}

	Node_ID new_id = size++;
	return new_id;
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Clear out all stored nodes to start over with all memory available again
template <int E>
void Memory_Bank<E>::Clear ( void )
{
	size = 0;
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Access a node data object in our memory pool by its ID
template <int E>
Node_Data<E> & Memory_Bank<E>::Node( Node_ID const & id )
{
	return bank[id];
}
//--------------------------------------------------------------------------------------------------

//--------------------------------------------------------------------------------------------------
// Overloads for array subscript operator
template <int E>
Node_Data<E> & Memory_Bank<E>::operator[] ( Node_ID const & id )
{
	return bank[id];
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
template <int E>
Node_Data<E> const & Memory_Bank<E>::operator[] (Node_ID const & id ) const
{
	return bank[id];
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Use this out of memory callback when the memory pool runs out
template <int E>
void Memory_Bank<E>::Use_Out_Of_Memory_Callback( void (*callback)(void) )
{
	out_of_memory_callback = callback;
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// Use this default callback function for when the memory pool runs out
template <int E>
void Memory_Bank<E>::Default_Out_Of_Memory_Callback( void )
{
	// AI, Ngram library error:
	// The provided memory pool has run out. Another node cannot be allocated.
	// To fix, you can provide more memory in the call to Ngram::Use_This_Memory().
	// To change this error behavior, modify this function or provide your own callback
	// via Ngram::Use_This_Out_Of_Memory_Callback().

	throw std::bad_alloc();
}
//--------------------------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Ctor
template <int E>
Memory_Bank<E>::Memory_Bank( void )
{
	bank = 0;
	size = capacity = capacity_bytes = 0;
	out_of_memory_callback = &Default_Out_Of_Memory_Callback;
}
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Pattern_Counts functions:


//------------------------------------------------------------------------------
// Add more counts to a pattern. May insert a new pattern if not already stored
template <int N, int E>
void Pattern_Counts<N, E>::Add_Count ( int const pattern[N-1], int event, int count )
{
	// If it's a unigram, add it and get out
	if ( N == 1 )
	{
		Tally_Array<E> & tally_array = * static_cast< Tally_Array<E>* >(&root);
		tally_array.Add_Count(event, count);
		total_occurrences += count;
		return;
	}

	// Check if this pattern already exists in the tally tree

	// We'll walk down the tree, creating nodes as needed
	int level = 0;
	Node_Data<E> * node = &root;

	// Go N-1 levels down to find the tallies
	while ( level < (N-1) )
	{
		// Use the event to lookup the ID for the node at the next level
		Node_ID node_id = node->indices[pattern[level]];

		// If the ID is bad, make a new node
		if ( node_id == NULL_NODE )
		{
			node_id = node_bank.Alloc_Node();
			// Clear it out appropriately
			// If the next level would break the loop, we're at the leaf level
			if ( (level+1) == (N-1) )
			{
				node_bank[node_id].Clear_As_Leaf();
			}
			else
			{
				node_bank[node_id].Clear_As_Branch();
			}

			// Hook this node into the tree
			node->indices[pattern[level]] = node_id;
		}

		// If we couldn't create a node due to no memory, give up and don't record this event
		if ( node_id == NULL_NODE )
		{
			return;
		}

		// Now we have the ID for the next node, so get at it to walk our pointer down the tree
		node = & node_bank[node_id];

		// Step down to the next tree level
		++level;
	}

	// If the pattern wasn't stored yet, we allocated memory for it
	// If the memory could not be allocated, we exited this function already
	// Now we are guaranteed to have a tally array for this pattern

	// Now node points to the tally array that matches this window (leaf node)
	Tally_Array<E> & tallies = * static_cast< Tally_Array<E>*>(node);
	tallies.Add_Count(event, count);

	// Keep a running total of all events
	total_occurrences += count;

}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Lookup the patterns that match this window. (Fills our cache)
template <int N, int E>
void Pattern_Counts<N, E>::Lookup_Window ( int const window[N-1] )
{
	// If we haven't had any occurrences, we can't point to anything
	if ( !total_occurrences )
	{
		window_matches = 0;
		return;
	}

	// For unigrams, don't bother looking up a window because there isn't one
	if ( N == 1 )
	{
		window_matches = static_cast< Tally_Array<E>* >(&root);
		return;
	}

	// Find the pattern if it exists

	// We'll walk down the tree, stopping if any child is a null node
	int level = 0;
	Node_Data<E> * node = &root;

	// Go N-1 levels down maximum
	while ( level < (N-1) )
	{
		// Use the event to lookup the ID for the node at the next level
		Node_ID node_id = node->indices[window[level++]];

		// If the ID is bad, we're done
		if ( node_id == NULL_NODE )
		{
			window_matches = 0;
			return;
		}

		// Now we have the ID for the next node, so get at it to walk our pointer down the tree
		node = & node_bank[node_id];
	}

	// Now node points to the tally array (bottom level) for this pattern
	window_matches = static_cast<Tally_Array<E>*>(node);
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the event with the most occurrences for the last window looked up
template <int N, int E>
int Pattern_Counts<N, E>::Get_Most( void ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->Most();
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the number of occurrences for the given event in the looked up window
template <int N, int E>
int Pattern_Counts<N, E>::Get_Most_Count ( void ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->Most_Count();
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the number of occurrences for the given event in the looked up window
template <int N, int E>
int Pattern_Counts<N, E>::Get_Count ( int event ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->Count_Of(event);
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the number of occurrences of the matches of the window last looked up
template <int N, int E>
int Pattern_Counts<N, E>::Get_Match_Count ( void ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->Count_Total();
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Report if there is a cached set of window-matching event tallies ready. Returns false if nothing cached
// If calling this after calling Lookup_Window(), it means the window has no matches
template <int N, int E>
bool Pattern_Counts<N, E>::Looked_Up_Window_Has_Matches( void ) const
{
	// Just check the pointer here
	return window_matches != 0;
}
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Report the number of bytes used by whatever pattern matching data structure we are using
template <int N, int E>
int Pattern_Counts<N, E>::Get_Bytes_Used ( void ) const
{
	return node_bank.Bytes_Used();
}
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// If we are using the Fixed Arrays version, use this memory
template <int N, int E>
void Pattern_Counts<N, E>::Use_Mem_Pool ( void * mem_pool, int size_bytes )
{
	node_bank.Initialize_Memory_Pool(mem_pool, size_bytes);
}
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Use this out of memory callback when the memory pool runs out
template <int N, int E>
void Pattern_Counts<N, E>::Use_Out_Of_Memory_Callback( void (*callback)(void) )
{
	node_bank.Use_Out_Of_Memory_Callback( callback );
}
//--------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Get at the patterns matching the looked up window
template <int N, int E>
Tally_Array<E> * Pattern_Counts<N, E>::Get_Matches ( void ) const
{
	return window_matches;
}
//--------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Start over with an empty slate
template <int N, int E>
void Pattern_Counts<N, E>::Reset ( void )
{
	node_bank.Clear();
	total_occurrences = 0;
	window_matches = 0;

	// We need to clear out the root node data. If we are a unigram, the root is a leaf
	if ( N == 1 )
	{
		root.Clear_As_Leaf();
	}
	else
	{
		root.Clear_As_Branch();
	}
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Ctor
template <int N, int E>
Pattern_Counts<N, E>::Pattern_Counts( void )
: total_occurrences(0), node_bank(), root(), window_matches(0)
{
	Reset();
}
//------------------------------------------------------------------------------


// End of fixed arrays version
#endif
//------------------------------------------------------------------------------









//------------------------------------------------------------------------------
// Vector arrays version. This uses less memory, but is slower and causes more allocations
#ifdef USE_VECTOR_ARRAYS


//------------------------------------------------------------------------------
Tally::Tally( int event_id, int start_count )
: event(event_id), count(start_count)
{
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
bool Tally::operator < ( int rhs ) const
{
	return event < rhs;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
Tallies::Tallies( void )
: tallies(), total_occurrences(0), most_index(0)
{
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
void Tallies::Add_Count ( int event, int count )
{
	// Update our total occurrences so we never need to calculate it
	total_occurrences += count;

	// If we were empty,
	if ( total_occurrences == count )
	{
		// Reserve 3 the first time
		tallies.reserve(3);
		tallies.push_back(Tally(event, count));
		most_index = 0;
		return;
	}

	// Find this event in the sorted array via binary search
	std::vector<Tally>::iterator iter;
	iter = std::lower_bound(tallies.begin(), tallies.end(), event);

	// Grab index now, since it will possibly be invalidated later
	int index = iter - tallies.begin();

	// If not found, add it in sorted order (iter could point to where it goes)
	if ( iter == tallies.end() || iter->event != event )
	{
		tallies.insert(iter, Tally(event, count)); ///< May invalidate iter
	}
	// If found, increment its count
	else
	{
		tallies[index].count += count;
	}

	// Update index with most counts for a speed optimization
	if ( tallies[most_index].count < tallies[index].count )
	{
		most_index = index;
	}

}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
int Tallies::Count_Total( void )
{
	return total_occurrences;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
int Tallies::Count_Of( int event )
{
	if ( total_occurrences == 0 )
	{
		return 0;
	}

	// Find this event and check its count, do binary search
	std::vector<Tally>::iterator iter;
	iter = std::lower_bound(tallies.begin(), tallies.end(), event);

	if ( iter == tallies.end() || iter->event != event )
	{
		return 0;
	}
	else
	{
		return iter->count;
	}

}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
int Tallies::Most( void )
{
	if ( total_occurrences == 0 )
	{
		// First possible event wins
		return 0;
	}

	return tallies[most_index].event;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
int Tallies::Most_Count( void )
{
	if ( total_occurrences == 0 )
	{
		return 0;
	}

	return tallies[most_index].count;
}
//------------------------------------------------------------------------------






//------------------------------------------------------------------------------
// A pattern storing N-1 events, plus a list of tallies for each final event
template <int N>
Pattern_Match<N>::Pattern_Match ( Pattern_Match<N> const & rhs )
{
	// Use assignment operator
	*this = rhs;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
template <int N>
Pattern_Match<N>::Pattern_Match(int const Pattern[N], int event, int count)
{
	// Copy over the window length elements of the pattern
	for ( int i = 0; i < (N-1); ++i )
	{
		pattern[i] = Pattern[i];
	}

	tallies.Add_Count(event, count);
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
template <int N>
Pattern_Match<N>::Pattern_Match(int const Pattern[N], int count)
{
	// Copy over the window length of the pattern
	for ( int i = 0; i < (N-1); ++i )
	{
		pattern[i] = Pattern[i];
	}

	// The last event in the pattern gets added to the tallies
	tallies.Add_Count(Pattern[N-1]);
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// For sorting. Determine if our pattern is less than the other
template <int N>
bool Pattern_Match<N>::operator< ( Pattern_Match<N> const & rhs ) const
{
	return *this < rhs.pattern;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
template <int N>
bool Pattern_Match<N>::operator== ( Pattern_Match<N> const & rhs ) const
{
	// Break out early if we are lesser or greater, continue if equal
	for ( int i = 0; i < (N-1); ++i )
	{
		if ( pattern[i] != rhs.pattern[i] ) { return false; }
	}

	// At this point, we're equal
	return true;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
template <int N>
Pattern_Match<N> & Pattern_Match<N>::operator= ( Pattern_Match<N> const & rhs )
{
	for ( int i = 0; i < (N-1); ++i )
	{
		pattern[i] = rhs.pattern[i];
	}
	tallies = rhs.tallies;
	return *this;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
template <int N>
bool Pattern_Match<N>::operator< ( int const Pattern[N-1] ) const
{
	// Break out early if we are lesser or greater, continue if equal
	for ( int i = 0; i < (N-1); ++i )
	{
				 if ( pattern[i] < Pattern[i] ) { return true; }
		else if ( pattern[i] > Pattern[i] ) { return false; }
	}
	// At this point, we're equal
	return false;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
template <int N>
bool Pattern_Match<N>::operator== (int const Pattern[N]) const
{
	// Break out early if we are lesser or greater, continue if equal
	for ( int i = 0; i < (N-1); ++i )
	{
		if ( pattern[i] != Pattern[i] ) { return false; }
	}

	// At this point, we're equal
	return true;
}
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Pattern_Counts members


//------------------------------------------------------------------------------
// Add more counts to a pattern. May insert a new pattern if not already stored
template <int N, int E>
void Pattern_Counts<N, E>::Add_Count ( int const pattern[N-1], int event, int count )
{
	// Keep a running total for convenience
	total_occurrences += count;

	// If it's the first one, we're done easy
	if ( total_occurrences == count )
	{
		patterns.push_back( Pattern_Match<N>(pattern, event, count) );
		return;
	}

	// If it's a darn unigram, just throw the count in and get out
	if ( N == 1 )
	{
		patterns[0].tallies.Add_Count(event, count);
		return;
	}

	// Find this pattern in the sorted list via binary search
	typename std::vector< Pattern_Match<N> >::iterator iter;
	iter = std::lower_bound(patterns.begin(), patterns.end(), pattern);

	// Grab the index where it will exist (either now or after insertion)
	int index = iter - patterns.begin();

	// If we hit the end of the list, or if this pattern isn't known, we need to add it in
	if ( iter == patterns.end() || !(*iter == pattern) )
	{
		patterns.insert(iter, Pattern_Match<N>(pattern, event, count));	///< invalidates iter
	}
	// If this pattern was found, update the counts
	else
	{
		patterns[index].tallies.Add_Count(event, count);
	}

}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Lookup the patterns that match this window. (Fills our cache)
template <int N, int E>
void Pattern_Counts<N, E>::Lookup_Window ( int const window[N-1] )
{
		// If we haven't had any occurrences, we can't point to anything
		if ( !total_occurrences )
		{
			window_matches = 0;
			return;
		}

	// For unigrams, don't do this
	if ( N == 1 )
	{
		window_matches = &*patterns.begin();
		return;
	}

	// Find if the given pattern exists via binary search
	typename std::vector< Pattern_Match<N> >::iterator iter;
	iter = std::lower_bound(patterns.begin(), patterns.end(), window);

	// Check if we found it or not
	if ( iter == patterns.end() || !(*iter == window) )
	{
		window_matches = 0;
	}
	else
	{
		// Cache this lookup. Save a pointer to this pattern's occurrence stats for later
		window_matches = &*iter;
	}
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the event with the most occurrences for the last window looked up
template <int N, int E>
int Pattern_Counts<N, E>::Get_Most( void ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->tallies.Most();
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the number of occurrences for the given event in the looked up window
template <int N, int E>
int Pattern_Counts<N, E>::Get_Most_Count ( void ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->tallies.Most_Count();
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the number of occurrences for the given event in the looked up window
template <int N, int E>
int Pattern_Counts<N, E>::Get_Count ( int event ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->tallies.Count_Of(event);
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get the number of occurrences of the matches of the window last looked up
template <int N, int E>
int Pattern_Counts<N, E>::Get_Match_Count ( void ) const
{
	if ( window_matches == 0 )
	{
		return 0;
	}

	return window_matches->tallies.Count_Total();
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Report if there is a cached set of window-matching event tallies ready. Returns false if nothing cached
// If calling this after calling Lookup_Window(), it means the window has no matches
template <int N, int E>
bool Pattern_Counts<N, E>::Looked_Up_Window_Has_Matches( void ) const
{
	// Just check the pointer here
	return window_matches != 0;
}
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Report the number of bytes used by whatever pattern matching data structure we are using
template <int N, int E>
int Pattern_Counts<N, E>::Get_Bytes_Used ( void ) const
{
	// Count capacity for vectors instead of size, since that's the real amount of memory allocated

	int patterns_count = (int)patterns.capacity();

	// Start with the size of our array times the sizeof(element)
	int bytes = patterns_count * sizeof(Pattern_Match<N>);

	// Add in the tallies vector size * sizeof(tally) for each pattern_match
	for ( int i = 0; i < patterns_count; ++i )
	{
		bytes += (int)patterns[i].tallies.tallies.capacity() * (int)sizeof(Tally);
	}

	return bytes;
}
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Get at the patterns matching the looked up window
template <int N, int E>
Pattern_Match<N> * Pattern_Counts<N, E>::Get_Matches ( void ) const
{
	return window_matches;
}
//--------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Start over with an empty slate
template <int N, int E>
void Pattern_Counts<N, E>::Reset ( void )
{
	patterns.clear();
//	patterns.shrink_to_fit();	///< get rid of old memory
	patterns.reserve(N);	///< save a little space. why not.
	total_occurrences = 0;
	window_matches = 0;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Ctor
template <int N, int E>
Pattern_Counts<N, E>::Pattern_Counts( void )
: total_occurrences(0), patterns(), window_matches(0)
{

}
//------------------------------------------------------------------------------

#endif	///< Vector arrays implementation
//--------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Ngram members


//------------------------------------------------------------------------------
// Take an entire series of inputs at once
template <int N, int E>
void Ngram<N, E>::Add_Events ( int const * events, int length )
{
	// Error checking the event IDs is done in the function call below
	// Just throw them in one at a time
	while (length--)
	{
		Add_Event(*events++);
	}
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Take a single new input and add to existing
template <int N, int E>
void Ngram<N, E>::Add_Event( int event )
{
	VERIFY_EVENTS(&event, 1);

	// Once we get enough events, we start getting full pattern occurrences
	if ( ++total_event_occurrences >= N )
	{
		++total_pattern_occurrences;
	}

	// Add this new pattern if a pattern has completed (not when events is < N)
	if ( total_pattern_occurrences > 0 )
	{
		pattern_counts.Add_Count(window, event);
	}

	// Update the window by moving everything over
	for ( int i = 0; i < (N-1 -1); ++i )
	{
		window[i] = window[i+1];
	}
	// Throw this new event onto the back of the window (if we have one)
	if ( N > 1 )	///< if window size is greater than 0
	{
		window[N-1 -1] = event;
	}

#ifdef USE_FIXED_ARRAYS
	// If we're using the event window, it's changed, so we need to look it up again
	if ( use_event_window )
	{
		need_lookup = true;
	}
#endif

#ifdef USE_VECTOR_ARRAYS
	// Invalidate cache for vector array version, since adding to the vector could have invalidated our cache pointer
	// We'll need to do a new lookup the next time we're asked for a prediction or probability
	need_lookup = true;
#endif
}
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Get next predicted event to occur
template <int N, int E>
int Ngram<N, E>::Predict( void ) const
{
	// Lookup the current window in the pattern if necessary
	Handle_Lookup();

	// If we're using a weighted random, consider all possibilities
	if ( use_weighted_random )
	{
		return Get_Weighted_Random_Prediction();
	}

	// If we aren't using a weighted random, use the most frequent event as our prediction

	// If nothing's happened, predict 0 as "random"
	if ( !total_pattern_occurrences)
	{
		return last_prediction = 0;
	}

	// Get the prediction, the one with the most occurrences that matches the current window
	return last_prediction = pattern_counts.Get_Most();
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get "probability" of next predicted value
template <int N, int E>
float Ngram<N, E>::Confidence( void ) const
{
	// If we haven't seen any occurrences yet
	if ( total_pattern_occurrences == 0 )
	{
		// then just return the probability of any event type
		return 1.f / E;
	}

	// Get occurrences of the last predicted event
	Handle_Lookup();
	int occurrences = pattern_counts.Get_Count(last_prediction);

	// From formula in paper
	int numerator = occurrences + 1;
	int denominator = pattern_counts.Get_Match_Count() + E;

	return (float)numerator / denominator;	///< den cannot be zero
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get next predicted value and its "probability" at once
template <int N, int E>
int Ngram<N, E>::Predict( float & probability_of_next )
{
	int prediction = Predict();
	probability_of_next = Confidence();
	return prediction;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get "probability" that a certain event will come next
template <int N, int E>
float Ngram<N, E>::Probability_Next_Is( int event ) const
{
	VERIFY_EVENTS(&event, 1);

	// If we haven't seen any occurrences yet
	if ( total_pattern_occurrences == 0 )
	{
		return 1.f / E;
	}

	Handle_Lookup();
	int occurrences = pattern_counts.Get_Count(event);

	// From formula in paper
	int numerator = occurrences + 1;
	int denominator = pattern_counts.Get_Match_Count() + E;

	return (float)numerator / denominator;	///< den cannot be zero
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get probability of a pattern to occur in the future
template <int N, int E>
float Ngram<N, E>::Probability_Future( int const pattern[N] ) const
{
	VERIFY_EVENTS(pattern, N);

	// If we haven't seen any occurrences yet
	if ( total_pattern_occurrences == 0 )
	{
		return 1.f / E;
	}

	// Do a lookup to find this pattern match
	pattern_counts.Lookup_Window(pattern);
	// Invalidate cache since we did a different lookup
	need_lookup = true;

	// We want the number of occurrences of this exact pattern
	int occurrences = pattern_counts.Get_Count(pattern[N-1]);

	// From formula in paper
	int numerator = occurrences + 1;
	float denominator = (float)total_pattern_occurrences + pow((float)E, N);

	return (float)numerator / denominator;	///< den cannot be zero
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Predict using a weighted random. This is off by default.
template <int N, int E>
void Ngram<N, E>::Use_Weighted_Random( bool enable )
{
	use_weighted_random = enable;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Predict using the implicit window from the event sequence (default)
template <int N, int E>
void Ngram<N, E>::Use_Window_From_Event_Sequence (void)
{
	use_event_window = true;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Predict with this window (rather than using the sequence window)
template <int N, int E>
void Ngram<N, E>::Use_Window( int const pattern[N-1] )
{
	VERIFY_EVENTS(pattern, N-1);

	// copy it in to remember it for later, when doing lookups again
	for (int i = 0; i < (N-1); ++i )
	{
		user_window[i] = pattern[i];
	}

	// Stop using event sequence as window
	use_event_window = false;
	// Go ahead and lookup this pattern now since users will expect it
	pattern_counts.Lookup_Window(user_window);
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Clear out history to start anew
template <int N, int E>
void Ngram<N, E>::Reset( void )
{
	total_pattern_occurrences = 0;
	total_event_occurrences = 0;
	last_prediction = 0;
	pattern_counts.Reset();
	need_lookup = true;
	// No need to initialize the windows since occurrences is 0
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Ctor
template <int N, int E>
Ngram<N, E>::Ngram( void )
{
	Reset();

	// Start off using the implicit event sequence window, and not doing weighted randoms
	use_weighted_random = false;
	use_event_window = true;

	// Use rand() as the random int generator
	Random_Int = &rand;

}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Report the amount of memory we're using
// Use this to determine how much memory to provide to the Fixed Arrays version
template <int N, int E>
int Ngram<N, E>::Memory_Usage_Bytes ( void ) const
{
	return pattern_counts.Get_Bytes_Used();
}
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Provide your own random integer generator, otherwise we'll use std::rand() by default
template <int N, int E>
void Ngram<N, E>::Use_This_Random_Int_Generator( int (*user_rng) ( void ) )
{
	Random_Int = user_rng;
}
//--------------------------------------------------------------------------------------------------



#ifdef USE_FIXED_ARRAYS

//------------------------------------------------------------------------------
/// Provide memory for the fixed array implementation to use
/// If we aren't compiled with the fixed array
template <int N, int E>
void Ngram<N, E>::Use_This_Memory ( void * mem_pool, unsigned size_bytes )
{
	pattern_counts.Use_Mem_Pool( mem_pool, size_bytes );
}
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Provide a callback function for when the mem pool runs out
template <int N, int E>
void Ngram<N, E>::Use_This_Out_Of_Memory_Callback ( void (*callback)(void) )
{
	pattern_counts.Use_Out_Of_Memory_Callback( callback );
}
//--------------------------------------------------------------------------------------------------

#endif


//-----------------------------------------------------------------------------
// Ngram private functions



//------------------------------------------------------------------------------
// Verify that events provided are less than the max specified at templatization
template<int N, int E>
void Ngram<N, E>::Verify_Events( int const * events, int count ) const
{
	while (count--)
	{
		// If the event is out of range,
		if ( *events >= E || *events < 0 )
		{
			// The user passed in an invalid event ID, or constructed us with a bad template argument E.
			// Handle this however you wish
			throw("AI ngram error: An invalid event was used. All events should be ranged [0, E). E is the template argument for max event types.");
		}
		++events;
	}
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
template<int N, int E>
void Ngram<N, E>::Handle_Lookup( void ) const
//------------------------------------------------------------------------------
{
#ifdef USE_FIXED_ARRAYS
	// Fixed arrays version doesn't move occurrence data when adding new data, so
	// it never needs to invalidate the cache if using a user-provided window for prediction

	// Don't do a lookup if we're using the user window or if the cache isn't dirty
	if ( use_event_window && need_lookup )
	{
		pattern_counts.Lookup_Window(window);
	}
#endif

#ifdef USE_VECTOR_ARRAYS
	// Don't do a lookup if we're using the user window or if the cache isn't dirty
	if ( need_lookup )
	{
		// Lookup the event sequence window, or the user-provided window, whichever we are currently using
		if ( use_event_window )
		{
			pattern_counts.Lookup_Window(window);
		}

		else
		{
			pattern_counts.Lookup_Window(user_window);
		}
	}
#endif

}
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
/// Predict using a weighted random
template<int N, int E>
int Ngram<N, E>::Get_Weighted_Random_Prediction( void ) const
//------------------------------------------------------------------------------
{

	// If no pattern has taken place yet, or the current pattern has not, then just pick a random event
	if ( !total_pattern_occurrences || !pattern_counts.Looked_Up_Window_Has_Matches() )
	{
		return last_prediction = (*Random_Int)() % E;
	}

	// First get our random value
	int random = (*Random_Int)();
	// Wrap it between 0 and the total occurrences of the current pattern
	int match_count = pattern_counts.Get_Match_Count();

	random %= (1 + match_count);

	// We have a random number ranged [0, match_count]

	// To pick a weighted random, we use the occurrence count for each event that occurred with the current window
	// We step through each stored event, and reduce the random number by the occurrence count for that event
	// When the random number reaches 0 or below, the event that caused it is the one we'll pick

	// If there are 100 occurrences for events matching this window,
	// 	and event 0 has 20 occurrences,
	// 	then reducing the random number by event 0's occurrences will make us pick 0 20% of the time,
	// 	because a random number ranged [0,20) should occur 20% of the time,
	// 	and reducing that number by 20 will make it reach 0 or below

	// Our tallies are stored differently based on our storage choice, so handle each iteration case below

#ifdef USE_FIXED_ARRAYS

// Iterate through an array of counts, where each element is an event
int (&counts)[E] = pattern_counts.Get_Matches()->counts;

// Step through each event in the array of counts
int event = 0;
// event will get incremented at least once no matter what
do
{
	random -= counts[event++];
} while (random > 0);

// Return whichever event we reached, and set it as our last prediction
return last_prediction = counts[event-1];	///< event was incremented at least once. It could be zero after this subtraction, which is fine

#endif



#ifdef USE_VECTOR_ARRAYS

	// Iterate through a vector of tallies, where each tally stores an event and a count
	// Start walking through each event in this pattern to pick one
	std::vector<Tally> & tallies = pattern_counts.Get_Matches()->tallies.tallies;
	int i = 0;
	do	///< do loop ensures i gets incremented at least once
	{
		// Subtract the occurrences of this event from our random number until
		// it goes to zero (or below), in which case we pick that event
		random -= tallies[i++].count;	///< increments event, don't forget after loop!
	} while ( random > 0 );


	// We're there, so return this event
	return last_prediction = tallies[i-1].event;	///< event was incremented in loop, guaranteed
#endif
}
//------------------------------------------------------------------------------















//------------------------------------------------------------------------------
// Ngram template specialization for unigram
// Yes, we'll do an entire new implementation of the Ngram class for Unigrams. Oi.


//------------------------------------------------------------------------------
// Take an entire series of inputs at once
template <int E>
void Ngram<1, E>::Add_Events ( int const * events, int length )
{
	VERIFY_EVENTS(events, length);

	for ( int i = 0; i < length; ++i )
	{
		if ( ++counts[events[i]] > counts[most_event] )
		{
			most_event = events[i];
		}
	}

	total_event_occurrences += length;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Take a single new input and add to existing
template <int E>
void Ngram<1, E>::Add_Event( int event )
{
	VERIFY_EVENTS(&event, 1);

	++total_event_occurrences;

	if ( ++counts[ event ] > counts[most_event] )
	{
		most_event = event;
	}

}
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Get next predicted event to occur
template <int E>
int Ngram<1, E>::Predict( void ) const
{
	// If we're using a weighted random, consider all possibilities
	if ( use_weighted_random )
	{
		return last_prediction = Get_Weighted_Random_Prediction();
	}

	// If we aren't using a weighted random, use the most frequent event as our prediction

	// If nothing's happened, predict 0 as "random"
	if ( !total_event_occurrences)
	{
		return last_prediction = 0;
	}

	// Get the prediction, the one with the most occurrences
	return last_prediction = most_event;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get "probability" of next predicted value
template <int E>
float Ngram<1, E>::Confidence( void ) const
{
	// If we haven't seen any occurrences yet
	if ( total_event_occurrences == 0 )
	{
		// then just return the probability of any event type
		return 1.f / E;
	}

	// Get occurrences of the last predicted event
	int occurrences = counts[last_prediction];

	// From formula in paper
	int numerator = occurrences + 1;
	int denominator = total_event_occurrences + E;

	return (float)numerator / denominator;	///< den cannot be zero
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get next predicted value and its "probability" at once
template <int E>
int Ngram<1, E>::Predict( float & probability_of_next )
{
	int prediction = Predict();
	probability_of_next = Confidence();
	return prediction;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Get "probability" that a certain event will come next
template <int E>
float Ngram<1, E>::Probability_Next_Is( int event ) const
{
	VERIFY_EVENTS(&event, 1);

	// If we haven't seen any occurrences yet
	if ( total_event_occurrences == 0 )
	{
		return 1.f / E;
	}

	int occurrences = counts[event];

	// From formula in paper
	int numerator = occurrences + 1;
	int denominator = total_event_occurrences + E;

	return (float)numerator / denominator;	///< den cannot be zero
}
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
/// Get the probability that a certain event will occur in the future. For unigrams, this is the same as calling Probability_Next_Is()
template<int E>
float Ngram<1, E>::Probability_Future( int event ) const
{
	return Probability_Next_Is( event );
}
//--------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Predict using a weighted random. This is off by default.
template <int E>
void Ngram<1, E>::Use_Weighted_Random( bool enable )
{
	use_weighted_random = enable;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Clear out history to start anew
template <int E>
void Ngram<1, E>::Reset( void )
{
	// Clear out all the counts
	std::memset(counts, 0, E*sizeof(int));
	most_event = 0;
	total_event_occurrences = 0;
	last_prediction = 0;

}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Ctor
template <int E>
Ngram<1, E>::Ngram( void )
{
	Reset();

	// Start off using the implicit event sequence window, and not doing weighted randoms
	use_weighted_random = false;

	// Use rand() as the random int generator
	Random_Int = &rand;
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Report the amount of memory we're using
// Use this to determine how much memory to provide to the Fixed Arrays version
template <int E>
int Ngram<1, E>::Memory_Usage_Bytes ( void ) const
{
	return E * sizeof(int);
}
//------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
/// Provide your own random integer generator, otherwise we'll use std::rand() by default
template <int E>
void Ngram<1, E>::Use_This_Random_Int_Generator( int (*user_rng) ( void ) )
{
	Random_Int = user_rng;
}
//--------------------------------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Ngram private functions for unigram specialization



//------------------------------------------------------------------------------
// Verify that events provided are less than the max specified at templatization
template<int E>
void Ngram<1, E>::Verify_Events( int const * events, int count ) const
{
	while (count--)
	{
		// If the event is out of range,
		if ( *events >= E || *events < 0 )
		{
			// The user passed in an invalid event ID, or constructed us with a bad template argument E.
			// Handle this however you wish
			throw("AI ngram error: An invalid event was used. All events should be ranged [0, E). E is the template argument for max event types.");
		}
		++events;
	}
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
/// Predict using a weighted random
template<int E>
int Ngram<1, E>::Get_Weighted_Random_Prediction( void ) const
//------------------------------------------------------------------------------
{
	// If no event has occurred yet, then just pick a random event
	if ( !total_event_occurrences )
	{
		return (*Random_Int)() % E;
	}

	// First get our random value and wrap it between 0 and the total occurrences
	int random = (*Random_Int)() % total_event_occurrences;

	// We have a random number ranged [0, total occurrences)

	// To pick a weighted random, we use the occurrence count for each event that occurred.
	// We step through each stored event, and reduce the random number by the occurrence count for that event.
	// When the random number reaches 0 or below, the event that caused it is the one we'll pick.

	// If there are 100 events that have occurred,
	// 	and event 0 has 20 occurrences,
	// 	then reducing the random number by event 0's occurrences will make us pick event 0 20% of the time,
	// 	because a random number ranged [0,20) should occur 20% of the time,
	// 	and reducing that number by 20 will make it reach 0 or below

	int event = 0;
	do
	{
		random -= counts[event++];
	} while (random > 0);

	return counts[event-1];	//< event variable was incremented once no matter what
}
//------------------------------------------------------------------------------











}
// End of ngram namespace
//--------------------------------------------------------------------------------------------------



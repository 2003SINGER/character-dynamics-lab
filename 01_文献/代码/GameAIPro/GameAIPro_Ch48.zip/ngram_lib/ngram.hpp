//-----------------------------------------------------------------------------
/// \par	Copyright 2012-2013 Joseph Vasquez II, All rights reserved
/// \par You can use it though

/// \version Version 1.0, distibuted with Game AI Pro, 2013

///	Description:
///		Declares templated Ngram class and its helper classes.
///		ngram.cpp is included at bottom of this file to handle template implementations
//-----------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
/// Header guard
#ifndef NGRAM_HPP
#define NGRAM_HPP
//--------------------------------------------------------------------------------------------------

//--------------------------------------------------------------------------------------------------
/// Stuff for you to configure:

// All events passed into an ngram will be ranged checked within [0, E)
// You can modify the function Verify_Events() as you please
// You can turn off event range checking by redefining this macro
#define VERIFY_EVENTS(events, count) Verify_Events((events), (count));

// There are two implementations for you, either "fixed arrays" or "vector arrays" version

// Fixed arrays:
	// Is faster at accessing occurrence count stats, which means faster predicting and event adding
	// Is a bit more hassle to use
	// Requires work memory to be provided up front, and never grows. Has good locality of reference
	// Stores occurrence counts in a custom prefix tree type structure
	// Has more memory overhead, especially for dense event sequences. Some unseen patterns are partially stored
	// Calls your callback if memory runs out

// Vector arrays:
	// Is generally slower in all aspects, due to poor locality of reference and more CPU usage
	// Is a bit easier to use, since work memory is not required up front
	// Relies on default standard allocator for memory allocations (calls new), and grows over time
	// Stores occurrences counts in a flat std::vector, and uses binary search to locate a pattern match
	// Uses less memory for dense event sequences. Only patterns seen are actually stored
	// Throws std::bad_alloc if memory runs out


// Use this to build with vector arrays version
//#define USE_VECTOR_ARRAYS

// Use this to build with fixed arrays version
#define USE_FIXED_ARRAYS

// Don't declare both, or fixed arrays will win
// Don't fail to declare one, or vector arrays will win
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
/// Housekeeping
#ifdef USE_FIXED_ARRAYS
	#undef USE_VECTOR_ARRAYS
#endif

#ifndef USE_FIXED_ARRAYS
	#define USE_VECTOR_ARRAYS
#endif

#ifdef USE_VECTOR_ARRAYS
	#include <vector>
#endif
//--------------------------------------------------------------------------------------------------

/// Everything is behind the ngram namespace
namespace ngram
{

// Forward dec
template <int N, int E>
class Pattern_Counts;

//--------------------------------------------------------------------------------------------------
/// Here is the Ngram class. It's the only class you have to care about
/// Instantiate by providing the N value and E number of events, like this: Ngram<3,5> ngram;
/// Note: unigrams are simple, so they are handled via a template specialization, and don't contain all functions listed here
template <int N_value, int E_max_events>
class Ngram
{
	//-----------------------------------------------------------------------------
	// Public functions
	public:

		// Add a single new event to the ngram's queue. This is used for runtime learning
		void Add_Event( int event );

		// Add multiple new events to the ngram's queue all at once. It's useful when offline learning occurred previously
		void Add_Events ( int const * events, int length );

		// Get the event predicted to occur next
		int Predict( void ) const;

		// Get the "probability" of the event predicted to occur next. This shows how confident the ngram is
		float Confidence( void ) const;

		// Get next predicted value and its "probability" together at once
		int Predict( float & probability_of_next );

		// Get the "probability" that a certain event will come next. This checks the confidence of various events
		float Probability_Next_Is( int event ) const;

		// Get the probability of a certain entire pattern occurring anytime in the future, NOT the next pattern to occur
		float Probability_Future( int const pattern[N_value] ) const;

		// Predict using a weighted random, which randomly chooses an event influenced by confidence levels. Off by default.
		void Use_Weighted_Random( bool enable );

		// Predict using the implicit window from the event sequence. On by default
		void Use_Window_From_Event_Sequence (void);

		// Predict with a provided window instead of the event sequence, for procedural generation. Off by default
		void Use_Window( int const user_window[N_value-1] );

		// Clear out our history and start anew
		void Reset( void );

		// Constructor requires nothing,
		Ngram( void );

		// Report the amount of memory we're using in this version (vectors or fixed arrays version)
		int Memory_Usage_Bytes ( void ) const;

		// Provide your own random integer generator if desired, otherwise we'll use std::rand() by default
		void Use_This_Random_Int_Generator( int (*Random_Int) ( void ) );

#ifdef USE_FIXED_ARRAYS

		// Provide memory for the fixed array implementation to use. It requires work RAM to be provided.
		void Use_This_Memory ( void * mem_pool, unsigned size_bytes );

		// Provide a custom callback function for when the provided memory pool runs out, or modify the one we use
		void Use_This_Out_Of_Memory_Callback( void (*callback)(void) );

#endif


/// You probably don't care about anything below this line







	//-----------------------------------------------------------------------------
	// Private functions
	protected:

		// Verify that events provided are less than the max specified at templatization
		void Verify_Events( int const * events, int count ) const;

		// Check if we need to lookup the current window, and do it if necessary (optimization via caching)
		void Handle_Lookup( void ) const;

		// Use a weighted random to pick an event to predict
		int Get_Weighted_Random_Prediction( void ) const;


	//-----------------------------------------------------------------------------
	// Private data
	protected:

		// The total number of event occurrences we've seen thus far
		int total_pattern_occurrences;

		// The total number of events so far
		int total_event_occurrences;

		// The last prediction we made
		mutable int last_prediction;	///< mutable cause caching happens during const functions

		// Use a weighted random for predictions
		bool use_weighted_random;

		// Use a random int generator for predicting with a weighted random
		int (*Random_Int)( void );

		// The counts for every sequence we've seen so far
		// This is mutable in order to update caching during prediction with const functions
		mutable Pattern_Counts<N_value, E_max_events> pattern_counts;

		// The current event sequence window, size N-1. (So, N must be >= 1)
		int window[N_value -1];
		// The current window set by the user, size N-1. (N must be >= 1)
		int user_window[N_value -1];

		// Tells us which window to use. We use the event window by default.
		bool use_event_window;

		// Cache dirty/clean. When nothing has been added since the last lookup, we can avoid a redundant lookup
		mutable bool need_lookup;	///< mutable since caching happens in const functions

};
//------------------------------------------------------------------------------






#ifdef USE_FIXED_ARRAYS
//------------------------------------------------------------------------------

// Fixed arrays stuffs
typedef int Node_ID;	//< ID for a node in the prefix tree
int const NULL_NODE = -1;	//< Represents an invalid node ID

//------------------------------------------------------------------------------
/// In the fixed array tree, leaf nodes and non-leaf nodes contain different data
/// To optimize the memory bank efficiency though, both nodes use the same data structure
template <int E>
struct Node_Data
{
	// Clear the data out to be used as a leaf node
	void Clear_As_Leaf( void );
	// Clear the data out to be used as a branch node
	void Clear_As_Branch( void );

	//------------------------------------------------------------------------------
	// Data members

	// Leaf nodes store the event (by its enum value) with the highest running count
	int most_index;

	// Leaf nodes store a current total of all events that have occured with this window
	int total_occurrences;

	// We store a C array of size E (max event types). There is one element for each event e.
	// The array is indexed by an event e.
	union
	{
		// If we are not a leaf node, each element stores an offset to the child node.
		// This offset is an index used by the memory bank, which stores all nodes.
		Node_ID indices[E];
		// If we are a leaf node, we store tallies for each event e
		int counts[E];
	};
};
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
/// This struct inherits node data and extends it with helper functions
/// Once Node_Data is identified as an array of tallies (not indices), we can cast
/// it to this object and pass it around in this wrapper to avoid confusion
template <int E>
struct Tally_Array : public Node_Data<E>
{
	// Add a count to an event.
	void Add_Count ( int event, int count_to_add = 1 );

	// Get the total number of tallies stored under this window
	int Count_Total ( void ) const;

	// Get the event (by its enum value) with the most tallies. First one always wins in the case of a tie.
	int Most ( void );

	// Get the tally count for the event that occurred the most
	int Most_Count ( void ) const;

	// Get the tally count for a specific event
	int Count_Of (int event) const;

	//------------------------------------------------------------------------------
	/// Data members
	// Note that we inherit the data from Node_Data
};
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
/// Stores the work memory provided by the user and allocates tally tree nodes from it
template <int E>
class Memory_Bank
{
	public:
		// Initialize us with the memory we need
		void Initialize_Memory_Pool( void * mem_pool, int size_bytes );

		// Report how many bytes we're using right now
		int Bytes_Used ( void ) const;

		// Allocate a new Node_Data<E> object and give us the ID for it
		Node_ID Alloc_Node( void );

		// Clear out all stored nodes to start over with all memory available again
		void Clear ( void );

		// Access a node data object in our memory pool by its ID
		Node_Data<E> & Node( Node_ID const & id );

		// Overloads for array subscript operator
		Node_Data<E> & operator[] ( Node_ID const & id );
		Node_Data<E> const & operator[] (Node_ID const & id ) const;

		// Use the provided out of memory callback when the memory pool runs out
		void Use_Out_Of_Memory_Callback( void (*callback)(void) );

		// Use this default callback function for when the memory pool runs out
		static void Default_Out_Of_Memory_Callback( void );

		// Ctor
		Memory_Bank( void );

	//--------------------------------------------------------------------------------------------------
	/// Data members
	protected:

		// The memory pool provided from the user
		Node_Data<E> * bank;

		// The number of Node_Data<E> elements stored in the memory pool, and max number
		int size, capacity;

		// The max number of bytes provided
		int capacity_bytes;

		// The out of memory callback provided by the user
		void (*out_of_memory_callback)( void );

};
//------------------------------------------------------------------------------



#endif	///< End of Fixed Arrays version stuffs
//------------------------------------------------------------------------------




//------------------------------------------------------------------------------
#ifdef USE_VECTOR_ARRAYS

// An event, plus a count of the number of times it's occurred at the end of a pattern
struct Tally
{
	int event;
	int count;

	Tally(int event = 0, int count = 1 );

	/// < operator used for binary search by std::lower_bound function
	bool operator < ( int rhs ) const;
};
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------
// A list of events with their counts. Each pattern has one of these at the end.
struct Tallies
{
	// Update a tally count
	void Add_Count ( int event, int count = 1 );

	// Get the number of tallies total (add them all up)
	int Count_Total( void );

	// Get the event with the most tallies. If there are any ties, first one wins.
	int Most( void );

	// Get the count of the event with the most tallies
	int Most_Count( void );

	// Get the count of a specific event
	int Count_Of(int event);

	// Ctor
	Tallies( void );


	// The list of tallies, which we want in order in memory
	std::vector<Tally> tallies;

	// The total counts of all tallies. For speed, don't calculate this every time
	int total_occurrences;

	// Keep track of the index with the most occurrences found, for a speed boost
	int most_index;

};
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// A pattern of events used for matching with a current window, etc.
// Each Pattern_Match an entry record stored in our database of observed patterns.
// It is made up of N-1 events, plus a list of tallies for each final event
template <int N>
struct Pattern_Match
{
	// Data to store our pattern start and all last digit options
	int pattern[N-1];
	Tallies tallies;

	// Ctors
	// Copy ctor needed for containers
	Pattern_Match ( Pattern_Match const & rhs );

	// Make a new pattern with the last event as part of the provided window+1 array
	Pattern_Match(int const Pattern[N], int count = 1);
	// Make a new pattern with event stated separately
	Pattern_Match(int const Pattern[N], int event, int count = 1);

	// For sorting
	bool operator< ( Pattern_Match const & rhs ) const;
	Pattern_Match & operator= ( Pattern_Match const & rhs );

	// For searching and insertion
	bool operator< ( int const Pattern[N-1] ) const;
	bool operator== ( Pattern_Match const & rhs ) const;
	bool operator== (int const Pattern[N]) const;

};
//------------------------------------------------------------------------------


#endif	///< End of Vector Arrays version stuffs
//--------------------------------------------------------------------------------------------------




//------------------------------------------------------------------------------
// A container of Pattern_Match objects, providing an easy layer for accessing stats we care about.
template <int N, int E>
class Pattern_Counts
{
public:

	// Add more counts to a pattern. May insert a new pattern if not already stored
	void Add_Count ( int const pattern_start[N-1], int pattern_last_event, int count = 1 );

	// Lookup the patterns that match this window. Updates our cached data
	void Lookup_Window ( int const window[N-1] );

	// Get the event with the most occurrences for the last window looked up
	int Get_Most( void ) const;

	// Get the number of occurrences for the most frequent event in the matching pattern
	int Get_Most_Count ( void ) const;

	// Get the number of occurrences for the given event in the looked up window
	int Get_Count ( int event ) const;

	// Get the total number of occurrences of the matches of the window last looked up
	int Get_Match_Count ( void ) const;

	// Report if there is a cached set of window-matching event tallies ready. Returns false if nothing cached
	// If calling this after calling Lookup_Window(), it means the window has no matches
	bool Looked_Up_Window_Has_Matches( void ) const;

	// Report the number of bytes used by whatever pattern matching data structure we are using
	int Get_Bytes_Used ( void ) const;

#ifdef USE_FIXED_ARRAYS
	// If we are using the Fixed Arrays version, use this memory
	void Use_Mem_Pool ( void * mem_pool, int size_bytes );

	// Use this out of memory callback when the memory pool runs out
	void Use_Out_Of_Memory_Callback( void (*callback)(void) );

#endif


#ifdef USE_FIXED_ARRAYS
	// Get at the patterns matching the looked up window
	Tally_Array<E> * Get_Matches ( void ) const;
#endif
#ifdef USE_VECTOR_ARRAYS
	// Get at the patterns matching the looked up window
	Pattern_Match<N> * Get_Matches ( void ) const;
#endif

	// Start over with an empty slate
	void Reset ( void );

	// Ctor
	Pattern_Counts( void );

	//-----------------------------------------------------------------------------
	// Private data

protected:

	// Total occurrences we've ever seen, for convenience
	int total_occurrences;

#ifdef USE_FIXED_ARRAYS

	Memory_Bank<E> node_bank;

	// The root of the tally tree
	Node_Data<E> root;

	// The cached set of counts for all events matching the last window looked up
	Tally_Array<E> * window_matches;

#endif
#ifdef USE_VECTOR_ARRAYS

	// List of all patterns, storing their occurrence counts
	std::vector< Pattern_Match<N> > patterns;

	// Used for caching. The last pattern match we've looked up from the window that was last set
	Pattern_Match<N> * window_matches;

#endif


};
//------------------------------------------------------------------------------






//--------------------------------------------------------------------------------------------------
/// We use a template specialization for unigram. Who uses unigram anyways?
template <int E>
class Ngram<1, E>
{
	//-----------------------------------------------------------------------------
	// Public functions
	public:

		// Add a single new event to the ngram's queue. This is used for runtime learning
		void Add_Event( int event );

		// Add multiple new events to the ngram's queue all at once. It's useful when offline learning occurred previously
		void Add_Events ( int const * events, int length );

		// Get the event predicted to occur next
		int Predict( void ) const;

		// Get the "probability" of the event predicted to occur next. This shows how confident the ngram is
		float Confidence( void ) const;

		// Get next predicted value and its "probability" together at once
		int Predict( float & probability_of_next );

		// Get the "probability" that a certain event will come next. This checks the confidence of various events
		float Probability_Next_Is( int event ) const;

		// Get the probability that a certain event will occur in the future. For unigrams, this is the same as calling Probability_Next_Is()
		float Probability_Future( int event ) const;

		// Predict using a weighted random, which randomly chooses an event influenced by confidence levels. Off by default.
		void Use_Weighted_Random( bool enable );

		// Clear out our history and start anew
		void Reset( void );

		// Constructor requires nothing,
		Ngram( void );

		// Report the amount of memory we're using for counts storage
		int Memory_Usage_Bytes ( void ) const;

		// Provide your own random integer generator if desired, otherwise we'll use std::rand() by default
		void Use_This_Random_Int_Generator( int (*Random_Int) ( void ) );

	//-----------------------------------------------------------------------------
	// Private functions
	protected:

		// Verify that events provided are less than the max specified at templatization
		void Verify_Events( int const * events, int count ) const;

		// Use a weighted random to pick an event to predict
		int Get_Weighted_Random_Prediction( void ) const;


	//-----------------------------------------------------------------------------
	// Private data
	protected:

		// The counts for every event we've seen so far
		int counts[E];

		// The event with the highest counts currently
		int most_event;

		// The total number of events so far
		int total_event_occurrences;

		// The last prediction we made
		mutable int last_prediction;	///< mutable cause caching happens during const functions

		// Use a weighted random for predictions
		bool use_weighted_random;

		// Use a random int generator for predicting with a weighted random
		int (*Random_Int)( void );

};
//------------------------------------------------------------------------------






}	///< end of ngram namespace


// Template inclusion
#include "ngram.cpp"

#endif
//------------------------------------------------------------------------------



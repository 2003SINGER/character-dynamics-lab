The code was built using Visual Studio 2010.  It should work 
on that compiler or later.

The demo represents a town.  The green buildings on the left 
are residential houses while the blue buildings are commercial 
buildings.  The black triangles are NPCs and the yellow squares 
are slots for those NPCs to do something.  The two larger green
areas to the right are farms.  At the top, you'll see the 
current time of the simulation.

Keys:
    1 - 6: Change the simulation speed.
    Left-Click: Show info on NPC.
    Right-Click: Show info on building or slot.

Enjoy!

-Rez

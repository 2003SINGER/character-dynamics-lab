// utils.cpp
#include "utils.h"
#include "../constants.h"
#include <windows.h>

bool Vec2::IsExtremelyCloseTo(const Vec2& right) const
{
    Vec2 diff = right - (*this);
    if (diff.Length() < 0.01f)
        return true;
    return false;
}


float GetDeltaTime(void)
{
	static LARGE_INTEGER frequency;
	static double inverseFrequency = 0;
	static __int64 currentTime = 0L;

	LARGE_INTEGER now;
	if (currentTime == 0L)
	{
		QueryPerformanceFrequency(&frequency);
		inverseFrequency = 1.0f / ((double)frequency.QuadPart);
		QueryPerformanceCounter(&now);
		currentTime = (__int64)((double)now.QuadPart * inverseFrequency * 1000);
	}

	QueryPerformanceCounter(&now);

	__int64 newcurrentTime = (__int64)((double)now.QuadPart * inverseFrequency * 1000);
	float dt = 0.001f * (newcurrentTime - currentTime);
	if (dt < 1.0f / 60.0f) // clamp between 60hz and 30hz
		dt = 1.0f / 60.0f;
	else if (dt > 1.0f / 30.0f)
		dt = 1.0f / 30.0f;

	currentTime = newcurrentTime;
	return dt;
}


void Log(const char* msg)
{
    OutputDebugStringA(msg);
}

float RandomRange(float low, float high)
{
    float val = low + (float)rand() / ((float)RAND_MAX / (high - low));
    return val;
}


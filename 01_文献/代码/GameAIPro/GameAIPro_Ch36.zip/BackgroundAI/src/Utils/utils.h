// utils.h

#ifndef __UTILS_H__
#define __UTILS_H__

#include <math.h>

class Vec2;


//-----------------------------------------------------------------------------------------------------------------------
// Helper functions
//-----------------------------------------------------------------------------------------------------------------------
#define ROUND_TO_NEAREST(_VAL_) ((int)((_VAL_) + 0.5f))
float GetDeltaTime(void);
void Log(const char* msg);
float RandomRange(float low, float high);


//-----------------------------------------------------------------------------------------------------------------------
// Class for handling 2D vectors
//-----------------------------------------------------------------------------------------------------------------------
class Vec2
{
public:
	float x, y;
	
	// construction
	Vec2(void) { x = 0; y = 0; }
	Vec2(float _x, float _y) { x = _x; y = _y; }

	Vec2& operator=(const Vec2 &newVec) {x = newVec.x; y = newVec.y; return (*this);}
	Vec2& operator=(const Vec2 *newVec) {x = newVec->x; y = newVec->y; return (*this);}
    Vec2& operator*=(const Vec2& right) {x *= right.x; y *= right.y; return (*this); }
    Vec2& operator*=(const float right) {x *= right; y *= right; return (*this); }
    bool operator==(const Vec2& right) { return (x == right.x && y == right.y); }
    bool operator!=(const Vec2& right) { return (x != right.x || y != right.y); }
	
	float Length(void) const { return (sqrt(x*x + y*y)); }
	float LengthSqr(void) const { return (x*x + y*y); }
    void Normalize(void) { float len = Length(); x /= len; y /= len; }
    bool IsExtremelyCloseTo(const Vec2& right) const;
};

inline Vec2 operator+(const Vec2& left, const Vec2& right)
{
	return (Vec2(left.x+right.x, left.y+right.y));
}

inline Vec2 operator*(const Vec2& left, const float right)
{
	return (Vec2(left.x*right, left.y*right));
}

inline Vec2 operator-(const Vec2& left, const Vec2& right)
{
	return (Vec2(left.x-right.x, left.y-right.y));
}


//-----------------------------------------------------------------------------------------------------------------------
// Class for handling rectangles (used for quads and collision detection)
//-----------------------------------------------------------------------------------------------------------------------
class Rect
{
public:
	float left, top, right, bottom;

	//construction
	Rect(void) {left = top = right = bottom = 0;}
	Rect(float newLeft, float newTop, float newRight, float newBottom) {left = newLeft; top = newTop; right = newRight; bottom = newBottom;}
	Rect(const Rect& newRect) {left = newRect.left; top = newRect.top; right = newRect.right; bottom = newRect.bottom;}
	Rect(Rect* newRect) {left = newRect->left; top = newRect->top; right = newRect->right; bottom = newRect->bottom;}

	//assignment
	Rect& operator=(const Rect &newRect) {left = newRect.left; top = newRect.top; right = newRect.right; bottom = newRect.bottom; return (*this);}
	Rect& operator=(const Rect *newRect) {left = newRect->left; top = newRect->top; right = newRect->right; bottom = newRect->bottom; return (*this);}

	// addition/subtraction
	Rect& operator+=(const Rect &newRect) {left += newRect.left; top += newRect.top; right += newRect.right; bottom += newRect.bottom; return (*this);}
	Rect& operator-=(const Rect &newRect) {left -= newRect.left; top -= newRect.top; right -= newRect.right; bottom -= newRect.bottom; return (*this);}
	Rect& operator+=(const Rect *newRect) {left += newRect->left; top += newRect->top; right += newRect->right; bottom += newRect->bottom; return (*this);}
	Rect& operator-=(const Rect *newRect) {left -= newRect->left; top -= newRect->top; right -= newRect->right; bottom -= newRect->bottom; return (*this);}
	Rect operator+(Rect &other) {Rect temp(this); temp += other; return temp;}
	Rect operator-(Rect &other) {Rect temp(this); temp -= other; return temp;}

	// move a rectangle by an amount defined by a Point, keeping the rectanle's size constant
	Rect& operator+=(const Vec2 &delta) {left += delta.x; top += delta.y; right += delta.x; bottom += delta.y; return (*this);}
	Rect& operator-=(const Vec2 &delta) {left -= delta.x; top -= delta.y; right -= delta.x; bottom -= delta.y; return (*this);}
	Rect& operator+=(const Vec2 *delta) {left += delta->x; top += delta->y; right += delta->x; bottom += delta->y; return (*this);}
	Rect& operator-=(const Vec2 *delta) {left -= delta->x; top -= delta->y; right -= delta->x; bottom -= delta->y; return (*this);}
	Rect operator+(Vec2 &delta) {Rect temp(this); temp += delta; return temp;}
	Rect operator-(Vec2 &delta) {Rect temp(this); temp -= delta; return temp;}

	//comparison
	bool operator==(const Rect &other) const {return ((left == other.left) && (top == other.top) && (right == other.right) && (bottom == other.bottom));}
	bool operator!=(const Rect &other) const {return (!((left == other.left) && (top == other.top) && (right == other.right) && (bottom == other.bottom)));}

	// collision
	bool Collide(const Vec2& p) const
	{
		return ( p.x > left && p.x < right && ((p.y > bottom && p.y < top) || (p.y > top && p.y < bottom)) );
	}
};


//-----------------------------------------------------------------------------------------------------------------------
// Some Vec2 constants to make life easier
//-----------------------------------------------------------------------------------------------------------------------
const Vec2 VEC2_ZERO(0, 0);

const Vec2 VEC2_UNIT_X(1.0f, 0);
const Vec2 VEC2_UNIT_Y(0, 1.0f);
const Vec2 VEC2_UNIT(1.0f, 1.0f);

const Vec2 VEC2_NEGUNIT_X(-1.0f, 0);
const Vec2 VEC2_NEGUNIT_Y(0, -1.0f);
const Vec2 VEC2_NEGUNIT(-1.0f, -1.0f);


#endif

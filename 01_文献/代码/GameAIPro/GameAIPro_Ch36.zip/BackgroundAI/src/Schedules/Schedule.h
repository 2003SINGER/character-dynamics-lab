// Schedule.h
#ifndef __SCHEDULE_H__
#define __SCHEDULE_H__

#include "../constants.h"
#include "ScheduleEntry.h"
#include <vector>

class ScheduleEntry;
class ActionInstance;

class ScheduleDefinition
{
    typedef std::vector<ScheduleEntry*> ScheduleEntries;

    ScheduleId m_id;
    ScheduleEntries m_scheduleEntries;

public:
    // construction / destruction
    explicit ScheduleDefinition(const ScheduleId& id) : m_id(id) { }
    ~ScheduleDefinition(void);
    void AddEntry(ScheduleEntry* pEntry) { m_scheduleEntries.push_back(pEntry); }

    // schedule entries
    int FindEntryForTime(double currentTime) const;
    double GetEndTime(int entryIndex) const { return m_scheduleEntries[GetNextEntryIndex(entryIndex)]->GetStartTime(); }
    int GetNextEntryIndex(int currentEntryIndex) const;

    // actions
    ActionInstance* ChooseNewAction(int entryIndex, ActionInstance* pLastAction) const;

    // misc accessors
    const ScheduleId& GetId(void) const { return m_id; }
};

#endif

// ScheduleDatabase.h
#ifndef __SCHEDULEDATABASE_H__
#define __SCHEDULEDATABASE_H__

#include "../constants.h"
#include <map>

class TiXmlElement;
class ScheduleDefinition;
class ScheduleInstance;
class ScheduleEntry;
class ActionDefinition;

class ScheduleDatabase
{
    // schedule entry types
    const static std::string SIMPLE_SCHEDULE_ENTRY;
    const static std::string WEIGHTED_RANDOM_SCHEDULE_ENTRY;
    const static std::string SEQUENTIAL_SCHEDULE_ENTRY;

    typedef std::map<ScheduleId, ScheduleDefinition*> Schedules;
    typedef std::map<ScheduleEntryTemplateId, ScheduleEntry*> ScheduleEntryTemplates;
    typedef std::map<ActionId, ActionDefinition*> ActionDefinitions;

    Schedules m_schedules;
    ScheduleEntryTemplates m_scheduleEntryTemplates;
    ActionDefinitions m_actionDefinitions;

public:
    ~ScheduleDatabase(void);
    bool LoadSchedules(const char* scheduleDatabaseFilename);
    ScheduleInstance* CreateScheduleInstance(const ScheduleId& scheduleId);

private:
    void CreateActionDefinition(TiXmlElement* pActionDef);
    void CreateSchedule(TiXmlElement* pScheduleDef);
    ScheduleEntry* CreateScheduleEntry(TiXmlElement* pScheduleEntryDef);
    ScheduleEntry* ScheduleEntryFactory(const std::string& type, const ScheduleId& id, double startTime);  // should only be called from CreateScheduleEntry()
    ScheduleDefinition* FindSchedule(const ScheduleId& scheduleId);
};

#endif

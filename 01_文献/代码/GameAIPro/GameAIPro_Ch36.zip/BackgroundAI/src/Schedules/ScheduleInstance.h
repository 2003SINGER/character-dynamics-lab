// ScheduleInstance.h
#ifndef __SCHEDULEINSTANCE_H__
#define __SCHEDULEINSTANCE_H__

#include "../constants.h"

class ScheduleDefinition;
class ActionInstance;

class ScheduleInstance
{
    ScheduleDefinition* m_pScheduleData;
    int m_entryIndex;
    int m_actionIndex;

public:
    explicit ScheduleInstance(ScheduleDefinition* pSchedule);

    void ChooseEntryForTime(double currentTime);
    void MoveToNextEntry(void);
    ActionInstance* ChooseNewAction(ActionInstance* pLastAction);
    double GetEndTime(void) const;
    const ScheduleId& GetId(void) const;
};

#endif

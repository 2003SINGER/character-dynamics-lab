// ScheduleEntry.h
#ifndef __SCHEDULEENTRY_H__
#define __SCHEDULEENTRY_H__

#include "../constants.h"
#include <vector>

class ActionDefinition;
class ActionInstance;
class TiXmlElement;

class ScheduleEntry
{
protected:
    ScheduleEntryId m_id;
    double m_startTime;

public:
    explicit ScheduleEntry(const ScheduleEntryId& id, double startTime)
        : m_id(id), m_startTime(startTime)
    { }
    virtual ~ScheduleEntry(void) {}

    // interface
    virtual void AddAction(ActionDefinition* pActionDefinition, TiXmlElement* pActionElement) = 0;
    virtual ActionInstance* ChooseNewAction(ActionInstance* pLastAction) = 0;
    virtual ScheduleEntry* Clone(const ScheduleEntryId& id, double startTime) = 0;

    // accessors
    const ScheduleEntryId& GetId(void) const { return m_id; }
    double GetStartTime(void) const { return m_startTime; }
};


class SimpleScheduleEntry : public ScheduleEntry
{
    ActionDefinition* m_pAction;

public:
    explicit SimpleScheduleEntry(const ScheduleEntryId& id, double startTime)
        : ScheduleEntry(id, startTime), m_pAction(NULL)
    { }

    virtual void AddAction(ActionDefinition* pActionDefinition, TiXmlElement* pActionElement);
    virtual ActionInstance* ChooseNewAction(ActionInstance* pLastAction);
    virtual ScheduleEntry* Clone(const ScheduleEntryId& id, double startTime);
};


class WeightedRandomScheduleEntry : public ScheduleEntry
{
    typedef std::vector<ActionDefinition*> Actions;
    typedef std::vector<unsigned int> ActionWeights;

    Actions m_actions;
    ActionWeights m_actionWeights;
    unsigned int m_maxWeight;

public:
    explicit WeightedRandomScheduleEntry(const ScheduleEntryId& id, double startTime)
        : ScheduleEntry(id, startTime), m_maxWeight(0)
    { }

    virtual void AddAction(ActionDefinition* pActionDefinition, TiXmlElement* pActionElement);
    virtual ActionInstance* ChooseNewAction(ActionInstance* pLastAction);
    virtual ScheduleEntry* Clone(const ScheduleEntryId& id, double startTime);
};


class SquentialScheduleEntry : public ScheduleEntry
{
    typedef std::vector<ActionDefinition*> Actions;

    Actions m_actions;

public:
    explicit SquentialScheduleEntry(const ScheduleEntryId& id, double startTime)
        : ScheduleEntry(id, startTime)
    { }

    virtual void AddAction(ActionDefinition* pActionDefinition, TiXmlElement* pActionElement);
    virtual ActionInstance* ChooseNewAction(ActionInstance* pLastAction);
    virtual ScheduleEntry* Clone(const ScheduleEntryId& id, double startTime);
};


#endif

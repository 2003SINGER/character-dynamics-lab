// ScheduleEntry.cpp
#include "ScheduleEntry.h"
#include "../Actions/ActionDefinition.h"
#include "../Actions/ActionInstance.h"
#include "../tinyxml/tinyxml.h"
#include <assert.h>


//---------------------------------------------------------------------------------------------------------------------
// SimpleScheduleEntry
//---------------------------------------------------------------------------------------------------------------------
void SimpleScheduleEntry::AddAction(ActionDefinition* pActionDefinition, TiXmlElement* pActionElement)
{
    assert(m_pAction == NULL);
    m_pAction = pActionDefinition;
}

ActionInstance* SimpleScheduleEntry::ChooseNewAction(ActionInstance* pLastAction)
{
    return m_pAction->CreateActionInstance();
}

ScheduleEntry* SimpleScheduleEntry::Clone(const ScheduleEntryId& id, double startTime)
{
    SimpleScheduleEntry* pEntry = new SimpleScheduleEntry(id, startTime);
    pEntry->m_pAction = m_pAction;
    return pEntry;
}


//---------------------------------------------------------------------------------------------------------------------
// WeightedRandomScheduleEntry
//---------------------------------------------------------------------------------------------------------------------
void WeightedRandomScheduleEntry::AddAction(ActionDefinition* pActionDefinition, TiXmlElement* pActionElement)
{
    // read the weight from the action XML def
    double weight = 1;  // 0 might be a better default
    pActionElement->Attribute("weight", &weight);
    unsigned int trueWeight = (unsigned int)weight;

    // add the action definition and weight
    m_actions.push_back(pActionDefinition);
    m_actionWeights.push_back(trueWeight + m_maxWeight);
    assert(m_actionWeights.size() == m_actionWeights.size());

    m_maxWeight += trueWeight;
}

ActionInstance* WeightedRandomScheduleEntry::ChooseNewAction(ActionInstance* pLastAction)
{
    // make the choice
    unsigned int choice = rand() % m_maxWeight;
    size_t totalActions = m_actions.size();
    unsigned int index = totalActions - 1;  // if the loop completes without finding an entry, the last entry is correct
    for (index = 0; index < totalActions; ++index)
    {
        if (choice < m_actionWeights[index])
            break;
    }

    ActionInstance* pActionInst = m_actions[index]->CreateActionInstance();
    return pActionInst;
}

ScheduleEntry* WeightedRandomScheduleEntry::Clone(const ScheduleEntryId& id, double startTime)
{
    WeightedRandomScheduleEntry* pEntry = new WeightedRandomScheduleEntry(id, startTime);

    assert(m_actions.size() == m_actionWeights.size());
    size_t numElements = m_actions.size();
    pEntry->m_actions.reserve(numElements);
    pEntry->m_actionWeights.reserve(numElements);

    for (unsigned int i = 0; i < numElements; ++i)
    {
        pEntry->m_actions.push_back(m_actions[i]);
        pEntry->m_actionWeights.push_back(m_actionWeights[i]);
    }

    pEntry->m_maxWeight = m_maxWeight;

    return pEntry;
}


//---------------------------------------------------------------------------------------------------------------------
// SquentialScheduleEntry
//---------------------------------------------------------------------------------------------------------------------
void SquentialScheduleEntry::AddAction(ActionDefinition* pActionDefinition, TiXmlElement* pActionElement)
{
    m_actions.push_back(pActionDefinition);
}

ActionInstance* SquentialScheduleEntry::ChooseNewAction(ActionInstance* pLastAction)
{
    unsigned int nextActionIndex = 0;

    if (pLastAction)
    {
        nextActionIndex = pLastAction->GetIndex() + 1;
        if (nextActionIndex >= m_actions.size())
            nextActionIndex = 0;
    }

    return m_actions[nextActionIndex]->CreateActionInstance(nextActionIndex);
}

ScheduleEntry* SquentialScheduleEntry::Clone(const ScheduleEntryId& id, double startTime)
{
    SquentialScheduleEntry* pEntry = new SquentialScheduleEntry(id, startTime);

    size_t numElements = m_actions.size();
    pEntry->m_actions.reserve(numElements);

    for (unsigned int i = 0; i < numElements; ++i)
    {
        pEntry->m_actions.push_back(m_actions[i]);
    }

    return pEntry;
}

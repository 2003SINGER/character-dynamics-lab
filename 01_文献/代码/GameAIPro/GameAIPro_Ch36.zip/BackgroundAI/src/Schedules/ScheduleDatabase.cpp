// ScheduleDatabase.cpp
#include "ScheduleDatabase.h"
#include "Schedule.h"
#include "ScheduleInstance.h"
#include "ScheduleEntry.h"
#include "../Actions/ActionDefinition.h"
#include "../tinyxml/tinyxml.h"
#include <assert.h>

const std::string ScheduleDatabase::SIMPLE_SCHEDULE_ENTRY("Simple");
const std::string ScheduleDatabase::WEIGHTED_RANDOM_SCHEDULE_ENTRY("WeightedRandom");
const std::string ScheduleDatabase::SEQUENTIAL_SCHEDULE_ENTRY("Sequential");

ScheduleDatabase::~ScheduleDatabase(void)
{
    for (auto it = m_actionDefinitions.begin(); it != m_actionDefinitions.end(); ++it)
    {
        delete it->second;
    }
    m_actionDefinitions.clear();

    for (auto it = m_scheduleEntryTemplates.begin(); it != m_scheduleEntryTemplates.end(); ++it)
    {
        delete it->second;
    }
    m_scheduleEntryTemplates.clear();

    for (auto it = m_schedules.begin(); it != m_schedules.end(); ++it)
    {
        delete it->second;
    }
    m_schedules.clear();
}

bool ScheduleDatabase::LoadSchedules(const char* scheduleDatabaseFilename)
{
    TiXmlDocument scheduleFile(scheduleDatabaseFilename);
    if (!scheduleFile.LoadFile())
    {
        assert(0&&"Failed to load objects.xml");
        return false;
    }

    TiXmlElement* pRoot = scheduleFile.RootElement();
    if (!pRoot)
    {
        assert(0&&"Failed to load root node from objects.xml");
        return false;
    }

    // load all actions
    TiXmlElement* pActionsElement = pRoot->FirstChildElement("Actions");
    if (pActionsElement)
    {
        for (TiXmlElement* pActionDef = pActionsElement->FirstChildElement(); pActionDef != NULL; pActionDef = pActionDef->NextSiblingElement())
        {
            CreateActionDefinition(pActionDef);
        }
    }

    // load all schedule entry templates
    TiXmlElement* pScheduleEntryTemplates = pRoot->FirstChildElement("ScheduleEntryTemplates");
    if (pScheduleEntryTemplates)
    {
        for (TiXmlElement* pScheduleEntryTemplateDef = pScheduleEntryTemplates->FirstChildElement(); pScheduleEntryTemplateDef != NULL; pScheduleEntryTemplateDef = pScheduleEntryTemplateDef->NextSiblingElement())
        {
            ScheduleEntry* pScheduleEntry = CreateScheduleEntry(pScheduleEntryTemplateDef);
            if (pScheduleEntry)
                m_scheduleEntryTemplates.insert(std::make_pair(pScheduleEntry->GetId(), pScheduleEntry));
        }
    }

    // load all schedules
    TiXmlElement* pSchedulesElement = pRoot->FirstChildElement("Schedules");
    if (pSchedulesElement)
    {
        for (TiXmlElement* pScheduleDef = pSchedulesElement->FirstChildElement(); pScheduleDef != NULL; pScheduleDef = pScheduleDef->NextSiblingElement())
        {
            CreateSchedule(pScheduleDef);
        }
    }

    return true;
}

ScheduleInstance* ScheduleDatabase::CreateScheduleInstance(const ScheduleId& scheduleId)
{
    ScheduleDefinition* pSchedule = FindSchedule(scheduleId);
    if (pSchedule)
    {
        ScheduleInstance* pScheduleInstance = new ScheduleInstance(pSchedule);
        return pScheduleInstance;
    }

    return NULL;
}

void ScheduleDatabase::CreateActionDefinition(TiXmlElement* pActionDefElement)
{
    // read the XML values
    const char* pActionId = pActionDefElement->Attribute("name");
    const char* pTargetType = pActionDefElement->Attribute("target");
    double minDuration = FLT_MAX;
    pActionDefElement->Attribute("minDuration", &minDuration);
    double maxDuration = FLT_MAX;
    pActionDefElement->Attribute("maxDuration", &maxDuration);

    // create a action definition
    ActionDefinition* pActionDef = new ActionDefinition(pActionId, pTargetType, (float)minDuration, (float)maxDuration);
    m_actionDefinitions.insert(std::make_pair(pActionDef->GetId(), pActionDef));
}

ScheduleEntry* ScheduleDatabase::CreateScheduleEntry(TiXmlElement* pScheduleEntryDef)
{
    // read the attributes for the entry
    const char* pEntryId = pScheduleEntryDef->Attribute("name");
    const char* pEntryType = pScheduleEntryDef->Attribute("type");
    const char* pEntryTemplate = pScheduleEntryDef->Attribute("template");
    double startTime = -1;
    pScheduleEntryDef->Attribute("startTime", &startTime);

    ScheduleEntry* pEntry = NULL;

    // attempt to create the schedule entry by cloning the template, if there is one
    if (pEntryTemplate)
    {
        auto findIt = m_scheduleEntryTemplates.find(pEntryTemplate);
        if (findIt != m_scheduleEntryTemplates.end())
            pEntry = findIt->second->Clone(pEntryId, startTime);
        else
            printf("[WARNING] Couldn't find template %s\n", pEntryTemplate);
    }

    // no template, so create from scratch
    if (!pEntry)
    {
        pEntry = ScheduleEntryFactory(pEntryType, pEntryId, startTime);

        // load all the actions
        for (TiXmlElement* pActionElement = pScheduleEntryDef->FirstChildElement(); pActionElement != NULL; pActionElement = pActionElement->NextSiblingElement())
        {
            const char* pActionType = pActionElement->Attribute("type");
            auto findIt = m_actionDefinitions.find(pActionType);
            if (findIt != m_actionDefinitions.end())
                pEntry->AddAction(findIt->second, pActionElement);
            else
                printf("[WARNING] Failed to load action of type %s\n", pActionType);
        }
    }

    return pEntry;
}

void ScheduleDatabase::CreateSchedule(TiXmlElement* pScheduleDef)
{
    // id & instantiation
    const char* pScheduleId = pScheduleDef->Attribute("name");
    if (!pScheduleId)
        return;
    ScheduleDefinition* pSchedule = new ScheduleDefinition(pScheduleId);

    // for each schedule entry
    for (TiXmlElement* pScheduleElement = pScheduleDef->FirstChildElement(); pScheduleElement != NULL; pScheduleElement = pScheduleElement->NextSiblingElement())
    {
        ScheduleEntry* pEntry = CreateScheduleEntry(pScheduleElement);
        pSchedule->AddEntry(pEntry);
    }

    // add the new schedule to the map
    m_schedules.insert(std::make_pair(pSchedule->GetId(), pSchedule));
}

ScheduleEntry* ScheduleDatabase::ScheduleEntryFactory(const std::string& type, const ScheduleId& id, double startTime)
{
    if (type == SIMPLE_SCHEDULE_ENTRY)
        return new SimpleScheduleEntry(id, startTime);
    else if (type == WEIGHTED_RANDOM_SCHEDULE_ENTRY)
        return new WeightedRandomScheduleEntry(id, startTime);
    else if (type == SEQUENTIAL_SCHEDULE_ENTRY)
        return new SquentialScheduleEntry(id, startTime);
    else
    {
        printf("[WARNING] Unknown Schedule type %s for schedule %s\n", type.c_str(), id.c_str());
        return NULL;
    }
}

ScheduleDefinition* ScheduleDatabase::FindSchedule(const ScheduleId& scheduleId)
{
    auto findIt = m_schedules.find(scheduleId);
    if (findIt != m_schedules.end())
        return findIt->second;
    else
        return NULL;
}

// Schedule.cpp
#include "Schedule.h"
#include <assert.h>

ScheduleDefinition::~ScheduleDefinition(void)
{
    for (auto it = m_scheduleEntries.begin(); it != m_scheduleEntries.end(); ++it)
    {
        delete (*it);
    }
    m_scheduleEntries.clear();
}

int ScheduleDefinition::FindEntryForTime(double currentTime) const
{
    // if there's only a single entry, the choice is easy
    if (m_scheduleEntries.size() == 1)
        return 0;

    for (unsigned int i = 0; i < m_scheduleEntries.size(); ++i)
    {
        double startTime = m_scheduleEntries[i]->GetStartTime();
        double endTime = GetEndTime(i);

        // end time doesn't wrap
        if (endTime >= startTime)
        {
            if (currentTime >= startTime && currentTime < endTime)
                return i;
        }
        else  // end time wraps to beginning; for example, startTime might be 22 (10pm) and endTime might be 7 (7am)
        {
            if (currentTime >= startTime || currentTime < endTime)
                return i;
        }
    }

    // If we get here, the schedule doesn't cover this time frame.  This should never happen since each entry only 
    // specifies a start time.  Holes in the schedule should be impossible.
    assert(0&&"Found an impossible hole in the schedule!");
    return 0;  // return something valid since the caller expects a valid result
}

int ScheduleDefinition::GetNextEntryIndex(int currentEntry) const
{
    ++currentEntry;
    if ((unsigned int)currentEntry >= m_scheduleEntries.size())
        currentEntry = 0;
    return currentEntry;
}

ActionInstance* ScheduleDefinition::ChooseNewAction(int entryIndex, ActionInstance* pLastAction) const
{
    return m_scheduleEntries[entryIndex]->ChooseNewAction(pLastAction);
}

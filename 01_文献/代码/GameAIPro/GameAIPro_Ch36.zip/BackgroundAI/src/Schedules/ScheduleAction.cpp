// ScheduleAction.cpp
#include "ScheduleAction.h"
#include "../Utils/utils.h"

ScheduleAction::ScheduleAction(void)
{
    m_minDuration = FLT_MAX;
    m_maxDuration = FLT_MAX;
}


float ScheduleAction::CalculateDuration(void) const
{
    float duration = RandomRange(m_minDuration, m_maxDuration);
    return duration;
}


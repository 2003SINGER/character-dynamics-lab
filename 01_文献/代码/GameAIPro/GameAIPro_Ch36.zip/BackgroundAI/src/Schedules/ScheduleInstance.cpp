// ScheduleInstance.cpp
#include "ScheduleInstance.h"
#include "Schedule.h"


ScheduleInstance::ScheduleInstance(ScheduleDefinition* pSchedule)
    : m_pScheduleData(pSchedule)
    , m_entryIndex(-1)
    , m_actionIndex(-1)
{ }

void ScheduleInstance::ChooseEntryForTime(double currentTime)
{
    m_entryIndex = m_pScheduleData->FindEntryForTime(currentTime);
}

void ScheduleInstance::MoveToNextEntry(void)
{
    m_entryIndex = m_pScheduleData->GetNextEntryIndex(m_entryIndex);
}

ActionInstance* ScheduleInstance::ChooseNewAction(ActionInstance* pLastAction)
{
    return m_pScheduleData->ChooseNewAction(m_entryIndex, pLastAction);
}
 
double ScheduleInstance::GetEndTime(void) const
{
    return m_pScheduleData->GetEndTime(m_entryIndex);
}

const ScheduleId& ScheduleInstance::GetId(void) const
{
    return m_pScheduleData->GetId();
}


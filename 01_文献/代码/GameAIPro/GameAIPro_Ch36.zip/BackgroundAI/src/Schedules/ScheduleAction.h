// ScheduleAction.h
#ifndef __SCHEDULEACTION_H__
#define __SCHEDULEACTION_H__

#include "../constants.h"

class ScheduleAction
{
protected:
    ObjectType m_target;
    float m_minDuration;
    float m_maxDuration;

public:
    ScheduleAction(void);
    const ObjectType& GetTarget(void) const { return m_target; }
    float CalculateDuration(void) const;
};


#endif

// GLShell.cpp : Defines the entry point for the console application.
#include "Game.h"
#include "../constants.h"
#include "../Utils/utils.h"
#include "../glut/glut.h"
#include "../glut/freeglut_ext.h"
#include "../tinyxml/tinyxml.h"

#include <list>
#include <assert.h>
#include <time.h>


Game* g_pGame = NULL;


void InitializeGame(void)
{
	assert(g_pGame == NULL);
	g_pGame = new Game();
	g_pGame->Init();
}

void DestroyGame(void)
{
    if (g_pGame)
    {
	    delete g_pGame;
	    g_pGame = NULL;
    }
}

void ExitCallback(void)
{
    DestroyGame();
}

void KeyboardCallback(unsigned char key, int x, int y)
{
	g_pGame->ProcessKeyboardInput(key);
}

void MouseCallback(int button, int state, int x, int y)
{
    g_pGame->ProcessMouseInput(button, state, x, y);
}

void DisplayCallback(void)
{
	g_pGame->RenderTick();
}

void IdleCallback(void)
{
	// check to see if we're quitting
	if (g_pGame->IsQuitting())
	{
		DestroyGame();
		exit(0);
	}

	// render the scene
	glPushMatrix();
	DisplayCallback();
	glPopMatrix();

	// tell the game to run its logic tick
	g_pGame->LogicTick(GetDeltaTime());
}

int main(int argc, char *argv[])
{
	srand((unsigned int)time(NULL));
    atexit(&ExitCallback);

    glutInit(&argc, argv);
    glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    glutInitDisplayMode(GLUT_STENCIL|GLUT_DEPTH|GLUT_DOUBLE);
    (void)glutCreateWindow("Background AI - AI Game Programming Wisdom 5 - David \"Rez\" Graham");

    glutDisplayFunc(&DisplayCallback);
    glutKeyboardFunc(&KeyboardCallback);
    glutMouseFunc(&MouseCallback);
    glutIdleFunc(&IdleCallback);

    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glOrtho(ORTHO_LEFT, ORTHO_RIGHT, ORTHO_BOTTOM, ORTHO_TOP, ORTHO_NEAR, ORTHO_FAR);
    glMatrixMode(GL_MODELVIEW);

    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glEnable(GL_COLOR_MATERIAL);

	InitializeGame();
    glutMainLoop();

    // This ends up getting called if you close the main window
    DestroyGame();

	return 0;
}


// Game.h
#ifndef __GAME_H__
#define __GAME_H__

#include "../Objects/GameObject.h"
#include "../Objects/NPC.h"
#include <map>
#include <vector>

class TiXmlElement;
class ScheduleDatabase;

class Game
{
    typedef std::map<ObjectId, GameObject*> ObjectMap;
    typedef std::map<ObjectId, Npc*> NpcList;
    typedef std::vector<GameObject*> GameObjectList;
    typedef std::map<ObjectType, GameObjectList> ObjectMapByType;

    // constants
    const static double SIMULATION_START_TIME;
    const static float SELECTION_RADIUS;
    const static unsigned int SELECTION_COLOR;

    // flag for quitting
    bool m_quitting;

    // object lists
    ObjectMap m_masterObjectList;
    ObjectMapByType m_objectsByType;
    NpcList m_npcs;
    GameObject* m_pSelectedObject;

    // schedules
    ScheduleDatabase* m_pScheduleDatabase;

    // timing
    double m_lastTime, m_currentTime;
    int m_timeCompression;

public:
	Game(void);
	~Game(void);
	void Init(void);

	void LogicTick(float deltaTime);
	void RenderTick(void);
	void ProcessKeyboardInput(unsigned char key);
    void ProcessMouseInput(int button, int state, int x, int y);

	// accessors
	bool IsQuitting(void) const { return m_quitting; }
    ScheduleDatabase* GetScheduleDatabase(void) const { return m_pScheduleDatabase; }

    // game object functions
    GameObject* FindObject(const ObjectId& objectId);
    GameObject* FindRandomObject(const ObjectType& objectType);

    // time functions
    double GetLastTime(void) const { return m_lastTime; }
    double GetCurrTime(void) const { return m_currentTime; }

private:
    // world loading
    bool LoadWorld(const char* worldFilename);
    void CreateBuilding(TiXmlElement* pBuildingDef);

    // object loading
    bool LoadObjects(const char* objectFilename);
    void CreateInteractableGameObject(TiXmlElement* pGameObjectDef);
    void CreateNpc(TiXmlElement* pNpcDef);

    // schedules
    bool LoadSchedules(const char* scheduleDatabaseFilename);

    // Logic updates
    void UpdateTime(float deltaTime);
    void UpdateNpcs(float deltaTime);

    // misc gameplay helpers
    void ConvertMousePosToWorldPos(Vec2& pos);
    void GetRandomPosition(Vec2& outRandomPosition);
    bool AddToMasterList(GameObject* pGameObject);
    GameObject* FindClosestNonNpc(const Vec2& point);
    Npc* FindClosestNpc(const Vec2& point);
    void SelectObject(GameObject* pGameObject);

    // render helpers
    void DrawArena(void);
    void DrawGameObjects(void);

    // HUD
    void DrawHud(void);
    void DrawSelectedObjectInfo(void);
    void DrawTime(void);

    // debug functions
    void StopAllNpcs(void);
    void SendAllNpcsToObject(const ObjectType& objectType);
};

#endif

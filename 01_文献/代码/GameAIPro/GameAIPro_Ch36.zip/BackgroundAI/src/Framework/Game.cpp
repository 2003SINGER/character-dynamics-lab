// Game.cpp
#include "Game.h"
#include "../Objects/InteractableGameObject.h"
#include "../Schedules/ScheduleDatabase.h"
#include "../constants.h"
#include "../glut/glut.h"
#include "../glut/freeglut_ext.h"
#include "../tinyxml/tinyxml.h"
#include <windows.h>  // for VK_ESCAPE  :(

const double Game::SIMULATION_START_TIME = 8.f;  // 8am
const float Game::SELECTION_RADIUS = 0.5f;
const unsigned int Game::SELECTION_COLOR = 0xffff00ff;  // fuchsia


Game::Game(void)
    : m_quitting(false)
    , m_pSelectedObject(NULL)
    , m_pScheduleDatabase(NULL)
    , m_currentTime(SIMULATION_START_TIME)
    , m_lastTime(m_currentTime)
    , m_timeCompression(1)
{ }

Game::~Game(void)
{
    // destroy all objects
	for (auto it = m_masterObjectList.begin(); it != m_masterObjectList.end(); ++it)
	{
		delete it->second;
	}

    // clear all maps, just to be safe
    m_masterObjectList.clear();
    m_npcs.clear();

    // destroy the schedule database
    delete m_pScheduleDatabase;
    m_pScheduleDatabase = NULL;
}

void Game::Init(void)
{
    LoadWorld("data/World.xml");
    LoadSchedules("data/Schedules.xml");
    LoadObjects("data/Objects.xml");
}

void Game::LogicTick(float deltaTime)
{
    float logicTime = deltaTime * m_timeCompression;
    UpdateTime(logicTime);
    UpdateNpcs(logicTime);
}

void Game::RenderTick(void)
{
	// clear stencil each time
	glClearColor(0.5f, 0.1f, 0.1f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);

	// draw all objects
	DrawArena();
	DrawGameObjects();
    DrawHud();

	// present the screen by swapping primary & back buffers
	glutSwapBuffers();
}

void Game::ProcessKeyboardInput(unsigned char key)
{
	switch (key)
	{
        // System controls
    	case VK_ESCAPE : m_quitting = true; break;

        // Time controls
        case '`': m_timeCompression = 0; break;
        case '1': m_timeCompression = 1; break;
        case '2': m_timeCompression = 2; break;
        case '3': m_timeCompression = 5; break;
        case '4': m_timeCompression = 10; break;
        case '5': m_timeCompression = 20; break;
        case '6': m_timeCompression = 50; break;
	}
}

void Game::ProcessMouseInput(int button, int state, int x, int y)
{
    if (state)
    {
        switch (button)
        {
            case GLUT_LEFT_BUTTON :
            {
                Vec2 pos((float)x, (float)y);
                ConvertMousePosToWorldPos(pos);
                GameObject* pGameObject = FindClosestNpc(pos);
                SelectObject(pGameObject);
                break;
            }

            case GLUT_RIGHT_BUTTON :
            {
                Vec2 pos((float)x, (float)y);
                ConvertMousePosToWorldPos(pos);
                //pos *= GLOBAL_SCALE;
                GameObject* pGameObject = FindClosestNonNpc(pos);
                SelectObject(pGameObject);
                break;
            }
        }
    }
}

GameObject* Game::FindObject(const ObjectId& objectId)
{
    auto findIt = m_masterObjectList.find(objectId);
    if (findIt != m_masterObjectList.end())
        return findIt->second;
    else
        return NULL;
}

GameObject* Game::FindRandomObject(const ObjectType& objectType)
{
    auto findIt = m_objectsByType.find(objectType);
    if (findIt != m_objectsByType.end())
    {
        GameObjectList& objList = findIt->second;
        int objIndex = rand() % objList.size();
        return objList[objIndex];
    }

    return NULL;  // no valid objects of this type
}

bool Game::LoadWorld(const char* worldFilename)
{
    TiXmlDocument worldFile(worldFilename);
    if (!worldFile.LoadFile())
    {
        assert(0&&"Failed to load world.xml");
        return false;
    }
    
    TiXmlElement* pRoot = worldFile.RootElement();
    if (!pRoot)
    {
        assert(0&&"Failed to load root node from world.xml");
        return false;
    }

    // load all builds
    TiXmlElement* pBuildingsElement = pRoot->FirstChildElement("Buildings");
    if (pBuildingsElement)
    {
        for (TiXmlElement* pBuildingDef = pBuildingsElement->FirstChildElement(); pBuildingDef != NULL; pBuildingDef = pBuildingDef->NextSiblingElement())
        {
            CreateBuilding(pBuildingDef);
        }
    }

    return true;
}

void Game::CreateBuilding(TiXmlElement* pBuildingDef)
{
    // create and initialize the building
    GameObject* pNewBuilding = new GameObject;
    if (pNewBuilding->Init(pBuildingDef))
        AddToMasterList(pNewBuilding);
}

bool Game::LoadObjects(const char* objectFilename)
{
    TiXmlDocument objectsFile(objectFilename);
    if (!objectsFile.LoadFile())
    {
        assert(0&&"Failed to load objects.xml");
        return false;
    }

    TiXmlElement* pRoot = objectsFile.RootElement();
    if (!pRoot)
    {
        assert(0&&"Failed to load root node from objects.xml");
        return false;
    }

    // load all game objects
    TiXmlElement* pGameObjectsElement = pRoot->FirstChildElement("GameObjects");
    if (pGameObjectsElement)
    {
        for (TiXmlElement* pGameObjectDef = pGameObjectsElement->FirstChildElement(); pGameObjectDef != NULL; pGameObjectDef = pGameObjectDef->NextSiblingElement())
        {
            CreateInteractableGameObject(pGameObjectDef);
        }
    }

    // load all Npcs
    TiXmlElement* pNpcsElement = pRoot->FirstChildElement("Npcs");
    if (pNpcsElement)
    {
        for (TiXmlElement* pNpcDef = pNpcsElement->FirstChildElement(); pNpcDef != NULL; pNpcDef = pNpcDef->NextSiblingElement())
        {
            CreateNpc(pNpcDef);
        }
    }

    return true;
}

void Game::CreateInteractableGameObject(TiXmlElement* pGameObjectDef)
{
    // create the GameObject
    GameObject* pGameObject = new InteractableGameObject;
    if (pGameObject->Init(pGameObjectDef))
    {
        // add the GmaeObject to the master list
        AddToMasterList(pGameObject);

        // add to the object type map if this object has a type
        if (pGameObject->GetType() != INVALID_OBJECT_ID)
        {
            GameObjectList& objList = m_objectsByType[pGameObject->GetType()];
            objList.push_back(pGameObject);
        }
    }
}

void Game::CreateNpc(TiXmlElement* pNpcDef)
{
    // create the NPC
    Npc* pNpc = new Npc;
    if (pNpc->Init(pNpcDef))
    {
        // add the NPC to the master list and the NPC list
        AddToMasterList(pNpc);
        m_npcs.insert(std::make_pair(pNpc->GetId(), pNpc));
    }
}

bool Game::LoadSchedules(const char* scheduleDatabaseFilename)
{
    m_pScheduleDatabase = new ScheduleDatabase;
    if (!m_pScheduleDatabase->LoadSchedules(scheduleDatabaseFilename))
    {
        delete m_pScheduleDatabase;
        m_pScheduleDatabase = NULL;
        return false;
    }
    return true;
}

void Game::UpdateTime(float deltaTime)
{
    // update the current time
    m_lastTime = m_currentTime;
    m_currentTime += deltaTime / 60.0;  // 1 simulation hour == 1 real minute at normal speed
    if (m_currentTime >= 24.f)
        m_currentTime = fmod(m_currentTime, 24.0);
}

void Game::UpdateNpcs(float deltaTime)
{
    for (auto it = m_npcs.begin(); it != m_npcs.end(); ++it)
    {
        it->second->Update(deltaTime);
    }
}

void Game::ConvertMousePosToWorldPos(Vec2& pos)
{
    double x = pos.x / WINDOW_WIDTH * 2 * ORTHO_RIGHT - ORTHO_RIGHT;
    double y = pos.y / WINDOW_HEIGHT * 2 * ORTHO_BOTTOM - ORTHO_BOTTOM;
    pos.x = (float)x;
    pos.y = (float)y;
}

void Game::GetRandomPosition(Vec2& outRandomPosition)
{
    outRandomPosition.x = (float)((rand() % (int)(END_HOR_OFFSET - START_HOR_OFFSET)) + START_HOR_OFFSET);
    outRandomPosition.y = (float)((rand() % (int)(END_VER_OFFSET - START_VER_OFFSET)) + START_VER_OFFSET);
}

bool Game::AddToMasterList(GameObject* pGameObject)
{
    assert(pGameObject);

    // Check to see if the object already exists.  If so, remove the old object so we can overwrite it.
    auto findIt = m_masterObjectList.find(pGameObject->GetId());
    if (findIt != m_masterObjectList.end())
    {
        assert(0&&"Found GameObject with the same name.  Destroying old object and overwriting.");
        delete findIt->second;
        m_masterObjectList.erase(findIt);
    }

    m_masterObjectList.insert(std::make_pair(pGameObject->GetId(), pGameObject));
    return true;
}

GameObject* Game::FindClosestNonNpc(const Vec2& point)
{
    GameObject* pClosestObject = NULL;
    float shortestDistance = FLT_MAX;

    for (auto it = m_masterObjectList.begin(); it != m_masterObjectList.end(); ++it)
    {
        GameObject* pCandidate = it->second;
        if (pCandidate->GetType() == Npc::NPC_TYPE)
            continue;

        Vec2 candidatePos;
        pCandidate->GetCenter(candidatePos);
        Vec2 delta = candidatePos - point;
        float distance = delta.Length();

        if (distance < SELECTION_RADIUS)
        {
            if (distance < shortestDistance)
            {
                pClosestObject = pCandidate;
                shortestDistance = distance;
            }
        }
    }

    return pClosestObject;
}

Npc* Game::FindClosestNpc(const Vec2& point)
{
    Npc* pClosestObject = NULL;
    float shortestDistance = FLT_MAX;

    for (auto it = m_npcs.begin(); it != m_npcs.end(); ++it)
    {
        Npc* pCandidate = it->second;
        Vec2 candidatePos;
        pCandidate->GetCenter(candidatePos);
        Vec2 delta = candidatePos - point;
        float distance = delta.Length();

        if (distance < SELECTION_RADIUS)
        {
            if (distance < shortestDistance)
            {
                pClosestObject = pCandidate;
                shortestDistance = distance;
            }
        }
    }

    return pClosestObject;
}

void Game::SelectObject(GameObject* pGameObject)
{
    // reset the old object
    if (m_pSelectedObject)
        m_pSelectedObject->ResetColor();

    // set the new object (or NULL if this is a de-selection)
    m_pSelectedObject = pGameObject;

    // if we have a validly selected object, set its color
    if (m_pSelectedObject)
        m_pSelectedObject->SetColor(SELECTION_COLOR);
}

void Game::DrawArena(void)
{
    // draw background quad
    glBegin(GL_QUADS);
    glColor4ub(255, 255, 255, 255);
    glVertex3f(START_HOR_OFFSET, START_VER_OFFSET,  ARENA_Z);
    glVertex3f(END_HOR_OFFSET, START_VER_OFFSET,  ARENA_Z);
    glVertex3f(END_HOR_OFFSET, END_VER_OFFSET,  ARENA_Z);
    glVertex3f(START_HOR_OFFSET, END_VER_OFFSET,  ARENA_Z);
    glEnd();

    // draw a grid to provide a sense of scale
    glBegin(GL_LINES);
    glColor4ub(0, 255, 0, 255);
    for (int i = 0; i <= NUM_INTERVALS; ++i)
    {
        glVertex3f(START_HOR_OFFSET, INTERVAL*i + START_VER_OFFSET,  GRID_Z);
        glVertex3f(END_HOR_OFFSET, INTERVAL*i + START_VER_OFFSET,  GRID_Z);
        glVertex3f(INTERVAL*i + START_HOR_OFFSET, START_VER_OFFSET, GRID_Z);
        glVertex3f(INTERVAL*i + START_HOR_OFFSET, END_VER_OFFSET, GRID_Z);
    }
    glEnd();
}

void Game::DrawGameObjects(void)
{
    for (auto it = m_masterObjectList.begin(); it != m_masterObjectList.end(); ++it)
    {
        it->second->Draw();
    }
}

void Game::DrawHud(void)
{
    DrawTime();
    DrawSelectedObjectInfo();
}

void Game::DrawSelectedObjectInfo(void)
{
    const static size_t BUFFER_LENGTH = 256;

    if (m_pSelectedObject)
    {
        unsigned char buffer[BUFFER_LENGTH];
        memset(buffer, 0, BUFFER_LENGTH);

        m_pSelectedObject->GetDebugString(buffer, BUFFER_LENGTH);

        // render the string
        glColor3f(0.0f, 0.0f, 0.0f);
        glRasterPos2i(-9, 9);
        glutBitmapString(GLUT_BITMAP_TIMES_ROMAN_24, buffer);
    }
}

void Game::DrawTime(void)
{
    // get the current time as a string
    unsigned int hours = (unsigned int)m_currentTime;
    unsigned int minutes = ROUND_TO_NEAREST(60 * (m_currentTime - hours));

    // convert to a string
    const static size_t TIME_STRING_LENGTH = 12;
    unsigned char timeString[TIME_STRING_LENGTH];
    memset(timeString, 0, TIME_STRING_LENGTH);
    if (minutes < 10)
        sprintf_s((char*)timeString, TIME_STRING_LENGTH, "%u:0%u (x%d)", hours, minutes, m_timeCompression);
    else
        sprintf_s((char*)timeString, TIME_STRING_LENGTH, "%u:%u (x%d)", hours, minutes, m_timeCompression);

    // render the time
    glColor3f(0.0f, 0.0f, 0.0f);
    glRasterPos2i(0, 9);
    glutBitmapString(GLUT_BITMAP_TIMES_ROMAN_24, timeString);
}

void Game::StopAllNpcs(void)
{
    for (auto it = m_npcs.begin(); it != m_npcs.end(); ++it)
    {
        it->second->Stop();
    }
}

void Game::SendAllNpcsToObject(const ObjectType& objectType)
{
    for (auto it = m_npcs.begin(); it != m_npcs.end(); ++it)
    {
        Npc* pNpc = it->second;

        const ObjectId& targetId = pNpc->GetOwnedObject(objectType);
        if (targetId != INVALID_OBJECT_ID)
        {
            GameObject* pTarget = FindObject(targetId);
            if (pTarget)
            {
                Vec2 center;
                pTarget->GetCenter(center);
                pNpc->GoTo(center);
            }
        }
    }
}


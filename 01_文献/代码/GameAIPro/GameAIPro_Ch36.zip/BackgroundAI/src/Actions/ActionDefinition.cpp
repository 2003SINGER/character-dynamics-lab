// ActionDefinition.cpp
#include "ActionDefinition.h"
#include "ActionInstance.h"
#include "../Utils/utils.h"

ActionDefinition::ActionDefinition(const ActionId& id, const ObjectType& target, float minDuration, float maxDuration)
    : m_id(id)
    , m_target(target)
    , m_minDuration(minDuration)
    , m_maxDuration(maxDuration)
{ }

float ActionDefinition::CalculateDuration(void) const
{
    float duration = RandomRange(m_minDuration, m_maxDuration);
    return duration;
}

ActionInstance* ActionDefinition::CreateActionInstance(int index) const
{
    ActionInstance* pActionInstance = new ActionInstance(this, CalculateDuration(), index);
    return pActionInstance;
}


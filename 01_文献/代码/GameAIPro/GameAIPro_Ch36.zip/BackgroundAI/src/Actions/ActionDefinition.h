// ActionDefinition.h
#ifndef __ACTIONDEFINITION_H__
#define __ACTIONDEFINITION_H__

#include "../constants.h"

class ActionInstance;

class ActionDefinition
{
    ActionId m_id;
    ObjectType m_target;
    float m_minDuration;
    float m_maxDuration;

public:
    explicit ActionDefinition(const ActionId& id, const ObjectType& target, float minDuration, float maxDuration);

    const ActionId& GetId(void) const { return m_id; }
    const ObjectType& GetTarget(void) const { return m_target; }
    ActionInstance* CreateActionInstance(int index = 0) const;

private:
    float CalculateDuration(void) const;
};

#endif

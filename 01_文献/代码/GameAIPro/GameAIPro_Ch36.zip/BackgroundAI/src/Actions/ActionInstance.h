// ActionInstance.h
#ifndef __ACTIONINSTANCE_H__
#define __ACTIONINSTANCE_H__

#include "../constants.h"

class ActionDefinition;

class ActionInstance
{
    const ActionDefinition* m_pDefinition;
    float m_duration;
    int m_index;

public:
    explicit ActionInstance(const ActionDefinition* pDefinition, float duration, int index);

    bool Update(float deltaTime);  // returns true if the action is over

    const ActionId& GetId(void) const;
    const ObjectType& GetTarget(void) const;
    float GetDuration(void) const { return m_duration; }
    int GetIndex(void) const { return m_index; }
};

#endif


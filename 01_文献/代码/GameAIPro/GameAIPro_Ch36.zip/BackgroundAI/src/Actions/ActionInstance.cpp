// ActionInstance.cpp
#include "ActionInstance.h"
#include "ActionDefinition.h"

ActionInstance::ActionInstance(const ActionDefinition* pDefinition, float duration, int index)
    : m_pDefinition(pDefinition)
    , m_duration(duration)
    , m_index(index)
{ }

const ActionId& ActionInstance::GetId(void) const
{
    return m_pDefinition->GetId();
}

const ObjectType& ActionInstance::GetTarget(void) const
{
    return m_pDefinition->GetTarget();
}

bool ActionInstance::Update(float deltaTime)
{
    float timeInHours = deltaTime / 60.0f;  // 1 simulation hour == 1 real minute at normal speed
    m_duration -= timeInHours;
    if (m_duration <= 0)
        return true;
    return false;
}


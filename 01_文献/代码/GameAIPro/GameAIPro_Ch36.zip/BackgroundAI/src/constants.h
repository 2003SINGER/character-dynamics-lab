// constants.h
#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

#include <string>

const int WINDOW_WIDTH = 768;
const int WINDOW_HEIGHT = 768;
const float GLOBAL_SCALE = 0.375f;
const unsigned int NUM_INTERVALS = 60;
const float INTERVAL = GLOBAL_SCALE;
const float START_HOR_OFFSET = (-30.0f * GLOBAL_SCALE);
const float END_HOR_OFFSET = (START_HOR_OFFSET + (NUM_INTERVALS * INTERVAL));
const float START_VER_OFFSET = (-30.0f * GLOBAL_SCALE);
const float END_VER_OFFSET = (START_VER_OFFSET + (NUM_INTERVALS * INTERVAL));
const float PIXELS_PER_SQUARE_X = WINDOW_WIDTH / NUM_INTERVALS;
const float PIXELS_PER_SQUARE_Y = WINDOW_HEIGHT / NUM_INTERVALS;
const double ORTHO_LEFT = -10.;
const double ORTHO_RIGHT = 10.;
const double ORTHO_TOP = 10.;
const double ORTHO_BOTTOM = -10.;
const double ORTHO_NEAR = 0.;
const double ORTHO_FAR = 20.;

// Z sorting
const float NPC_Z = -1.3f;
const float INTERACTABLEGAMEOBJECT_Z = -1.35f;
const float INITIAL_GAMEOBJECT_Z = -1.4f;
const float GRID_Z = -1.5f;
const float ARENA_Z = -1.6f;


// object types & constants
// Having these as strings makes life easier for the purposes of learning how the system fits together.  In a real 
// game, these would probably be hashed, or perhaps just unsigned int's.
typedef std::string ObjectType;
typedef std::string ObjectId;
const ObjectId INVALID_OBJECT_ID("INVALID_OBJECT_ID");
const ObjectType INVALID_OBJECT_TYPE("INVALID_OBJECT_TYPE");

// schedule types & constants
typedef std::string ScheduleId;
typedef std::string ScheduleEntryTemplateId;
typedef std::string ScheduleEntryId;
const ScheduleId INVALID_SCHEDULE("INVALID_SCHEDULE");
const ScheduleEntryTemplateId INVALID_SCHEDULE_ENTRY_TEMPLATE("INVALID_SCHEDULE_ENTRY_TEMPLATE");
const ScheduleEntryId INVALID_SCHEDULE_ENTRY("INVALID_SCHEDULE_ENTRY");
typedef std::string ActionId;

#endif

// GameObject.h
#ifndef __GAMEOBJECT_H__
#define __GAMEOBJECT_H__

#include "../Utils/utils.h"
#include "../constants.h"

class TiXmlElement;

class GameObject
{
    const static unsigned int DEFAULT_COLOR;

protected:
    ObjectId m_id;
	Rect m_boundingBox;
    float m_z;
    unsigned int m_originalColor, m_color;  // AARRGGBB

public:
    // construction / destruction
	GameObject(void);
    GameObject(unsigned int initialColor, float z = INITIAL_GAMEOBJECT_Z);
    virtual ~GameObject(void) { }
    virtual bool Init(TiXmlElement* pObjectElement);

    // per-frame updates
	virtual void Draw(void);

    // accessors
    const ObjectId& GetId(void) const { return m_id; }
    virtual const ObjectType& GetType(void) const { return INVALID_OBJECT_TYPE; }
    virtual void GetCenter(Vec2& outCenterPoint) const;
    void SetColor(unsigned int color) { m_color = color; }
    void ResetColor(void) { m_color = m_originalColor; }

    // debug stuff
    virtual void GetDebugString(unsigned char* pOutDebugString, size_t size);

protected:
    void SetRenderColor(void);
};

#endif

#ifndef __INTERACTABLEGAMEOBJECT_H__
#define __INTERACTABLEGAMEOBJECT_H__

#include "GameObject.h"

class InteractableGameObject : public GameObject
{
    const static unsigned int INTERACTABLEGAMEOBJECT_COLOR;

    ObjectType m_type;

public:
    // construction / destruction
    InteractableGameObject(void);
    InteractableGameObject(const ObjectType& objectType);
    virtual bool Init(TiXmlElement* pObjectElement);

    // accessors
    virtual const ObjectType& GetType(void) const { return m_type; }
};

#endif

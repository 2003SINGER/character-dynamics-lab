// NPC.cpp
#include "NPC.h"
#include "../Framework/Game.h"
#include "../Schedules/ScheduleDatabase.h"
#include "../Schedules/ScheduleInstance.h"
#include "../Actions/ActionInstance.h"
#include "../constants.h"
#include "../glut/glut.h"
#include "../tinyxml/tinyxml.h"
#include <assert.h>

const float Npc::SPEED_FACTOR = 2.0f;
const float Npc::SPEED_FACTOR_SQUARED = Npc::SPEED_FACTOR * Npc::SPEED_FACTOR;
const float Npc::NPC_SCALE = 2.0f;
const ObjectType Npc::NPC_TYPE("NPC");

extern Game* g_pGame;

Npc::Npc(void)
    : m_lookAt(VEC2_UNIT_X)
    , m_pCurrentAction(NULL)
    , m_pCurrentSchedule(NULL)
    , m_scheduleEntryEndTime(-1)
{ }

Npc::~Npc(void)
{
    EndCurrentAction();
    delete m_pCurrentSchedule;
    m_pCurrentSchedule = NULL;
}

bool Npc::Init(TiXmlElement* pObjectElement)
{
    // initialize the base class portion
    bool success = GameObject::Init(pObjectElement);
    if (!success)
        return false;

    // Position (loaded from base class definition)
    m_pos.x = m_boundingBox.left;
    m_pos.y = m_boundingBox.top;
    m_destination = m_pos;

    // Facing
    TiXmlElement* pFacingElement = pObjectElement->FirstChildElement("Facing");
    if (pFacingElement)
    {
        double x = 0, y = 0;

        pFacingElement->Attribute("x", &x);
        pFacingElement->Attribute("y", &y);

        m_lookAt.x = (float)x;
        m_lookAt.y = (float)y;
        m_lookAt.Normalize();
    }

    // Object ownership
    TiXmlElement* pObjectOwnershipElement = pObjectElement->FirstChildElement("ObjectOwnership");
    if (pObjectOwnershipElement)
    {
        for (TiXmlAttribute* pAttribute = pObjectOwnershipElement->FirstAttribute(); pAttribute != NULL; pAttribute = pAttribute->Next())
        {
            const char* pObjType = pAttribute->Name();
            const char* pObjName = pAttribute->Value();
            m_ownershipMap.insert(std::make_pair(pObjType, pObjName));
        }
    }

    // Initial schedule
    TiXmlElement* pInitialScheduleElement = pObjectElement->FirstChildElement("InitialSchedule");
    if (pInitialScheduleElement)
    {
        const char* pName = pInitialScheduleElement->Attribute("name");
        m_pCurrentSchedule = g_pGame->GetScheduleDatabase()->CreateScheduleInstance(pName);
        assert(m_pCurrentSchedule);
        InitCurrentSchedule();
    }

    return true;
}

void Npc::Draw(void)
{
	static Vec2 p1(0.24f*GLOBAL_SCALE, 0.0f);
	static Vec2 p2(-0.12f*GLOBAL_SCALE, -0.12f*GLOBAL_SCALE);
	static Vec2 p3(-0.12f*GLOBAL_SCALE, 0.12f*GLOBAL_SCALE);
	Vec2 t1, t2, t3;

	// transform points so that triangle "heads" in travel direction
    Vec2 scaledLookAt = m_lookAt * NPC_SCALE;
	t1.x =  p1.x * scaledLookAt.x + p1.y * scaledLookAt.y;
	t1.y = -p1.y * scaledLookAt.x + p1.x * scaledLookAt.y;
	t2.x =  p2.x * scaledLookAt.x + p2.y * scaledLookAt.y;
	t2.y = -p2.y * scaledLookAt.x + p2.x * scaledLookAt.y;
	t3.x =  p3.x * scaledLookAt.x + p3.y * scaledLookAt.y;
	t3.y = -p3.y * scaledLookAt.x + p3.x * scaledLookAt.y;
	glBegin(GL_TRIANGLES);
    SetRenderColor();

	glVertex3f(m_pos.x + t1.x, m_pos.y + t1.y, NPC_Z);
	glVertex3f(m_pos.x + t2.x, m_pos.y + t2.y, NPC_Z);
	glVertex3f(m_pos.x + t3.x, m_pos.y + t3.y, NPC_Z);
	glEnd();
}

void Npc::Update(float deltaTime)
{
    bool isMoving = (m_velocity != VEC2_ZERO);

    // process movement
    if (isMoving)
    {
        if (!CheckForArrival(deltaTime))
        {
	        // move player
	        m_pos.x += SPEED_FACTOR * m_velocity.x * deltaTime;
	        m_pos.y += SPEED_FACTOR * m_velocity.y * deltaTime;
        }
    }

    // process schedule
    if (m_pCurrentSchedule)
    {
        assert(m_scheduleEntryEndTime >= 0 && m_scheduleEntryEndTime < 24);

        // check to see if we crossed the time threshold for a new schedule entry
        if (g_pGame->GetLastTime() < m_scheduleEntryEndTime && g_pGame->GetCurrTime() >= m_scheduleEntryEndTime)
        {
            m_pCurrentSchedule->MoveToNextEntry();
            m_scheduleEntryEndTime = m_pCurrentSchedule->GetEndTime();
            ChooseNewAction();
        }

        // otherwise, update the current action if we're not moving (this simulates an animation running when the NPC arrives)
        else if (m_pCurrentAction && !isMoving)
        {
            if (m_pCurrentAction->Update(deltaTime))
                ChooseNewAction();
        }
    }
}

void Npc::GoTo(const Vec2& dest)
{
    if (m_pos.IsExtremelyCloseTo(dest))
    {
        SetVelocity(VEC2_ZERO);
    }

    else
    {
        m_destination = dest;
        Vec2 diff = m_destination - m_pos;
        diff.Normalize();
        SetVelocity(diff);
    }
}

void Npc::SetVelocity(const Vec2& newVelocity)
{
    m_velocity = newVelocity;

    // change the facing if we have a non-zero velocity.
    if (m_velocity.x != 0 || m_velocity.y != 0)
    {
        m_lookAt = newVelocity;
        m_lookAt.Normalize();
    }
}

const ObjectId& Npc::GetOwnedObject(const ObjectType& objectType) const
{
    auto findIt = m_ownershipMap.find(objectType);
    if (findIt != m_ownershipMap.end())
        return findIt->second;
    else
        return INVALID_OBJECT_ID;
}

void Npc::GetCenter(Vec2& outCenterPoint) const
{
    outCenterPoint = m_pos;
}

void Npc::SetPos(const Vec2& newPos)
{
    m_pos = newPos;
    m_destination = m_pos;
}

void Npc::GetDebugString(unsigned char* pOutDebugString, size_t size)
{
    sprintf_s((char*)pOutDebugString, size, "Name: %s\nPos: (%f, %f)\nSchedule: %s\n  Ends: %f\n  Action: %s on %s\n  %f hours left", 
                                             m_id.c_str(), m_pos.x, m_pos.y, m_pCurrentSchedule->GetId().c_str(), 
                                             m_scheduleEntryEndTime, m_pCurrentAction->GetId().c_str(), m_pCurrentAction->GetTarget().c_str(), 
                                             m_pCurrentAction->GetDuration());
}

bool Npc::CheckForArrival(float deltaTime)
{
    Vec2 diff = m_destination - m_pos;

    // already one step away, so just teleport
    if (diff.LengthSqr() < SPEED_FACTOR_SQUARED * deltaTime)
    {
        m_pos = m_destination;
        SetVelocity(VEC2_ZERO);
        SetFacing(diff);
        return true;
    }

    return false;
}

void Npc::InitCurrentSchedule(void)
{
    m_pCurrentSchedule->ChooseEntryForTime(g_pGame->GetCurrTime());
    m_pCurrentAction = m_pCurrentSchedule->ChooseNewAction(NULL);
    m_scheduleEntryEndTime = m_pCurrentSchedule->GetEndTime();
    ExecuteCurrentAction();
}

void Npc::ExecuteCurrentAction(void)
{
    if (!m_pCurrentAction)
        return;

    // find the next destination object
    const ObjectType& targetType = m_pCurrentAction->GetTarget();
    const ObjectId& targetObjectId = GetOwnedObject(targetType);

    // If this NPC owns an object of the appropriate type, use that object.  Otherwise, find a random 
    // object of the correct type.
    GameObject* pTargetObj = NULL;
    if (targetObjectId != INVALID_OBJECT_ID)
        pTargetObj = g_pGame->FindObject(targetObjectId);
    else
        pTargetObj = g_pGame->FindRandomObject(targetType);

    // head towards the chosen object
    if (pTargetObj)
    {
        Vec2 destination;
        pTargetObj->GetCenter(destination);
        GoTo(destination);

        // debug
        printf("%s executing schedule: \n\tTarget: %s\n\tEnd Time: %f\n", m_id.c_str(), pTargetObj->GetId().c_str(), m_scheduleEntryEndTime);
    }
    else
    {
        printf("[ERROR] Couldn't find target object %s of type %s\n", targetObjectId.c_str(), targetType.c_str());
    }
}

void Npc::ChooseNewAction(void)
{
    ActionInstance* pNewAction = m_pCurrentSchedule->ChooseNewAction(m_pCurrentAction);
    EndCurrentAction();
    m_pCurrentAction = pNewAction;
    ExecuteCurrentAction();
}

void Npc::EndCurrentAction(void)
{
    if (m_pCurrentAction)
    {
        delete m_pCurrentAction;
        m_pCurrentAction = NULL;
    }
}



// GameObject.cpp
#include "GameObject.h"
#include "../glut/glut.h"
#include "../tinyxml/tinyxml.h"

const unsigned int GameObject::DEFAULT_COLOR = 0xffff0000;

GameObject::GameObject(void) 
    : m_originalColor(DEFAULT_COLOR)
    , m_color(DEFAULT_COLOR)
    , m_boundingBox(0, 0, 1, 1)
    , m_z(INITIAL_GAMEOBJECT_Z)
{ }

GameObject::GameObject(unsigned int initialColor, float z)
    : m_originalColor(initialColor)
    , m_color(initialColor)
    , m_boundingBox(0, 0, 1, 1)
    , m_z(z)
{ }

bool GameObject::Init(TiXmlElement* pObjectElement)
{
    if (!pObjectElement)
        return false;

    // id
    const char* pName = pObjectElement->Attribute("name");
    if (!pName)
    {
        assert(0&&"Couldn't find name for GameObject");
        return false;
    }
    m_id = pName;

    // Shape
    TiXmlElement* pShapeElement = pObjectElement->FirstChildElement("Shape");
    if (pShapeElement)
    {
        double x = 0, y = 0, w = 0, h = 0;

        pShapeElement->Attribute("x", &x);
        pShapeElement->Attribute("y", &y);
        pShapeElement->Attribute("w", &w);
        pShapeElement->Attribute("h", &h);

        m_boundingBox.left = (float)(x * GLOBAL_SCALE);
        m_boundingBox.top = (float)(y * GLOBAL_SCALE);
        m_boundingBox.bottom = m_boundingBox.top + (float)(h * GLOBAL_SCALE);
        m_boundingBox.right = m_boundingBox.left + (float)(w * GLOBAL_SCALE);
    }

    // Color
    TiXmlElement* pColorElement = pObjectElement->FirstChildElement("Color");
    if (pColorElement)
    {
        int r = 0, g = 0, b = 0, a = 0;

        pColorElement->Attribute("r", &r);
        pColorElement->Attribute("g", &g);
        pColorElement->Attribute("b", &b);
        pColorElement->Attribute("a", &a);

        m_originalColor = (a << 24) | ((r & 0x000000ff) << 16) | ((g & 0x000000ff) << 8) | (b & 0x000000ff);
        m_color = m_originalColor;
    }

    return true;
}

void GameObject::Draw(void)
{
    glBegin(GL_QUADS);
    SetRenderColor();

	glVertex3f(m_boundingBox.left, m_boundingBox.top, m_z);
	glVertex3f(m_boundingBox.right, m_boundingBox.top, m_z);
	glVertex3f(m_boundingBox.right, m_boundingBox.bottom, m_z);
	glVertex3f(m_boundingBox.left, m_boundingBox.bottom, m_z);

    glEnd();
}

void GameObject::SetRenderColor(void)
{
    unsigned char alpha = (m_color >> 24) & 0x000000ff;
    unsigned char red = (m_color >> 16) & 0x000000ff;
    unsigned char green = (m_color >> 8) & 0x000000ff;
    unsigned char blue = m_color & 0x000000ff;
    glColor4ub(red, green, blue, alpha);
}

void GameObject::GetCenter(Vec2& outCenterPoint) const
{
    outCenterPoint.x = ((m_boundingBox.right - m_boundingBox.left) / 2) + m_boundingBox.left;
    outCenterPoint.y = ((m_boundingBox.bottom - m_boundingBox.top) / 2) + m_boundingBox.top;
}

void GameObject::GetDebugString(unsigned char* pOutDebugString, size_t size)
{
    Vec2 center;
    GetCenter(center);
    sprintf_s((char*)pOutDebugString, size, "Name: %s\nType: %s\nPos: (%f, %f)", m_id.c_str(), GetType().c_str(), center.x, center.y);
}


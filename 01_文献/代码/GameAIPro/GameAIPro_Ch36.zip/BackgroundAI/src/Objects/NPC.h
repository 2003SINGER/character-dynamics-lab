// NPC.h
#ifndef __NPC_H__
#define __NPC_H__

#include "GameObject.h"
#include "../Utils/utils.h"
#include <map>

class ScheduleInstance;
class ActionInstance;

class Npc : public GameObject
{
    typedef std::map<ObjectType, ObjectId> ObjectOwnershipMap;

    const static float SPEED_FACTOR;
    const static float SPEED_FACTOR_SQUARED;
    const static float NPC_SCALE;

public:
    const static ObjectType NPC_TYPE;

private:
	Vec2 m_pos, m_velocity, m_lookAt, m_destination;
    ObjectOwnershipMap m_ownershipMap;

    // actions
    ActionInstance* m_pCurrentAction;

    // schedule stuff
    ScheduleInstance* m_pCurrentSchedule;
    double m_scheduleEntryEndTime;  // the absolute time when this schedule entry will end

public:
    // construction / destruction
    Npc(void);
    virtual ~Npc(void);
    virtual bool Init(TiXmlElement* pObjectElement);

    // per-frame updates
    virtual void Draw(void);
    void Update(float deltaTime);

    // movement functions
    void GoTo(const Vec2& dest);
    void Stop(void) { SetVelocity(VEC2_ZERO); }

    // accessors
    virtual const ObjectType& GetType(void) const { return NPC_TYPE; }
    const ObjectId& GetOwnedObject(const ObjectType& objectType) const;
    virtual void GetCenter(Vec2& outCenterPoint) const;
    void SetPos(const Vec2& newPos);

    // debug stuff
    virtual void GetDebugString(unsigned char* pOutDebugString, size_t size);

private:
    // helpers
    bool CheckForArrival(float deltaTime);
    void InitCurrentSchedule(void);
    void ExecuteCurrentAction(void);
    void ChooseNewAction(void);
    void EndCurrentAction(void);

    // internal accessors
    void SetVelocity(const Vec2& newVelocity);
    void SetFacing(const Vec2& newFacing) { m_lookAt = newFacing; m_lookAt.Normalize(); }
};

#endif


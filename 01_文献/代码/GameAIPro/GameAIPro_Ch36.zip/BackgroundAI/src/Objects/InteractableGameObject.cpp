// InteractableGameObject.cpp
#include "InteractableGameObject.h"
#include "../tinyxml/tinyxml.h"

const unsigned int InteractableGameObject::INTERACTABLEGAMEOBJECT_COLOR = 0xffc0c000;  // a darkish yellow color (192,192,0)

InteractableGameObject::InteractableGameObject(void)
    : GameObject(INTERACTABLEGAMEOBJECT_COLOR, INTERACTABLEGAMEOBJECT_Z)
    , m_type(INVALID_OBJECT_TYPE)
{ }

InteractableGameObject::InteractableGameObject(const ObjectType& objectType) 
    : GameObject(INTERACTABLEGAMEOBJECT_COLOR, INTERACTABLEGAMEOBJECT_Z)
    , m_type(objectType)
{ }

bool InteractableGameObject::Init(TiXmlElement* pObjectElement)
{
    if (!GameObject::Init(pObjectElement))
        return false;

    // type
    const char* pType = pObjectElement->Attribute("type");
    if (pType)
    {
        m_type = pType;
    }

    return true;
}



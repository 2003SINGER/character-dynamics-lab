
#include "StochasticGrammar.h"


using namespace GameAIPro3;


namespace {

template <typename T>
void DumpSequence (const T & seq) {
	for (const auto element : seq)
		std::cout << element;

	std::cout << std::endl;
}


}


int main () {

	typedef Sequence<char> SequenceT;
	typedef Grammar<SequenceT> GrammarT;
	typedef GrammarNodeLeaf<SequenceT> LeafNodeT;
	typedef GrammarNodeSequence<SequenceT> SeqNodeT;
	typedef GrammarNodeAlternation<SequenceT> AltNodeT;


	// First grammar
	AltNodeT * alternation = new AltNodeT;
	alternation->AddOption(new LeafNodeT('b'), 1.0f);
	alternation->AddOption(new LeafNodeT('c'), 3.0f);

	SeqNodeT * node = new SeqNodeT(0.0f);
	node->AddElementToSequence(new LeafNodeT('a'));
	node->AddElementToSequence(alternation);

	GrammarT grammar(node);


	// Second grammar
	AltNodeT * secondAlternation = new AltNodeT;
	secondAlternation->AddOption(new LeafNodeT('d'), 1.0f);
	secondAlternation->AddOption(new LeafNodeT('e'), 3.0f);

	SeqNodeT * secondNode = new SeqNodeT(0.5f);
	secondNode->AddElementToSequence(new LeafNodeT('f'));
	secondNode->AddElementToSequence(secondAlternation);

	GrammarT secondGrammar(secondNode);


	// Basic test of grammar generation
	auto seq = grammar.GenerateSequence();
	DumpSequence(seq);


	// Sanity check 1
	{
		if (grammar.RecognizeSequence(seq))
			std::cout << "RECOGNIZER SUCESS!" << std::endl;
		else
			std::cout << "RECOGNIZER BARF!" << std::endl;
	}

	// Sanity check 2
	{
		SequenceT bogussequence;
		bogussequence.AddElement('a');
		bogussequence.AddElement('d');

		if (grammar.RecognizeSequence(bogussequence))
			std::cout << "FILTER BARF!" << std::endl;
		else
			std::cout << "FILTER SUCCESS!" << std::endl;
	}

	// Rewriter test
	{
		Rewriter<GrammarT, GrammarT> rewriter(grammar, secondGrammar);
		auto secondSeq = rewriter.Rewrite(seq);
		DumpSequence(secondSeq);
	}

	// Stochastic recognition test
	{
		auto permutations = grammar.RecognizeAllSequences(seq);
		for (const auto & pair : permutations) {
			std::cout << "With confidence " << pair.second << " - ";
			DumpSequence(pair.first);
		}
	}

    return 0;
}


#pragma once

// Dependencies
#include <vector>
#include <map>
#include <random>


namespace GameAIPro3
{


template <typename T>
class Sequence {
public:
	typedef T ElementT;
	typedef std::vector<T> ContainerT;
	typedef typename ContainerT::const_iterator const_iterator;

	void AddElement (const ElementT & element) {
		elements.push_back(element);
	}

	const_iterator begin () const {
		return elements.cbegin();
	}

	const_iterator end () const {
		return elements.cend();
	}

private:
	ContainerT elements;
};


template <typename SequenceT>
class GrammarNode {
public:
	virtual ~GrammarNode () { }
	virtual void GenerateElement (SequenceT * out) const = 0;
	virtual bool RecognizeElement (typename SequenceT::const_iterator * iter, typename SequenceT::const_iterator end) const = 0;
	virtual void RecognizeAll (typename SequenceT::const_iterator * iter, typename SequenceT::const_iterator end, std::vector<std::pair<SequenceT, float>> * outPermutations) const = 0;
};


template <typename SequenceT>
class GrammarNodeLeaf : public GrammarNode<SequenceT> {
public:
	typedef typename SequenceT::const_iterator SeqIter;

	explicit GrammarNodeLeaf (const typename SequenceT::ElementT & element)
		: leafElement(element)
	{ }

	void GenerateElement (SequenceT * out) const override {
		out->AddElement(leafElement);
	}

	bool RecognizeElement (SeqIter * iter, SeqIter end) const override {
		return **iter == leafElement;
	}

	void RecognizeAll (SeqIter * iter, SeqIter end, std::vector<std::pair<SequenceT, float>> * outPermutations) const override {
		outPermutations->back().first.AddElement(leafElement);

		if (!RecognizeElement(iter, end))
			outPermutations->back().second = 0.0f;
	}

private:
	typename SequenceT::ElementT leafElement;
};


template <typename SequenceT>
class GrammarNodeSequence : public GrammarNode<SequenceT> {
public:
	typedef typename SequenceT::const_iterator SeqIter;

	explicit GrammarNodeSequence (float repetitionProbability)
		: repProbability(repetitionProbability),
		  randEngine(randDevice())
	{ }

	~GrammarNodeSequence () {
		for (auto * node : children)
			delete node;
	}

	void GenerateElement (SequenceT * out) const override {
		GenerateChildren(out);

		if (repProbability > 0.0f) {
			std::uniform_real_distribution<float> distribution(0.0f, 1.0f);
			while (distribution(randEngine) <= repProbability)
				GenerateChildren(out);
		}
	}

	bool RecognizeElement (SeqIter * iter, SeqIter end) const override {
		SeqIter copyIter = *iter;
		for (const auto * node : children) {
			if (copyIter == end)
				return false;

			if (!node->RecognizeElement(&copyIter, end))
				return false;

			++copyIter;
		}

		*iter = copyIter;
		return true;
	}

	void RecognizeAll (SeqIter * iter, SeqIter end, std::vector<std::pair<SequenceT, float>> * outPermutations) const override {
		SeqIter copyIter = *iter;
		for (const auto * node : children) {
			if (copyIter == end)
				return;

			node->RecognizeAll(&copyIter, end, outPermutations);

			++copyIter;
		}

		*iter = copyIter;
	}

	void AddElementToSequence (GrammarNode<SequenceT> * node) {
		children.push_back(node);
	}

private:
	void GenerateChildren (SequenceT * out) const {
		for (const auto * node : children)
			node->GenerateElement(out);
	}

private:
	std::vector<GrammarNode<SequenceT> *> children;
	float repProbability;

	std::random_device randDevice;
	mutable std::default_random_engine randEngine;
};


template <typename SequenceT>
class GrammarNodeAlternation : public GrammarNode<SequenceT> {
public:
	typedef typename SequenceT::const_iterator SeqIter;

	GrammarNodeAlternation () 
		: weightSum(0.0f),
		  randEngine(randDevice())
	{ }

	~GrammarNodeAlternation () {
		for (auto & node : children)
			delete node.first;
	}

	void GenerateElement (SequenceT * out) const override {
		std::uniform_real_distribution<float> distribution(0, weightSum);
		float rand = distribution(randEngine);

		for (const auto & node : children) {
			if (rand < node.second) {
				node.first->GenerateElement(out);
				return;
			}

			rand -= node.second;
		}
	}

	bool RecognizeElement (SeqIter * iter, SeqIter end) const override {
		SeqIter copyIter = *iter;
		for (auto & node : children) {
			if (node.first->RecognizeElement(&copyIter, end)) {
				*iter = copyIter;
				return true;
			}
		}

		// TODO - recognize repeated sequences!

		return false;
	}

	void RecognizeAll (SeqIter * iter, SeqIter end, std::vector<std::pair<SequenceT, float>> * outPermutations) const override {		
		SequenceT currentSequence = outPermutations->back().first;
		float currentScore = outPermutations->back().second;

		SeqIter copyIter;
		for (auto & node : children) {
			copyIter = *iter;
			outPermutations->emplace_back(currentSequence, currentScore / (weightSum / node.second));
			node.first->RecognizeAll(&copyIter, end, outPermutations);
		}

		// TODO - recognize repeated sequences!

		*iter = copyIter;
	}

	void AddOption (GrammarNode<SequenceT> * node, float weight) {
		children.emplace_back(node, weight);
		weightSum += weight;
	}

private:
	std::vector<std::pair<GrammarNode<SequenceT> *, float>> children;
	float weightSum;

	std::random_device randDevice;
	mutable std::default_random_engine randEngine;
};


template <typename SequenceT>
class Grammar {
public:
	typedef SequenceT SequenceType;

	explicit Grammar (GrammarNode<SequenceT> * root)
		: rootNode(root)
	{ }

	~Grammar () {
		delete rootNode;
	}

	SequenceT GenerateSequence () const {
		SequenceT seq;
		rootNode->GenerateElement(&seq);
		return seq;
	}

	bool RecognizeSequence (const SequenceT & sequence) const {
		auto iter = sequence.begin();
		return rootNode->RecognizeElement(&iter, sequence.end());
	}

	std::vector<std::pair<SequenceT, float>> RecognizeAllSequences (const SequenceT & sequence) const {
		std::vector<std::pair<SequenceT, float>> ret;
		ret.emplace_back(SequenceT(), 1.0f);

		auto iter = sequence.begin();
		rootNode->RecognizeAll(&iter, sequence.end(), &ret);

		return ret;
	}

private:
	GrammarNode<SequenceT> * rootNode;
};


template <typename SourceGrammarT, typename DestGrammarT>
class Rewriter {
public:
	typedef typename DestGrammarT::SequenceType DestSequenceT;
	typedef typename SourceGrammarT::SequenceType SourceSequenceT;

	Rewriter (const SourceGrammarT & source, const DestGrammarT & dest)
		: sourceGrammar(source),
		  destGrammar(dest)
	{ }

	DestSequenceT Rewrite (const SourceSequenceT & sequence) const {
		if (sourceGrammar.RecognizeSequence(sequence))
			return destGrammar.GenerateSequence();

		return DestSequenceT();
	}

private:
	const SourceGrammarT & sourceGrammar;
	const DestGrammarT & destGrammar;
};


}


